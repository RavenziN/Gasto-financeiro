import { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { LocalAuthUser } from '../types';

const STORAGE_KEYS = {
  LOCAL_USER: 'gasto_local_auth_user_v1',
};

export function useAuth() {
  const [currentUser, setCurrentUser] = useState<User | LocalAuthUser | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LOCAL_USER);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading initial cached auth session:', e);
    }
    return null;
  });

  const [authLoading, setAuthLoading] = useState(true);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);
        try {
          const userObj: LocalAuthUser = {
            uid: user.uid,
            email: user.email || undefined,
            displayName: user.displayName || undefined,
            photoURL: user.photoURL || undefined,
          };
          localStorage.setItem(STORAGE_KEYS.LOCAL_USER, JSON.stringify(userObj));
        } catch (e) {
          console.error('Error caching auth session to localStorage:', e);
        }
      } else {
        const saved = localStorage.getItem(STORAGE_KEYS.LOCAL_USER);
        if (saved) {
          try {
            setCurrentUser(JSON.parse(saved));
          } catch (e) {
            console.error('Error restoring session from localStorage:', e);
            setCurrentUser(null);
          }
        } else {
          setCurrentUser(null);
        }
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLocalLogin = useCallback((user: LocalAuthUser) => {
    setCurrentUser(user);
    try {
      localStorage.setItem(STORAGE_KEYS.LOCAL_USER, JSON.stringify(user));
    } catch (e) {
      console.error('Error saving local user session:', e);
    }
  }, []);

  const handleSignOut = useCallback(async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Error signing out of Firebase:', e);
    }
    try {
      localStorage.removeItem(STORAGE_KEYS.LOCAL_USER);
    } catch (e) {
      console.error('Error clearing local user session:', e);
    }
    setCurrentUser(null);
  }, []);

  return {
    currentUser,
    setCurrentUser,
    authLoading,
    handleLocalLogin,
    handleSignOut,
  };
}
