export function triggerHaptic(duration = 10) {
  if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
    try {
      navigator.vibrate(duration);
    } catch {
      // Ignore vibration errors on unsupported devices/browsers
    }
  }
}
