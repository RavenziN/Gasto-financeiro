import React, { useState, useMemo } from 'react';
import { 
  CreditCard as CardIcon, 
  Users, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Plus, 
  ArrowUpRight, 
  ArrowDownRight, 
  Receipt, 
  PieChart as PieIcon, 
  ChevronLeft, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown,
  Wallet,
  Car,
  Briefcase,
  Sparkles,
  AlertCircle,
  Building2,
  Banknote,
  Target,
  DollarSign,
  ChevronUp,
  Layers,
  ArrowLeftRight,
  Bell,
  User as UserIcon,
  PiggyBank,
  FileText,
  Grid,
  Send,
  Download,
  RotateCcw,
  Zap,
  Tag,
  ShieldCheck,
  Smartphone,
  Eye,
  EyeOff
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, AreaChart, Area, XAxis, YAxis, CartesianGrid } from 'recharts';
import { 
  CardBillPayment, 
  CreditCard, 
  ExpenseItem, 
  MonthSummary, 
  Person, 
  MainTabType, 
  UserProfile,
  WalletAccount,
  WalletTransaction,
  InvestmentBox,
  SubscriptionItem,
  DriverTrip,
  DriverExpense,
  DriverGoals,
  ExtraProfileConfig,
  FreelanceEntry,
  FreelanceExpense,
  FreelanceGoals
} from '../types';
import { 
  formatCurrency, 
  formatMonthDisplay, 
  addMonths, 
  getActiveExpensesForMonth, 
  calculateNetWorth, 
  formatMonthShort 
} from '../utils/financeCalculations';
import { BankLogo } from './BankLogo';

interface ChartsDashboardProps {
  currentMonth: string;
  summary: MonthSummary;
  expenses: ExpenseItem[];
  cards: CreditCard[];
  people: Person[];
  paidBills: CardBillPayment[];
  onNavigateToTab: (tab: MainTabType) => void;
  onSelectMonth: (month: string) => void;
  isDarkMode: boolean;
  onOpenTutorial: () => void;
  onOpenAddExpense: () => void;
  onOpenAddIncome?: () => void;
  onPayBill: (card: CreditCard, amount: number, monthYear: string) => void;
  onNextMonth: () => void;
  isBalanceVisible?: boolean;
  walletAccounts?: WalletAccount[];
  walletTransactions?: WalletTransaction[];
  investmentBoxes?: InvestmentBox[];
  subscriptions?: SubscriptionItem[];
  driverTrips?: DriverTrip[];
  driverExpenses?: DriverExpense[];
  driverGoals?: DriverGoals;
  extraProfile?: ExtraProfileConfig;
  freelanceEntries?: FreelanceEntry[];
  freelanceExpenses?: FreelanceExpense[];
  freelanceGoals?: FreelanceGoals;
  allMonthsHistory?: { monthYear: string; income: number; expense: number; net: number }[];
  totalIncome?: number;
  totalExpense?: number;
  netBalance?: number;
  userProfile?: UserProfile;
  onOpenProfile?: () => void;
  onOpenAddWalletTransaction?: (initialMode?: 'expense' | 'income' | 'transfer' | 'adjust', accountId?: string) => void;
}

const PIE_COLORS = ['#10B981', '#059669', '#34D399', '#6366F1', '#8B5CF6', '#06B6D4', '#F43F5E', '#F59E0B'];

export function ChartsDashboard({
  currentMonth,
  summary,
  expenses,
  cards,
  people,
  paidBills,
  onNavigateToTab,
  onSelectMonth,
  onOpenAddExpense,
  onOpenAddIncome,
  isBalanceVisible = true,
  walletAccounts = [],
  walletTransactions = [],
  investmentBoxes = [],
  subscriptions = [],
  driverTrips = [],
  driverExpenses = [],
  driverGoals,
  extraProfile,
  freelanceEntries = [],
  freelanceExpenses = [],
  freelanceGoals,
  userProfile,
  onOpenProfile,
  onOpenAddWalletTransaction,
  ...props
}: ChartsDashboardProps) {
  const [balanceMode, setBalanceMode] = useState<'totalGastos' | 'saldoCarteira' | 'patrimonio'>('totalGastos');
  const [heroViewType, setHeroViewType] = useState<'value' | 'chart'>('value');
  const [showNotifications, setShowNotifications] = useState(false);

  const displayVal = (val: number) => isBalanceVisible === false ? 'R$ ••••••' : formatCurrency(val);

  const activeExpenses = useMemo(() => {
    return getActiveExpensesForMonth(expenses, currentMonth);
  }, [expenses, currentMonth]);

  const netWorthData = useMemo(() => {
    return calculateNetWorth(
      walletAccounts,
      investmentBoxes,
      summary.totalPending
    );
  }, [walletAccounts, investmentBoxes, summary.totalPending]);

  // Total in Wallet Accounts
  const totalWalletBalance = useMemo(() => {
    return walletAccounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);
  }, [walletAccounts]);

  // Card Bill Status Breakdown
  const cardSummary = useMemo(() => {
    return cards.map((card) => {
      const cardExpenses = activeExpenses.filter((e) => e.expense.cardId === card.id);
      const total = cardExpenses.reduce((acc, curr) => acc + curr.expense.amount, 0);
      const isPaid = paidBills.some((p) => p.cardId === card.id && p.monthYear === currentMonth);
      return {
        card,
        total,
        count: cardExpenses.length,
        isPaid,
      };
    });
  }, [cards, activeExpenses, paidBills, currentMonth]);

  const totalInvoicesAmount = useMemo(() => {
    return cardSummary.reduce((acc, curr) => acc + curr.total, 0);
  }, [cardSummary]);

  // Driver summary
  const driverStats = useMemo(() => {
    const monthTrips = driverTrips.filter(t => t.date.startsWith(currentMonth));
    const monthExpenses = driverExpenses.filter(e => e.date.startsWith(currentMonth));
    
    const gross = monthTrips.reduce((sum, t) => sum + (t.grossAmount || 0), 0);
    const exp = monthExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const net = monthTrips.reduce((sum, t) => sum + (t.netAmount || t.grossAmount || 0), 0) - exp;
    
    const todayStr = new Date().toISOString().split('T')[0];
    const todayTrips = driverTrips.filter(t => t.date === todayStr);
    const todayExpenses = driverExpenses.filter(e => e.date === todayStr);
    const todayNet = todayTrips.reduce((sum, t) => sum + (t.netAmount || t.grossAmount || 0), 0) - 
                     todayExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);

    return {
      gross,
      expenses: exp,
      net,
      count: monthTrips.length,
      todayNet,
      todayCount: todayTrips.length,
      todayGross: todayTrips.reduce((sum, t) => sum + (t.grossAmount || 0), 0),
    };
  }, [driverTrips, driverExpenses, currentMonth]);

  // Freelance summary
  const freelanceStats = useMemo(() => {
    const monthEntries = freelanceEntries.filter(e => e.date.startsWith(currentMonth));
    const monthExpenses = freelanceExpenses.filter(e => e.date.startsWith(currentMonth));
    
    const totalEarnings = monthEntries.reduce((sum, e) => sum + (e.amount || 0), 0);
    const totalExpenses = monthExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const net = totalEarnings - totalExpenses;
    
    return {
      totalEarnings,
      totalExpenses,
      net,
      count: monthEntries.length,
    };
  }, [freelanceEntries, freelanceExpenses, currentMonth]);

  const upcomingBills = useMemo(() => {
    const alerts: { title: string; subtitle: string; days: number; isOverdue: boolean }[] = [];
    const today = new Date();
    const currentDay = today.getDate();
    
    cards.forEach(card => {
      if (card.dueDay >= currentDay && card.dueDay <= currentDay + 5) {
        alerts.push({
          title: `Fatura ${card.name}`,
          subtitle: `Vence dia ${card.dueDay}`,
          days: card.dueDay - currentDay,
          isOverdue: false
        });
      } else if (currentDay > card.dueDay && currentDay <= card.dueDay + 3) {
        alerts.push({
          title: `Fatura ${card.name}`,
          subtitle: `Venceu dia ${card.dueDay}`,
          days: currentDay - card.dueDay,
          isOverdue: true
        });
      }
    });

    subscriptions.forEach(sub => {
      if (!sub.active) return;
      if (sub.billingDay >= currentDay && sub.billingDay <= currentDay + 5) {
        alerts.push({
          title: `Assinatura ${sub.name}`,
          subtitle: `Vence dia ${sub.billingDay}`,
          days: sub.billingDay - currentDay,
          isOverdue: false
        });
      }
    });

    return alerts.sort((a, b) => (a.isOverdue === b.isOverdue ? a.days - b.days : a.isOverdue ? -1 : 1));
  }, [cards, subscriptions]);

  const handlePrevMonth = () => onSelectMonth(addMonths(currentMonth, -1));
  const handleNextMonth = () => onSelectMonth(addMonths(currentMonth, 1));

  // Expenses by Category
  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};
    activeExpenses.forEach((item) => {
      const cat = item.expense.category || 'outros';
      map[cat] = (map[cat] || 0) + item.expense.amount;
    });

    return Object.entries(map).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value,
    })).sort((a, b) => b.value - a.value);
  }, [activeExpenses]);

  // People Split Breakdown
  const peopleSummary = useMemo(() => {
    return people.map((person) => {
      const personExpenses = activeExpenses.filter((e) => e.expense.personId === person.id);
      const total = personExpenses.reduce((acc, curr) => acc + curr.expense.amount, 0);
      const paid = personExpenses
        .filter((e) => e.expense.paidByPerson)
        .reduce((acc, curr) => acc + curr.expense.amount, 0);
      const pending = total - paid;

      return {
        person,
        total,
        paid,
        pending,
        count: personExpenses.length,
        isSettled: total > 0 && pending === 0,
      };
    });
  }, [people, activeExpenses]);

  const isFreelanceMode = extraProfile?.workType === 'freelancer';

  // Dynamic days in the currently viewed month
  const daysInCurrentMonth = useMemo(() => {
    const [y, m] = currentMonth.split('-').map(Number);
    return y && m ? new Date(y, m, 0).getDate() : 31;
  }, [currentMonth]);

  // Wave Chart Data for the Hero Section
  const heroChartData = useMemo(() => {
    const lastDay = daysInCurrentMonth;
    const intervals = [
      { label: '01', day: 1 },
      { label: '05', day: 5 },
      { label: '10', day: 10 },
      { label: '15', day: 15 },
      { label: '20', day: 20 },
      { label: '25', day: 25 },
      { label: String(lastDay).padStart(2, '0'), day: lastDay },
    ];

    if (balanceMode === 'saldoCarteira') {
      return intervals.map((int, i) => {
        const factor = 0.7 + 0.3 * (i / (intervals.length - 1));
        const variation = Math.sin((i / 2) * Math.PI) * (totalWalletBalance * 0.08);
        return {
          name: `Dia ${int.label}`,
          day: int.day,
          value: Math.max(0, Math.round(totalWalletBalance * factor + (i === intervals.length - 1 ? 0 : variation))),
          isLast: i === intervals.length - 1,
        };
      });
    }

    if (balanceMode === 'patrimonio') {
      return intervals.map((int, i) => {
        const factor = 0.88 + 0.12 * (i / (intervals.length - 1));
        return {
          name: `Dia ${int.label}`,
          day: int.day,
          value: Math.round(netWorthData.netWorth * factor),
          isLast: i === intervals.length - 1,
        };
      });
    }

    // Default: Total de Gastos no Mês - calculate accumulated expenses by date
    const totalMonth = summary.totalMonth;
    const hasExpenses = activeExpenses.length > 0 || totalMonth > 0;
    if (!hasExpenses) {
      return intervals.map((int, i) => ({
        name: `Dia ${int.label}`,
        day: int.day,
        value: 0,
        isLast: i === intervals.length - 1,
      }));
    }

    // Check if expenses have specific recorded dates in this month
    const hasRecordedDates = activeExpenses.some(
      (item) => !!item.expense.date && item.expense.date.startsWith(currentMonth)
    );

    return intervals.map((int, i) => {
      let val = 0;
      if (hasRecordedDates) {
        const expensesUpToDay = activeExpenses.filter((item) => {
          const pDate = item.expense.date;
          if (!pDate) return true;
          const day = parseInt(pDate.split('-')[2] || '1', 10);
          return day <= int.day;
        });
        val = expensesUpToDay.reduce((sum, item) => sum + (item.expense.amount || 0), 0);
      } else {
        // Natural progression curve up to the full month total
        const progress = Math.pow((i + 1) / intervals.length, 1.4);
        val = Math.round(totalMonth * progress);
      }

      // Always guarantee that the last day (e.g. Dia 31) reaches the exact full total
      if (i === intervals.length - 1 && totalMonth > 0) {
        val = totalMonth;
      }

      return {
        name: `Dia ${int.label}`,
        day: int.day,
        value: val,
        isLast: i === intervals.length - 1,
      };
    });
  }, [balanceMode, totalWalletBalance, netWorthData.netWorth, activeExpenses, summary.totalMonth, currentMonth, daysInCurrentMonth]);

  // Value displayed in the big hero text according to selected mode
  const currentHeroDisplay = useMemo(() => {
    if (balanceMode === 'saldoCarteira') {
      return {
        label: 'Saldo Disponível na Carteira',
        amount: totalWalletBalance,
        sub: `${walletAccounts.length} contas cadastradas`
      };
    }
    if (balanceMode === 'patrimonio') {
      return {
        label: 'Patrimônio Líquido Total',
        amount: netWorthData.netWorth,
        sub: `Contas (${formatCurrency(totalWalletBalance)}) + Investimentos (${formatCurrency(netWorthData.totalInvested)})`
      };
    }
    return {
      label: 'Total de Gastos no Mês',
      amount: summary.totalMonth,
      sub: `${activeExpenses.length} ${activeExpenses.length === 1 ? 'lançamento' : 'lançamentos'}`
    };
  }, [balanceMode, totalWalletBalance, walletAccounts.length, netWorthData, summary.totalMonth, activeExpenses.length]);

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full pb-8">
      
      {/* ========================================================================= */}
      {/* 1. TOP GREEN HERO HEADER (Matching Reference Layout with Emerald Green) */}
      {/* ========================================================================= */}
      <div className="relative">
        
        {/* Curved Green Hero Card */}
        <div className="rounded-3xl sm:rounded-[36px] bg-gradient-to-b from-[#065F46] via-[#047857] to-[#064E3B] text-white p-4 sm:p-7 pt-4 sm:pt-6 pb-14 sm:pb-16 shadow-2xl relative overflow-hidden">
          
          {/* Subtle glowing orbs */}
          <div className="absolute -top-10 -right-10 w-48 h-48 bg-emerald-300/15 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-emerald-900/30 rounded-full blur-2xl pointer-events-none" />

          {/* Top Row: View Switcher (Valor / Gráfico) + Month Switcher + Notification Bell */}
          <div className="relative z-10 flex items-center justify-between gap-2">
            
            {/* Left: View Toggle (Valor Total vs Gráfico em Onda) - Somente Ícones */}
            <div className="flex items-center gap-1 bg-emerald-950/40 backdrop-blur-md rounded-full p-0.5 sm:p-1 border border-emerald-300/20 shadow-inner">
              <button
                type="button"
                id="hero-view-mode-total"
                onClick={() => setHeroViewType('value')}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  heroViewType === 'value'
                    ? 'bg-white text-emerald-900 shadow-xs scale-100'
                    : 'text-emerald-200 hover:text-white hover:bg-white/10'
                }`}
                title="Exibir valor numérico total"
                aria-label="Exibir valor numérico total"
              >
                <DollarSign size={15} className="stroke-[2.5]" />
              </button>
              <button
                type="button"
                id="hero-view-mode-chart"
                onClick={() => setHeroViewType('chart')}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  heroViewType === 'chart'
                    ? 'bg-white text-emerald-900 shadow-xs scale-100'
                    : 'text-emerald-200 hover:text-white hover:bg-white/10'
                }`}
                title="Exibir gráfico de evolução em onda"
                aria-label="Exibir gráfico de evolução em onda"
              >
                <TrendingUp size={15} className="stroke-[2.5]" />
              </button>
            </div>

            {/* Center: Month Switcher Pill */}
            <div className="flex items-center gap-1 bg-emerald-950/40 backdrop-blur-md rounded-full p-1 border border-emerald-300/20 shadow-inner">
              <button
                type="button"
                onClick={handlePrevMonth}
                title="Mês anterior"
                className="w-7 h-7 rounded-full flex items-center justify-center text-emerald-200 hover:text-white hover:bg-white/10 active:scale-90 transition-all cursor-pointer"
              >
                <ChevronLeft size={16} className="stroke-[2.5]" />
              </button>

              <span className="text-xs sm:text-sm font-bold px-2 text-white capitalize tracking-tight select-none">
                {formatMonthDisplay(currentMonth)}
              </span>

              <button
                type="button"
                onClick={handleNextMonth}
                title="Próximo mês"
                className="w-7 h-7 rounded-full flex items-center justify-center text-emerald-200 hover:text-white hover:bg-white/10 active:scale-90 transition-all cursor-pointer"
              >
                <ChevronRight size={16} className="stroke-[2.5]" />
              </button>
            </div>

            {/* Right: Notification Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-emerald-950/40 border border-emerald-300/20 text-emerald-100 flex items-center justify-center hover:bg-emerald-900/60 active:scale-95 transition-all cursor-pointer relative shadow-sm"
                title="Notificações & Lembretes"
              >
                <Bell size={18} className="stroke-[2.2]" />
                {upcomingBills.length > 0 && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-emerald-900 animate-pulse" />
                )}
              </button>

              {/* Notification Dropdown Popover */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white dark:bg-[#1C1C1E] rounded-2xl shadow-2xl border border-slate-200 dark:border-white/10 p-3 z-50 text-slate-900 dark:text-white animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-white/10">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <AlertCircle size={13} className="text-emerald-500" /> Lembretes
                    </span>
                    <button 
                      onClick={() => setShowNotifications(false)}
                      className="text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                    >
                      Fechar
                    </button>
                  </div>
                  {upcomingBills.length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center">Nenhum vencimento próximo.</p>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto">
                      {upcomingBills.map((bill, i) => (
                        <div key={i} className="p-2 rounded-xl bg-slate-50 dark:bg-white/[0.04] text-xs flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-slate-800 dark:text-white">{bill.title}</p>
                            <p className="text-[10px] text-slate-400">{bill.subtitle}</p>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${bill.isOverdue ? 'bg-rose-100 text-rose-600 dark:bg-rose-900/40 dark:text-rose-300' : 'bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-300'}`}>
                            {bill.isOverdue ? 'Vencido' : bill.days === 0 ? 'Hoje' : `${bill.days}d`}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>

          {/* Balance Hero Display or Wave Chart Display */}
          <div className="relative z-10 text-center pt-4 sm:pt-5 pb-1">
            
            {/* Mode Switcher Tabs (Gastos / Saldo Carteira / Patrimônio) */}
            <div className="inline-flex items-center gap-1 bg-emerald-950/30 p-0.5 rounded-full border border-emerald-300/15 mb-2">
              <button
                type="button"
                onClick={() => setBalanceMode('totalGastos')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all cursor-pointer ${
                  balanceMode === 'totalGastos'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                Gastos do Mês
              </button>
              <button
                type="button"
                onClick={() => setBalanceMode('saldoCarteira')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all cursor-pointer ${
                  balanceMode === 'saldoCarteira'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                Saldo Carteira
              </button>
              <button
                type="button"
                onClick={() => setBalanceMode('patrimonio')}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-all cursor-pointer ${
                  balanceMode === 'patrimonio'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-emerald-200 hover:text-white'
                }`}
              >
                Patrimônio
              </button>
            </div>

            {heroViewType === 'value' ? (
              /* ================= MODE 1: VALOR TOTAL NUMÉRICO ================= */
              <div className="animate-in fade-in duration-200">
                <p className="text-xs font-medium text-emerald-100/90 tracking-wide">
                  {currentHeroDisplay.label}
                </p>

                {/* Big Currency Value */}
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight tabular-nums text-white mt-1 drop-shadow-sm">
                  {displayVal(currentHeroDisplay.amount)}
                </h1>

                {/* Sub Info */}
                <p className="text-[11px] sm:text-xs text-emerald-200/80 mt-1 font-medium">
                  {currentHeroDisplay.sub}
                </p>

                {/* Quitado progress bar if in Gastos mode */}
                {balanceMode === 'totalGastos' && summary.totalMonth > 0 && (
                  <div className="max-w-xs mx-auto mt-3">
                    <div className="flex items-center justify-between text-[10px] text-emerald-200 mb-1 px-1">
                      <span>Quitado: {displayVal(summary.totalPaid)}</span>
                      <span>{((summary.totalPaid / summary.totalMonth) * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-emerald-950/40 rounded-full overflow-hidden">
                      <div 
                        style={{ width: `${Math.min(100, (summary.totalPaid / summary.totalMonth) * 100)}%` }}
                        className="bg-emerald-300 h-full rounded-full transition-all duration-500"
                      />
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* ================= MODE 2: GRÁFICO EM ONDA VERDE (REFERENCE IMAGE) ================= */
              <div className="animate-in fade-in duration-200 w-full pt-1">
                <div className="flex items-center justify-between px-2 text-[11px] text-emerald-200 mb-1">
                  <span className="font-semibold">{currentHeroDisplay.label}</span>
                  <span className="font-bold text-white tabular-nums bg-emerald-900/50 px-2 py-0.5 rounded-full border border-emerald-300/20">
                    Total: {displayVal(currentHeroDisplay.amount)}
                  </span>
                </div>

                <div className="h-44 sm:h-48 w-full -mb-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={heroChartData} margin={{ top: 25, right: 10, left: 10, bottom: 0 }}>
                      <defs>
                        <linearGradient id="heroEmeraldWave" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#6EE7B7" stopOpacity={0.6} />
                          <stop offset="60%" stopColor="#10B981" stopOpacity={0.25} />
                          <stop offset="100%" stopColor="#047857" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" vertical={false} />
                      <XAxis 
                        dataKey="name" 
                        stroke="#A7F3D0" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false}
                        dy={4}
                      />
                      <YAxis hide domain={[0, (dataMax: number) => (dataMax <= 0 ? 100 : Math.round(dataMax * 1.35))]} />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0];
                            return (
                              <div className="flex flex-col items-center -translate-y-4">
                                <div className="bg-emerald-300 text-emerald-950 text-xs font-black px-2.5 py-1 rounded-lg shadow-lg flex items-center gap-1 tracking-tight">
                                  <span>{displayVal(Number(data.value))}</span>
                                </div>
                                <div className="w-2 h-2 bg-emerald-300 rotate-45 -mt-1 shadow-xs" />
                              </div>
                            );
                          }
                          return null;
                        }}
                        cursor={{ stroke: '#6EE7B7', strokeWidth: 1.5, strokeDasharray: '3 3' }}
                      />
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="#6EE7B7"
                        strokeWidth={3.5}
                        fill="url(#heroEmeraldWave)"
                        dot={(props: any) => {
                          const { cx, cy, payload, index } = props;
                          if (cx === undefined || cy === undefined) return <circle key={`dot-null-${index}`} />;
                          const isLast = payload?.isLast;
                          if (isLast) {
                            return (
                              <g key={`dot-last-${index}`}>
                                <circle cx={cx} cy={cy} r={9} fill="#6EE7B7" opacity={0.35} />
                                <circle cx={cx} cy={cy} r={5} fill="#10B981" stroke="#ffffff" strokeWidth={2.5} />
                              </g>
                            );
                          }
                          return (
                            <circle
                              key={`dot-${index}`}
                              cx={cx}
                              cy={cy}
                              r={3.5}
                              fill="#10B981"
                              stroke="#ffffff"
                              strokeWidth={2}
                            />
                          );
                        }}
                        activeDot={{ r: 6.5, fill: '#10B981', stroke: '#ffffff', strokeWidth: 3 }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* ========================================================================= */}
        {/* 2. FLOATING ACTION PILL (Top Up / Send / Request / History style) */}
        {/* ========================================================================= */}
        <div className="relative -mt-9 sm:-mt-10 px-3 sm:px-6 z-20">
          <div className="max-w-lg mx-auto bg-white dark:bg-[#1C1C1E] rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-xl border border-slate-200/70 dark:border-white/[0.1] grid grid-cols-4 gap-2 text-center">
            
            {/* Action 1: Depositar / Receita (Top Up) */}
            <button
              type="button"
              onClick={() => onOpenAddIncome ? onOpenAddIncome() : onOpenAddExpense()}
              className="flex flex-col items-center justify-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900/50 group-active:scale-95 transition-all shadow-2xs">
                <Download size={20} className="stroke-[2.3]" />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200 tracking-tight">
                Receita
              </span>
            </button>

            {/* Action 2: Nova Despesa (Send) */}
            <button
              type="button"
              onClick={onOpenAddExpense}
              className="flex flex-col items-center justify-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center group-hover:bg-rose-100 dark:group-hover:bg-rose-900/50 group-active:scale-95 transition-all shadow-2xs">
                <Send size={20} className="stroke-[2.3]" />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200 tracking-tight">
                Despesa
              </span>
            </button>

            {/* Action 3: Divisão / Cobrar (Request) */}
            <button
              type="button"
              onClick={() => onNavigateToTab('pessoas')}
              className="flex flex-col items-center justify-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/50 group-active:scale-95 transition-all shadow-2xs">
                <Users size={20} className="stroke-[2.3]" />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200 tracking-tight">
                Divisão
              </span>
            </button>

            {/* Action 4: Faturas / Extrato (History) */}
            <button
              type="button"
              onClick={() => onNavigateToTab('cartoes')}
              className="flex flex-col items-center justify-center gap-1.5 group cursor-pointer"
            >
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:bg-amber-100 dark:group-hover:bg-amber-900/50 group-active:scale-95 transition-all shadow-2xs">
                <Clock size={20} className="stroke-[2.3]" />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-200 tracking-tight">
                Faturas
              </span>
            </button>

          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3. MÓDULOS & SERVIÇOS ("Payment List" grid from the reference image) */}
      {/* ========================================================================= */}
      <div className="ios-card rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-sm border border-slate-200/70 dark:border-white/[0.08]">
        
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-800 dark:text-white flex items-center gap-1.5">
            <Grid size={15} className="text-emerald-600 dark:text-emerald-400" />
            <span>Módulos & Serviços</span>
          </h2>
          <span className="text-[11px] text-slate-400 font-medium">
            Toque para navegar
          </span>
        </div>

        {/* 8-Tile Icon Grid matching the mockup style */}
        <div className="grid grid-cols-4 gap-3 sm:gap-4 text-center">
          
          {/* 1. Carteira */}
          <button
            type="button"
            onClick={() => onNavigateToTab('carteira')}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              <Wallet size={22} className="stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
              Carteira
            </span>
          </button>

          {/* 2. Cartões */}
          <button
            type="button"
            onClick={() => onNavigateToTab('cartoes')}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center group-hover:bg-indigo-500 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              <CardIcon size={22} className="stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
              Cartões
            </span>
          </button>

          {/* 3. Extra / Freela */}
          <button
            type="button"
            onClick={() => onNavigateToTab('extra')}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              {isFreelanceMode ? <Briefcase size={22} className="stroke-[2.2]" /> : <Car size={22} className="stroke-[2.2]" />}
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
              {isFreelanceMode ? 'Freela' : 'Extra/App'}
            </span>
          </button>

          {/* 4. Divisão / Pessoas */}
          <button
            type="button"
            onClick={() => onNavigateToTab('pessoas')}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center group-hover:bg-cyan-500 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              <Users size={22} className="stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors">
              Divisão
            </span>
          </button>

          {/* 5. Investimentos / Caixinhas */}
          <button
            type="button"
            onClick={() => onNavigateToTab('investimentos')}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:bg-purple-500 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              <PiggyBank size={22} className="stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
              Caixinhas
            </span>
          </button>

          {/* 6. Assinaturas */}
          <button
            type="button"
            onClick={() => onNavigateToTab('assinaturas')}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center group-hover:bg-rose-500 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              <Sparkles size={22} className="stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors">
              Assinaturas
            </span>
          </button>

          {/* 7. Lançar Gasto */}
          <button
            type="button"
            onClick={onOpenAddExpense}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center group-hover:bg-emerald-700 group-active:scale-95 transition-all shadow-sm">
              <Plus size={24} className="stroke-[2.8]" />
            </div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              + Gasto
            </span>
          </button>

          {/* 8. Meu Perfil */}
          <button
            type="button"
            onClick={() => onOpenProfile && onOpenProfile()}
            className="flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-slate-500/10 text-slate-600 dark:text-slate-300 flex items-center justify-center group-hover:bg-slate-700 group-hover:text-white group-active:scale-95 transition-all shadow-2xs">
              <UserIcon size={22} className="stroke-[2.2]" />
            </div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">
              Perfil
            </span>
          </button>

        </div>

      </div>

      {/* ========================================================================= */}
      {/* 4. VISÃO DOS MÓDULOS (Clean 2-Column Minimalist Fintech Grid from Reference) */}
      {/* ========================================================================= */}
      <div className="space-y-3">
        
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-800 dark:text-white flex items-center gap-1.5">
            <Layers size={15} className="text-emerald-600 dark:text-emerald-400" />
            <span>Visão dos Módulos</span>
          </h2>
          <span className="text-[11px] text-slate-400 dark:text-slate-500 font-medium">
            Toque para acessar
          </span>
        </div>

        {/* Clean 2-Column Minimalist Grid (Inspired by Reference Image with White Cards) */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
          
          {/* 1. CARTEIRA & BANCOS */}
          <div 
            onClick={() => onNavigateToTab('carteira')}
            className="rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-zinc-700 transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between min-h-[128px] sm:min-h-[148px] group"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 flex items-center justify-center shadow-2xs group-hover:text-emerald-600 dark:group-hover:text-emerald-400 group-hover:border-emerald-500/30 transition-all">
                <Wallet size={20} className="stroke-[2]" />
              </div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                <ArrowRight size={13} />
              </span>
            </div>

            <div className="mt-3">
              <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-200 group-hover:text-slate-950 dark:group-hover:text-white transition-colors">
                Carteira & Bancos
              </h3>
              <p className="font-black text-sm sm:text-base text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
                {displayVal(totalWalletBalance)}
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 font-medium truncate mt-0.5">
                {walletAccounts.length} {walletAccounts.length === 1 ? 'conta ativa' : 'contas ativas'}
              </p>
            </div>
          </div>

          {/* 2. CARTÕES DE CRÉDITO */}
          <div 
            onClick={() => onNavigateToTab('cartoes')}
            className="rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-zinc-700 transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between min-h-[128px] sm:min-h-[148px] group"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 flex items-center justify-center shadow-2xs group-hover:text-indigo-600 dark:group-hover:text-indigo-400 group-hover:border-indigo-500/30 transition-all">
                <CardIcon size={20} className="stroke-[2]" />
              </div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                <ArrowRight size={13} />
              </span>
            </div>

            <div className="mt-3">
              <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-200 group-hover:text-slate-950 dark:group-hover:text-white transition-colors">
                Cartões de Crédito
              </h3>
              <p className="font-black text-sm sm:text-base text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
                {displayVal(totalInvoicesAmount)}
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 font-medium truncate mt-0.5">
                {cards.length} {cards.length === 1 ? 'cartão' : 'cartões'} cadastrados
              </p>
            </div>
          </div>

          {/* 3. RENDA EXTRA / FREELA */}
          <div 
            onClick={() => onNavigateToTab('extra')}
            className="rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-zinc-700 transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between min-h-[128px] sm:min-h-[148px] group"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 flex items-center justify-center shadow-2xs group-hover:text-amber-600 dark:group-hover:text-amber-400 group-hover:border-amber-500/30 transition-all">
                {isFreelanceMode ? <Briefcase size={20} className="stroke-[2]" /> : <Car size={20} className="stroke-[2]" />}
              </div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                <ArrowRight size={13} />
              </span>
            </div>

            <div className="mt-3">
              <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-200 group-hover:text-slate-950 dark:group-hover:text-white transition-colors">
                {isFreelanceMode ? 'Projetos Freela' : 'Motorista & Apps'}
              </h3>
              <p className="font-black text-sm sm:text-base text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
                {displayVal(isFreelanceMode ? freelanceStats.net : driverStats.net)}
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 font-medium truncate mt-0.5">
                {isFreelanceMode ? `${freelanceStats.count} projetos este mês` : `${driverStats.count} corridas este mês`}
              </p>
            </div>
          </div>

          {/* 4. INVESTIMENTOS & CAIXINHAS */}
          <div 
            onClick={() => onNavigateToTab('investimentos')}
            className="rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-zinc-700 transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between min-h-[128px] sm:min-h-[148px] group"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 flex items-center justify-center shadow-2xs group-hover:text-purple-600 dark:group-hover:text-purple-400 group-hover:border-purple-500/30 transition-all">
                <PiggyBank size={20} className="stroke-[2]" />
              </div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                <ArrowRight size={13} />
              </span>
            </div>

            <div className="mt-3">
              <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-200 group-hover:text-slate-950 dark:group-hover:text-white transition-colors">
                Investimentos & Caixinhas
              </h3>
              <p className="font-black text-sm sm:text-base text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
                {displayVal(netWorthData.totalInvested)}
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 font-medium truncate mt-0.5">
                {investmentBoxes.length} {investmentBoxes.length === 1 ? 'caixinha guardada' : 'caixinhas guardadas'}
              </p>
            </div>
          </div>

          {/* 5. DIVISÃO DE FATURAS & PESSOAS */}
          <div 
            onClick={() => onNavigateToTab('pessoas')}
            className="rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-zinc-700 transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between min-h-[128px] sm:min-h-[148px] group"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 flex items-center justify-center shadow-2xs group-hover:text-cyan-600 dark:group-hover:text-cyan-400 group-hover:border-cyan-500/30 transition-all">
                <Users size={20} className="stroke-[2]" />
              </div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors">
                <ArrowRight size={13} />
              </span>
            </div>

            <div className="mt-3">
              <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-200 group-hover:text-slate-950 dark:group-hover:text-white transition-colors">
                Divisão & Pessoas
              </h3>
              <p className="font-black text-sm sm:text-base text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
                {displayVal(summary.totalOthers)}
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 font-medium truncate mt-0.5">
                {people.length} {people.length === 1 ? 'pessoa' : 'pessoas'} no rateio
              </p>
            </div>
          </div>

          {/* 6. ASSINATURAS FIXAS */}
          <div 
            onClick={() => onNavigateToTab('assinaturas')}
            className="rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md hover:border-slate-300 dark:hover:border-zinc-700 transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between min-h-[128px] sm:min-h-[148px] group"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700/60 text-slate-800 dark:text-slate-100 flex items-center justify-center shadow-2xs group-hover:text-rose-600 dark:group-hover:text-rose-400 group-hover:border-rose-500/30 transition-all">
                <Sparkles size={20} className="stroke-[2]" />
              </div>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors">
                <ArrowRight size={13} />
              </span>
            </div>

            <div className="mt-3">
              <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-200 group-hover:text-slate-950 dark:group-hover:text-white transition-colors">
                Assinaturas Fixas
              </h3>
              <p className="font-black text-sm sm:text-base text-slate-900 dark:text-white tabular-nums tracking-tight mt-0.5">
                {displayVal(subscriptions.filter(s => s.active).reduce((sum, s) => sum + s.amount, 0))}
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 font-medium truncate mt-0.5">
                {subscriptions.filter(s => s.active).length} ativas este mês
              </p>
            </div>
          </div>

        </div>

      </div>

      {/* ========================================================================= */}
      {/* 5. ANÁLISE DE CATEGORIAS E RATEIO DE PESSOAS */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 items-start">
        
        {/* Category Breakdown (Donut Chart) */}
        <div className="ios-card p-4 sm:p-6 rounded-2xl sm:rounded-3xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <PieIcon size={15} />
              </div>
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white tracking-tight">
                Gastos por Categoria
              </h3>
            </div>
            <span className="text-xs font-medium text-slate-400">
              {categoryData.length} categorias
            </span>
          </div>

          {categoryData.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs font-medium">
              Nenhum lançamento registrado neste mês.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 items-center gap-4">
              <div className="h-44 w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={65}
                      innerRadius={44}
                      paddingAngle={2}
                    >
                      {categoryData.map((_, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={PIE_COLORS[index % PIE_COLORS.length]} 
                          stroke="transparent"
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val: any) => [displayVal(Number(val)), 'Valor']}
                      contentStyle={{
                        backgroundColor: '#1C1C1E',
                        borderRadius: '12px',
                        border: '1px solid rgba(255,255,255,0.1)',
                        fontSize: '12px',
                        color: '#fff',
                        boxShadow: '0 4px 14px rgba(0,0,0,0.3)',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                {categoryData.map((cat, idx) => {
                  const percent = summary.totalMonth > 0 ? (cat.value / summary.totalMonth) * 100 : 0;
                  return (
                    <div key={cat.name} className="flex items-center justify-between text-xs py-0.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }}
                        />
                        <span className="text-slate-700 dark:text-slate-300 font-medium truncate">
                          {cat.name}
                        </span>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 font-normal">
                          ({percent.toFixed(0)}%)
                        </span>
                      </div>
                      <span className="font-semibold text-slate-900 dark:text-white tabular-nums shrink-0 ml-2">
                        {displayVal(cat.value)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Divisão com Pessoas */}
        <div className="ios-card p-4 sm:p-6 rounded-2xl sm:rounded-3xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
                  <Users size={15} />
                </div>
                <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white tracking-tight">
                  Divisão de Faturas
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateToTab('pessoas')}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>Ver todos</span>
                <ArrowRight size={13} />
              </button>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {peopleSummary.map(({ person, total, pending, isSettled, count }) => (
                <div
                  key={person.id}
                  className="p-2.5 rounded-xl border border-slate-200/70 dark:border-white/[0.06] bg-slate-50/60 dark:bg-white/[0.03] flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={`w-7 h-7 rounded-full ${person.avatarBg} text-white font-bold text-xs flex items-center justify-center shrink-0`}
                    >
                      {person.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-semibold text-xs text-slate-900 dark:text-slate-100 truncate">
                        {person.name}
                      </h4>
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 font-normal truncate">
                        {count} {count === 1 ? 'despesa' : 'despesas'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="font-bold text-xs text-slate-900 dark:text-white tabular-nums">
                      {displayVal(total)}
                    </p>
                    {person.isSelf ? (
                      <span className="text-[10px] font-medium text-slate-400 dark:text-slate-500">
                        Sua parte
                      </span>
                    ) : isSettled ? (
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center justify-end gap-1">
                        <CheckCircle2 size={11} />
                        Quitado
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                        Pendente {displayVal(pending)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateToTab('pessoas')}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-200 dark:hover:bg-white/15 transition-colors cursor-pointer flex items-center justify-center gap-1"
          >
            <span>Gerenciar Divisão & Cobranças</span>
            <ArrowRight size={13} />
          </button>
        </div>

      </div>

    </div>
  );
}
