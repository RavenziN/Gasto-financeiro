import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  UserPlus, 
  Phone, 
  QrCode, 
  CreditCard, 
  Sparkles, 
  Camera, 
  Upload, 
  Mail, 
  Trash2,
  FileText
} from 'lucide-react';
import { Person } from '../types';
import { compressImageFile } from '../utils/imageUtils';

interface AddPersonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (personData: Partial<Person>) => void;
  editingPerson?: Person | null;
}

const AVATAR_COLORS = [
  'bg-emerald-600',
  'bg-blue-600',
  'bg-violet-600',
  'bg-pink-600',
  'bg-amber-600',
  'bg-rose-600',
  'bg-indigo-600',
  'bg-teal-600',
  'bg-cyan-600',
  'bg-slate-700',
];

const SUGGESTED_RELATIONS = [
  'Namorada(o)',
  'Esposa / Marido',
  'Irmão / Irmã',
  'Mãe / Pai',
  'Filho(a)',
  'Amigo(a)',
  'Colega de Trabalho',
];

export function AddPersonModal({ isOpen, onClose, onSave, editingPerson }: AddPersonModalProps) {
  const [name, setName] = useState('');
  const [pixKey, setPixKey] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [cpf, setCpf] = useState('');
  const [notes, setNotes] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [avatarBg, setAvatarBg] = useState(AVATAR_COLORS[0]);
  const [isUploading, setIsUploading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingPerson) {
      setName(editingPerson.name || '');
      setPixKey(editingPerson.pixKey || '');
      setPhone(editingPerson.phone || '');
      setEmail(editingPerson.email || '');
      setCpf(editingPerson.cpf || '');
      setNotes(editingPerson.notes || '');
      setPhotoURL(editingPerson.photoURL || '');
      setAvatarBg(editingPerson.avatarBg || AVATAR_COLORS[0]);
    } else {
      setName('');
      setPixKey('');
      setPhone('');
      setEmail('');
      setCpf('');
      setNotes('');
      setPhotoURL('');
      setAvatarBg(AVATAR_COLORS[0]);
    }
  }, [editingPerson, isOpen]);

  if (!isOpen) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const compressed = await compressImageFile(file, 300, 300, 0.85);
      setPhotoURL(compressed);
    } catch (err) {
      console.error('Error compressing photo:', err);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSave({
      id: editingPerson?.id,
      name: name.trim(),
      pixKey: pixKey.trim() || undefined,
      phone: phone.trim() || undefined,
      email: email.trim() || undefined,
      cpf: cpf.trim() || undefined,
      notes: notes.trim() || undefined,
      photoURL: photoURL.trim() || undefined,
      avatarBg,
      isSelf: editingPerson?.isSelf,
    });

    onClose();
  };

  const handleApplySuggestion = (rel: string) => {
    if (!name) {
      setName(rel);
    } else if (!name.includes('(')) {
      setName(`${name} (${rel})`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      <div className="bg-white dark:bg-[#1C1C1E] rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200/80 dark:border-white/[0.08] my-auto max-h-[92vh] flex flex-col justify-between overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 dark:border-white/[0.06] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-slate-100 dark:bg-white/10 text-slate-800 dark:text-slate-200 flex items-center justify-center font-bold shadow-2xs">
              {editingPerson ? <CreditCard size={18} /> : <UserPlus size={18} />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">
                {editingPerson ? 'Editar Pessoa / Empréstimo' : 'Nova Pessoa (Cartão Emprestado)'}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Organize as compras de amigos e familiares no seu cartão
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs overflow-y-auto pr-1 flex-1">
          {/* Avatar Preview & Photo Action */}
          <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-50 dark:bg-black/20 border border-slate-200/70 dark:border-white/[0.06]">
            <div className="relative group shrink-0">
              <div 
                className={`w-14 h-14 rounded-2xl overflow-hidden flex items-center justify-center font-bold text-lg text-white shadow-sm ${
                  photoURL ? 'bg-slate-900' : avatarBg
                }`}
              >
                {photoURL ? (
                  <img 
                    src={photoURL} 
                    alt={name || 'Avatar'} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  (name || 'P').charAt(0).toUpperCase()
                )}
              </div>

              {photoURL && (
                <button
                  type="button"
                  onClick={() => setPhotoURL('')}
                  className="absolute -top-1 -right-1 p-1 bg-rose-600 hover:bg-rose-700 text-white rounded-full shadow-xs cursor-pointer"
                  title="Remover foto"
                >
                  <Trash2 size={11} />
                </button>
              )}
            </div>

            <div className="min-w-0 flex-1">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <p className="font-bold text-slate-900 dark:text-white text-xs">
                Foto ou Avatar
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Adicione a foto do WhatsApp ou escolha uma cor
              </p>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="mt-1.5 px-2.5 py-1 bg-white dark:bg-white/10 hover:bg-slate-100 dark:hover:bg-white/15 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-white/10 rounded-lg text-[10px] font-semibold transition-all inline-flex items-center gap-1 cursor-pointer shadow-2xs"
              >
                <Camera size={11} />
                <span>{isUploading ? 'Carregando...' : photoURL ? 'Trocar Foto' : 'Adicionar Foto'}</span>
              </button>
            </div>
          </div>

          {/* Name & Quick Suggestions */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nome ou Identificação *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Mariana (Namorada), Lucas (Irmão)..."
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
            />

            {!editingPerson && (
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center gap-1">
                  <Sparkles size={10} /> Sugestões:
                </span>
                {SUGGESTED_RELATIONS.map((rel) => (
                  <button
                    key={rel}
                    type="button"
                    onClick={() => handleApplySuggestion(rel)}
                    className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-white/[0.06] hover:bg-slate-200 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 text-[10px] font-medium transition-colors cursor-pointer"
                  >
                    +{rel}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* WhatsApp / Phone */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Phone size={13} className="text-blue-500" />
              WhatsApp / Telefone para Cobrança (opcional)
            </label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Ex: 11999998888 ou (11) 99999-8888"
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
            />
            <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
              Permite enviar cobranças detalhadas com um único clique direto no WhatsApp.
            </p>
          </div>

          {/* Pix Key */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <QrCode size={13} className="text-emerald-500" />
              Chave Pix da pessoa (opcional)
            </label>
            <input
              type="text"
              value={pixKey}
              onChange={(e) => setPixKey(e.target.value)}
              placeholder="CPF, e-mail, telefone ou chave aleatória"
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Avatar Color if no photo */}
          {!photoURL && (
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Cor de Identificação
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                {AVATAR_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setAvatarBg(color)}
                    className={`w-6 h-6 rounded-xl ${color} transition-all cursor-pointer ${
                      avatarBg === color ? 'ring-2 ring-offset-2 ring-emerald-500 scale-110 shadow-xs' : 'opacity-60 hover:opacity-100'
                    }`}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Modal Footer Buttons */}
          <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-slate-100 dark:border-white/[0.06] shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 font-bold bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer"
            >
              {editingPerson ? 'Salvar Alterações' : 'Cadastrar Pessoa'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
