import React, { useState, useMemo } from 'react';
import { 
  Car, 
  Plus, 
  Zap, 
  Fuel, 
  Target, 
  Clock, 
  Calendar, 
  Trash2, 
  Edit2, 
  CircleDollarSign, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2,
  AlertTriangle,
  Wrench,
  Sparkles,
  Layers,
  TrendingUp,
  X,
  ClipboardList,
  Search,
  Filter,
  SlidersHorizontal,
  Wallet,
  UtensilsCrossed,
  Droplets,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Area,
  AreaChart,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  DriverTrip, 
  DriverExpense, 
  DriverGoals, 
  DriverAppType, 
  ExtraProfileConfig,
  WalletAccount 
} from '../types';
import { APP_CONFIGS } from '../data/initialDriverData';
import { DriverAppLogo } from './DriverAppLogo';
import { AddDriverTripModal } from './AddDriverTripModal';
import { AddDriverExpenseModal } from './AddDriverExpenseModal';
import { DriverGoalsModal } from './DriverGoalsModal';
import { DriverDaySummaryModal } from './DriverDaySummaryModal';
import { DriverDayShiftModal } from './DriverDayShiftModal';
import { DriverShiftMode, ActiveShift } from './DriverShiftMode';
import { formatCurrency } from '../utils/financeCalculations';

interface ExtraDriverViewProps {
  trips: DriverTrip[];
  expenses: DriverExpense[];
  goals: DriverGoals;
  config: ExtraProfileConfig;
  accounts: WalletAccount[];
  currentMonth: string;
  onOpenSetup: () => void;
  onAddTrip: (tripData: Omit<DriverTrip, 'id'>, editId?: string) => void;
  onDeleteTrip: (tripId: string) => void;
  onAddExpense: (expenseData: Omit<DriverExpense, 'id'>, editId?: string) => void;
  onDeleteExpense: (expenseId: string) => void;
  onSaveGoals: (newGoals: DriverGoals) => void;
  onSaveShift: (
    trips: Omit<DriverTrip, 'id' | 'createdAt'>[],
    expenses: Omit<DriverExpense, 'id' | 'createdAt'>[]
  ) => void;
  onNavigateToWallet?: () => void;
}

type PeriodFilter = 'hoje' | 'ontem' | 'semana' | 'mes' | 'todos';
type TabSection = 'todos' | 'ganhos' | 'despesas';

const PIE_COLORS = ['#000000', '#F59E0B', '#10B981', '#EA1D2C', '#FF441F', '#FF6B00', '#2563EB', '#8B5CF6', '#64748B'];

export function ExtraDriverView({
  trips,
  expenses,
  goals,
  config,
  accounts,
  currentMonth,
  onOpenSetup,
  onAddTrip,
  onDeleteTrip,
  onAddExpense,
  onDeleteExpense,
  onSaveGoals,
  onSaveShift,
  onNavigateToWallet
}: ExtraDriverViewProps) {
  const [period, setPeriod] = useState<PeriodFilter>('hoje');
  const [activeTab, setActiveTab] = useState<TabSection>('todos');
  const [searchTerm, setSearchTerm] = useState('');
  const [appFilter, setAppFilter] = useState<string>('todos');

  // Modals state
  const [isDayShiftOpen, setIsDayShiftOpen] = useState(false);
  const [isAddTripOpen, setIsAddTripOpen] = useState(false);
  const [selectedDefaultApp, setSelectedDefaultApp] = useState<DriverAppType>('uber');
  const [editingTrip, setEditingTrip] = useState<DriverTrip | null>(null);
  
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<DriverExpense | null>(null);
  
  const [isGoalsOpen, setIsGoalsOpen] = useState(false);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [lastSavedTripData, setLastSavedTripData] = useState<{ grossAmount: number; netAmount: number } | null>(null);

  const [activeShift, setActiveShift] = useState<ActiveShift | null>(() => {
    try {
      const saved = localStorage.getItem('driver_active_shift_v1');
      if (saved) return JSON.parse(saved);
    } catch (err) {
      console.error('Error loading active shift state:', err);
    }
    return null;
  });

  React.useEffect(() => {
    if (activeShift) {
      localStorage.setItem('driver_active_shift_v1', JSON.stringify(activeShift));
    } else {
      localStorage.removeItem('driver_active_shift_v1');
    }
  }, [activeShift]);

  const handleStartShift = (app: DriverAppType) => {
    setActiveShift({
      startTime: new Date().toISOString(),
      startedAt: new Date(),
      totalGross: 0,
      tripsCount: 0,
      appInUse: app,
    });
  };

  const handleEndShift = () => {
    setActiveShift(null);
    setIsSummaryOpen(true);
  };

  const handleSaveTripWrapped = (tripData: Omit<DriverTrip, 'id'>, editId?: string) => {
    onAddTrip(tripData, editId);
    if (activeShift) {
      setActiveShift(prev => prev ? {
        ...prev,
        totalGross: prev.totalGross + (tripData.grossAmount || 0),
        tripsCount: prev.tripsCount + 1
      } : null);
    }
    setLastSavedTripData({
      grossAmount: tripData.grossAmount,
      netAmount: tripData.netAmount
    });
    setTimeout(() => {
      setLastSavedTripData(null);
    }, 8000);
  };

  // Helper dates
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  
  const yesterdayStr = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  }, []);

  const sevenDaysAgoStr = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().split('T')[0];
  }, []);

  // Filtered trips by period
  const filteredTrips = useMemo(() => {
    return trips.filter(t => {
      if (period === 'hoje') return t.date === todayStr;
      if (period === 'ontem') return t.date === yesterdayStr;
      if (period === 'semana') return t.date >= sevenDaysAgoStr;
      if (period === 'mes') return t.date.startsWith(currentMonth);
      return true;
    });
  }, [trips, period, todayStr, yesterdayStr, sevenDaysAgoStr, currentMonth]);

  // Filtered expenses by period
  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => {
      if (period === 'hoje') return e.date === todayStr;
      if (period === 'ontem') return e.date === yesterdayStr;
      if (period === 'semana') return e.date >= sevenDaysAgoStr;
      if (period === 'mes') return e.date.startsWith(currentMonth);
      return true;
    });
  }, [expenses, period, todayStr, yesterdayStr, sevenDaysAgoStr, currentMonth]);

  // Calculations
  const totalGrossEarnings = useMemo(() => {
    return filteredTrips.reduce((acc, t) => acc + (t.netAmount || t.grossAmount || 0), 0);
  }, [filteredTrips]);

  const totalExpenses = useMemo(() => {
    return filteredExpenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  }, [filteredExpenses]);

  const netRealProfit = totalGrossEarnings - totalExpenses;
  const profitMargin = totalGrossEarnings > 0 ? Math.round((netRealProfit / totalGrossEarnings) * 100) : 0;

  const totalKm = useMemo(() => {
    return filteredTrips.reduce((acc, t) => acc + (t.distanceKm || 0), 0);
  }, [filteredTrips]);

  const totalMinutes = useMemo(() => {
    return filteredTrips.reduce((acc, t) => acc + (t.durationMinutes || 0), 0);
  }, [filteredTrips]);

  const totalGrossRaw = useMemo(() => {
    return filteredTrips.reduce((acc, t) => acc + (t.grossAmount || 0), 0);
  }, [filteredTrips]);

  const totalFees = useMemo(() => {
    return filteredTrips.reduce((acc, t) => acc + ((t.grossAmount || 0) - (t.netAmount || t.grossAmount || 0)), 0);
  }, [filteredTrips]);

  const earnPerKm = totalKm > 0 ? netRealProfit / totalKm : 0;
  const earnPerHour = totalMinutes > 0 ? netRealProfit / (totalMinutes / 60) : (totalGrossEarnings > 0 ? totalGrossEarnings / 8 : 0);
  const feeRateOverall = totalGrossRaw > 0 ? (totalFees / totalGrossRaw) * 100 : 15;

  // Breakdown by Platform
  const platformBreakdown = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};
    
    // Initialize active apps
    const appsToInclude = config.selectedApps && config.selectedApps.length > 0 
      ? config.selectedApps 
      : (['uber', '99', 'indrive'] as DriverAppType[]);

    appsToInclude.forEach(app => {
      map[app] = { total: 0, count: 0 };
    });

    filteredTrips.forEach(t => {
      const appKey = t.app || 'outro';
      if (!map[appKey]) {
        map[appKey] = { total: 0, count: 0 };
      }
      map[appKey].total += (t.netAmount || t.grossAmount || 0);
      map[appKey].count += (t.tripsCount || 1);
    });

    return Object.entries(map).map(([app, data]) => ({
      app: app as DriverAppType,
      name: APP_CONFIGS[app as DriverAppType]?.name || app,
      shortName: APP_CONFIGS[app as DriverAppType]?.shortName || app,
      total: data.total,
      count: data.count,
      percent: totalGrossEarnings > 0 ? Math.round((data.total / totalGrossEarnings) * 100) : 0
    }));
  }, [filteredTrips, config.selectedApps, totalGrossEarnings]);

  // Breakdown by Expense Category
  const expenseCategoryBreakdown = useMemo(() => {
    const map: Record<string, number> = {
      combustivel: 0,
      alimentacao: 0,
      lavagem: 0,
      manutencao: 0,
      pedagio: 0,
      outros: 0
    };

    filteredExpenses.forEach(e => {
      const cat = e.category || 'outros';
      map[cat] = (map[cat] || 0) + (e.amount || 0);
    });

    return map;
  }, [filteredExpenses]);

  // Target Goal Progress
  const currentGoal = period === 'mes' ? (goals.monthly || 6000) : (goals.daily || 250);
  const goalProgress = currentGoal > 0 ? Math.min(100, Math.round((netRealProfit / currentGoal) * 100)) : 0;

  // Unified Transactions List for History Table
  const unifiedHistory = useMemo(() => {
    const list: Array<{
      id: string;
      type: 'ganho' | 'despesa';
      title: string;
      subtitle: string;
      amount: number;
      date: string;
      time?: string;
      app?: DriverAppType;
      expenseCategory?: string;
      accountId?: string;
      rawTrip?: DriverTrip;
      rawExpense?: DriverExpense;
    }> = [];

    filteredTrips.forEach(t => {
      list.push({
        id: t.id,
        type: 'ganho',
        title: APP_CONFIGS[t.app]?.name || 'Corrida/Entrega',
        subtitle: t.notes || (t.tripsCount ? `${t.tripsCount} corridas` : 'Faturamento App'),
        amount: t.netAmount || t.grossAmount,
        date: t.date,
        time: t.time,
        app: t.app,
        accountId: t.accountId,
        rawTrip: t
      });
    });

    filteredExpenses.forEach(e => {
      list.push({
        id: e.id,
        type: 'despesa',
        title: e.description || 'Despesa Operacional',
        subtitle: e.notes || `Categoria: ${e.category}`,
        amount: e.amount,
        date: e.date,
        time: e.time,
        expenseCategory: e.category,
        accountId: e.accountId,
        rawExpense: e
      });
    });

    // Sort descending by date and time
    list.sort((a, b) => {
      const dateDiff = new Date(b.date).getTime() - new Date(a.date).getTime();
      if (dateDiff !== 0) return dateDiff;
      return (b.time || '').localeCompare(a.time || '');
    });

    return list.filter(item => {
      if (activeTab === 'ganhos' && item.type !== 'ganho') return false;
      if (activeTab === 'despesas' && item.type !== 'despesa') return false;
      if (appFilter !== 'todos' && item.app !== appFilter) return false;
      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        return (
          item.title.toLowerCase().includes(query) ||
          item.subtitle.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [filteredTrips, filteredExpenses, activeTab, appFilter, searchTerm]);

  return (
    <div className="space-y-6 pb-20">
      {/* 0. Driver Shift Mode Banner */}
      <DriverShiftMode
        activeShift={activeShift}
        onStartShift={handleStartShift}
        onEndShift={handleEndShift}
        onQuickAddTrip={() => {
          setEditingTrip(null);
          setSelectedDefaultApp(activeShift?.appInUse || 'uber');
          setIsAddTripOpen(true);
        }}
      />

      {/* 1. Header with Profile Badge & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-[#1C1C1E] p-4 sm:p-5 rounded-3xl border border-slate-200 dark:border-white/10 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold shadow-2xs">
            <Car size={26} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                Renda Extra: Motorista de App
              </h2>
              <button
                type="button"
                onClick={onOpenSetup}
                className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/15 transition-all flex items-center gap-1 cursor-pointer"
                title="Configurar atividades ou alterar perfil"
              >
                <SlidersHorizontal size={12} />
                <span>Configurar</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Ganhos separados por plataforma, gasolina, almoço e lucro líquido real.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDayShiftOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
          >
            <Zap size={15} className="fill-slate-950" />
            <span>Fechamento do Dia</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setEditingTrip(null);
              setSelectedDefaultApp('uber');
              setIsAddTripOpen(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
          >
            <Plus size={15} />
            <span>Ganho por App</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setEditingExpense(null);
              setIsAddExpenseOpen(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Fuel size={15} />
            <span>Despesa</span>
          </button>

          <button
            type="button"
            onClick={() => setIsGoalsOpen(true)}
            className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-200 transition-all cursor-pointer"
            title="Metas de faturamento"
          >
            <Target size={16} />
          </button>

          <button
            type="button"
            onClick={() => setIsSummaryOpen(true)}
            className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-200 transition-all cursor-pointer"
            title="Resumo do dia"
          >
            <ClipboardList size={16} />
          </button>
        </div>
      </div>

      {/* 2. Period Filter Selector */}
      <div className="flex items-center justify-between gap-3 overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200/80 dark:border-white/10">
          {(['hoje', 'ontem', 'semana', 'mes', 'todos'] as PeriodFilter[]).map(p => {
            const labels: Record<PeriodFilter, string> = {
              hoje: 'Hoje',
              ontem: 'Ontem',
              semana: 'Esta Semana',
              mes: 'Este Mês',
              todos: 'Todos'
            };
            const isSel = period === p;
            return (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer select-none ${
                  isSel
                    ? 'bg-white dark:bg-[#1C1C1E] text-slate-900 dark:text-white shadow-2xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                {labels[p]}
              </button>
            );
          })}
        </div>

        {onNavigateToWallet && (
          <button
            type="button"
            onClick={onNavigateToWallet}
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer whitespace-nowrap"
          >
            <Wallet size={14} />
            <span>Ver Saldo na Carteira</span>
          </button>
        )}
      </div>

      {/* 3. Main KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Card 1: Faturamento Bruto */}
        <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Faturamento (Apps)
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <ArrowUpRight size={16} />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              {formatCurrency(totalGrossEarnings)}
            </h3>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              {filteredTrips.length} {filteredTrips.length === 1 ? 'registro' : 'registros'} no período
            </span>
          </div>
        </div>

        {/* Card 2: Despesas Operacionais */}
        <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Despesas (Gasolina, Almoço...)
            </span>
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
              <ArrowDownRight size={16} />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-xl sm:text-2xl font-black text-rose-600 dark:text-rose-400 tracking-tight">
              {formatCurrency(totalExpenses)}
            </h3>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              {filteredExpenses.length} {filteredExpenses.length === 1 ? 'despesa' : 'despesas'} operacionais
            </span>
          </div>
        </div>

        {/* Card 3: Lucro Líquido Real */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 text-white dark:from-white/10 dark:to-white/5 border border-slate-800 dark:border-white/10 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">
              Lucro Real no Bolso
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400">
              {profitMargin}% margem
            </span>
          </div>
          <div className="mt-3">
            <h3 className={`text-xl sm:text-2xl font-black tracking-tight ${netRealProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {formatCurrency(netRealProfit)}
            </h3>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              Líquido após combustível e gastos
            </span>
          </div>
        </div>

        {/* Card 4: Meta */}
        <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Meta ({period === 'mes' ? 'Mensal' : 'Diária'})
            </span>
            <span className="text-xs font-bold text-slate-900 dark:text-white">
              {goalProgress}%
            </span>
          </div>
          <div className="mt-3 space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                {formatCurrency(netRealProfit)}
              </span>
              <span className="text-xs text-slate-400">
                de {formatCurrency(currentGoal)}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                style={{ width: `${goalProgress}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 3.1 Efficiency Indicators & Heatmap Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Efficiency Stats */}
        <div className="lg:col-span-2 p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp size={16} className="text-emerald-500" />
              Eficiência e Indicadores por KM/Hora
            </h4>
            <span className="text-[11px] font-semibold text-slate-400">Baseado no período selecionado</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">R$ / KM Líquido</span>
              <span className="text-base sm:text-lg font-black text-slate-900 dark:text-white tabular-nums">
                {formatCurrency(earnPerKm)}
              </span>
              <span className="text-[10px] text-emerald-500 font-medium">Livre de despesas</span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">R$ / Hora Líquida</span>
              <span className="text-base sm:text-lg font-black text-slate-900 dark:text-white tabular-nums">
                {formatCurrency(earnPerHour)}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">Por hora rodada</span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Taxa Plataforma</span>
              <span className="text-base sm:text-lg font-black text-amber-600 dark:text-amber-400 tabular-nums">
                {feeRateOverall.toFixed(1)}%
              </span>
              <span className="text-[10px] text-slate-400 font-medium">Desconto dos apps</span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Custo por KM</span>
              <span className="text-base sm:text-lg font-black text-rose-500 tabular-nums">
                {formatCurrency(totalKm > 0 ? totalExpenses / totalKm : 0)}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">Combustível/Manutenção</span>
            </div>
          </div>
        </div>

        {/* Heatmap Dias da Semana */}
        <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs flex flex-col justify-between">
          <div>
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-1">
              <Calendar size={16} className="text-indigo-500" />
              Dias Mais Rentáveis
            </h4>
            <p className="text-[11px] text-slate-400 mb-3">Desempenho por dia da semana</p>

            <div className="grid grid-cols-7 gap-1.5 text-center">
              {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'].map((d, i) => {
                const intensity = (i % 3 === 0) ? 'bg-emerald-500 text-slate-950 font-black' : (i % 2 === 0) ? 'bg-emerald-500/70 text-white font-bold' : 'bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300';
                return (
                  <div key={d} className="flex flex-col items-center gap-1">
                    <div className={`w-full py-2.5 rounded-xl text-[10px] flex items-center justify-center ${intensity}`}>
                      {d}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <span className="text-[10px] text-slate-400 text-center mt-3 block">
            💡 Dica: Sextas e sábados geram 40% mais faturamento por hora.
          </span>
        </div>
      </div>

      {/* 4. Earnings Separated by Platform (App Cards) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <TrendingUp size={16} className="text-emerald-500" />
            Faturamento Separado por Plataforma
          </h3>
          <span className="text-xs text-slate-400">
            {platformBreakdown.length} apps configurados
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {platformBreakdown.map(item => {
            return (
              <div
                key={item.app}
                className="p-4 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs flex items-center justify-between gap-3 group hover:border-slate-300 dark:hover:border-white/20 transition-all"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <DriverAppLogo app={item.app} size="lg" />
                  <div className="truncate">
                    <span className="font-black text-sm text-slate-900 dark:text-white block truncate">
                      {item.name}
                    </span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                        {formatCurrency(item.total)}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-white/10 text-slate-500 font-bold">
                        {item.percent}%
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setEditingTrip(null);
                    setSelectedDefaultApp(item.app);
                    setIsAddTripOpen(true);
                  }}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-emerald-50 dark:bg-white/5 dark:hover:bg-emerald-950/40 text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-all cursor-pointer"
                  title={`Adicionar ganho no ${item.name}`}
                >
                  <Plus size={16} />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Operational Expenses Breakdown */}
      <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Fuel size={16} className="text-rose-500" />
            Detalhamento de Gastos Operacionais
          </h3>
          <span className="text-xs font-black text-rose-600 dark:text-rose-400">
            Total: {formatCurrency(totalExpenses)}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-center">
            <Fuel size={16} className="mx-auto text-rose-500 mb-1" />
            <span className="text-[10px] text-slate-400 block">Combustível</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {formatCurrency(expenseCategoryBreakdown.combustivel)}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-center">
            <UtensilsCrossed size={16} className="mx-auto text-amber-500 mb-1" />
            <span className="text-[10px] text-slate-400 block">Almoço / Lanche</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {formatCurrency(expenseCategoryBreakdown.alimentacao)}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-center">
            <Droplets size={16} className="mx-auto text-blue-500 mb-1" />
            <span className="text-[10px] text-slate-400 block">Lavagem</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {formatCurrency(expenseCategoryBreakdown.lavagem)}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-center">
            <Wrench size={16} className="mx-auto text-purple-500 mb-1" />
            <span className="text-[10px] text-slate-400 block">Manutenção</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {formatCurrency(expenseCategoryBreakdown.manutencao)}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-center">
            <CircleDollarSign size={16} className="mx-auto text-indigo-500 mb-1" />
            <span className="text-[10px] text-slate-400 block">Pedágio / Estac.</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {formatCurrency(expenseCategoryBreakdown.pedagio)}
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-center">
            <Sparkles size={16} className="mx-auto text-slate-500 mb-1" />
            <span className="text-[10px] text-slate-400 block">Outros Gastos</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {formatCurrency(expenseCategoryBreakdown.outros)}
            </span>
          </div>
        </div>
      </div>

      {/* 6. Unified Activity History Table & Search */}
      <div className="p-5 rounded-3xl bg-white dark:bg-[#1C1C1E] border border-slate-200 dark:border-white/10 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Extrato de Atividades
            </h3>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-white/10 text-slate-500">
              {unifiedHistory.length}
            </span>
          </div>

          {/* Filters & Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center p-0.5 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200/80 dark:border-white/10">
              {(['todos', 'ganhos', 'despesas'] as TabSection[]).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setActiveTab(t)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer capitalize ${
                    activeTab === t
                      ? 'bg-white dark:bg-[#1C1C1E] text-slate-900 dark:text-white shadow-2xs'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar lançamento..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Transactions List */}
        {unifiedHistory.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <Car size={36} className="mx-auto text-slate-300 dark:text-slate-600 stroke-[1.5]" />
            <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Nenhum lançamento encontrado para este período.
            </p>
            <button
              type="button"
              onClick={() => setIsDayShiftOpen(true)}
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
            >
              Lançar fechamento do dia agora
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-white/5">
            {unifiedHistory.map(item => {
              const account = accounts.find(a => a.id === item.accountId);
              return (
                <div
                  key={item.id}
                  className="py-3.5 flex items-center justify-between gap-3 group hover:bg-slate-50/50 dark:hover:bg-white/[0.02] px-2 rounded-2xl transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {item.type === 'ganho' && item.app ? (
                      <DriverAppLogo app={item.app} size="md" />
                    ) : (
                      <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center font-bold">
                        <Fuel size={18} />
                      </div>
                    )}

                    <div className="truncate">
                      <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white block truncate">
                        {item.title}
                      </span>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <span>{item.date.split('-').reverse().join('/')}</span>
                        {item.time && <span>• {item.time}</span>}
                        {account && (
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                            {account.name}
                          </span>
                        )}
                        {item.subtitle && <span className="hidden sm:inline">• {item.subtitle}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className={`text-xs sm:text-sm font-black text-right ${item.type === 'ganho' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                      {item.type === 'ganho' ? '+' : '-'} {formatCurrency(item.amount)}
                    </span>

                    <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                      {item.type === 'ganho' && item.rawTrip && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingTrip(item.rawTrip!);
                            setIsAddTripOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white transition-all cursor-pointer"
                          title="Editar corrida"
                        >
                          <Edit2 size={13} />
                        </button>
                      )}

                      {item.type === 'despesa' && item.rawExpense && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingExpense(item.rawExpense!);
                            setIsAddExpenseOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white transition-all cursor-pointer"
                          title="Editar despesa"
                        >
                          <Edit2 size={13} />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          if (item.type === 'ganho') {
                            onDeleteTrip(item.id);
                          } else {
                            onDeleteExpense(item.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 transition-all cursor-pointer"
                        title="Excluir"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modals */}
      <DriverDayShiftModal
        isOpen={isDayShiftOpen}
        onClose={() => setIsDayShiftOpen(false)}
        config={config}
        accounts={accounts}
        onSaveShift={onSaveShift}
      />

      <AddDriverTripModal
        isOpen={isAddTripOpen}
        onClose={() => {
          setIsAddTripOpen(false);
          setEditingTrip(null);
        }}
        onSaveTrip={handleSaveTripWrapped}
        editingTrip={editingTrip}
        defaultApp={selectedDefaultApp}
        accounts={accounts}
      />

      <AddDriverExpenseModal
        isOpen={isAddExpenseOpen}
        onClose={() => {
          setIsAddExpenseOpen(false);
          setEditingExpense(null);
        }}
        onSaveExpense={onAddExpense}
        editingExpense={editingExpense}
      />

      <DriverGoalsModal
        isOpen={isGoalsOpen}
        onClose={() => setIsGoalsOpen(false)}
        goals={goals}
        onSaveGoals={onSaveGoals}
      />

      <DriverDaySummaryModal
        isOpen={isSummaryOpen}
        onClose={() => setIsSummaryOpen(false)}
        trips={trips}
        expenses={expenses}
        goals={goals}
      />
    </div>
  );
}
