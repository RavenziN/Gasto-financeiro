import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  User, 
  Phone, 
  QrCode, 
  LogOut, 
  Check, 
  Camera, 
  Upload, 
  Sparkles, 
  Mail, 
  FileText, 
  Calendar, 
  Briefcase, 
  Trash2,
  Link as LinkIcon, 
  RefreshCw,
  CreditCard,
  ShieldCheck,
  Globe,
  Lock
} from 'lucide-react';
import { Person, UserProfile } from '../types';
import { compressImageFile, AVATAR_PRESETS } from '../utils/imageUtils';
import { auth } from '../lib/firebase';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string | null;
  currentUser?: any;
  profile: UserProfile;
  people: Person[];
  onSaveProfile: (updatedProfile: UserProfile, syncWithPersonMe: boolean) => void;
  onSignOut: () => void;
  onWipeData?: () => void;
  onOpenLegalTerms?: () => void;
}

export function ProfileModal({
  isOpen,
  onClose,
  userEmail,
  currentUser,
  profile,
  people,
  onSaveProfile,
  onSignOut,
  onWipeData,
  onOpenLegalTerms,
}: ProfileModalProps) {
  const [name, setName] = useState('');
  const [nickname, setNickname] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [pixKey, setPixKey] = useState('');
  const [pixKeyType, setPixKeyType] = useState<'cpf' | 'email' | 'telefone' | 'aleatoria'>('email');
  const [photoURL, setPhotoURL] = useState('');
  const [photoSource, setPhotoSource] = useState<'google' | 'upload' | 'url' | 'preset'>('upload');
  const [cpf, setCpf] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [occupation, setOccupation] = useState('');
  const [bio, setBio] = useState('');
  
  // Novas Funcionalidades (Preferences)
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [appLockEnabled, setAppLockEnabled] = useState(false);
  const [appLockPin, setAppLockPin] = useState('');
  const [useBiometrics, setUseBiometrics] = useState(false);
  const [budgets, setBudgets] = useState<Record<string, number>>({});
  
  const [syncWithPersonMe, setSyncWithPersonMe] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [customUrl, setCustomUrl] = useState('');
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'geral' | 'foto' | 'pessoal' | 'prefs'>('geral');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize state on open or profile change
  useEffect(() => {
    if (isOpen) {
      const authUser = auth.currentUser || currentUser;
      const gName = authUser?.displayName || authUser?.providerData?.[0]?.displayName || '';
      const gEmail = authUser?.email || authUser?.providerData?.[0]?.email || userEmail || '';
      const gPhoto = authUser?.photoURL || authUser?.providerData?.[0]?.photoURL || '';
      const gPhone = authUser?.phoneNumber || authUser?.providerData?.[0]?.phoneNumber || '';

      const isPlaceholderName = profile.name === 'Usuário Google';
      const isPlaceholderEmail = profile.email === 'usuario.google@gmail.com';

      const initialName = (!isPlaceholderName && profile.name) ? profile.name : (gName || profile.name || '');
      const initialNickname = (!isPlaceholderName && profile.nickname) ? profile.nickname : (gName || profile.nickname || '');
      const initialEmail = (!isPlaceholderEmail && profile.email) ? profile.email : (gEmail || profile.email || '');
      const initialPhoto = profile.photoURL || gPhoto || '';

      setName(initialName);
      setNickname(initialNickname);
      setEmail(initialEmail);
      setPhone(profile.phone || gPhone || '');
      setPixKey(profile.pixKey || '');
      setPixKeyType(profile.pixKeyType || 'email');
      setPhotoURL(initialPhoto);
      setPhotoSource(profile.photoSource || (initialPhoto ? 'google' : 'upload'));
      setCpf(profile.cpf || '');
      setBirthDate(profile.birthDate || '');
      setOccupation(profile.occupation || '');
      setBio(profile.bio || '');
      
      setNotificationsEnabled(profile.notificationsEnabled || false);
      setAppLockEnabled(profile.appLockEnabled || false);
      setAppLockPin(profile.appLockPin || '');
      setUseBiometrics(profile.useBiometrics || false);
      setBudgets(profile.budgets || {});

      setSavedSuccess(false);
      setShowUrlInput(false);
      setPhotoError(null);
    }
  }, [isOpen, profile, currentUser, userEmail]);

  if (!isOpen) return null;

  // Handle Photo File Upload
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingPhoto(true);
    setPhotoError(null);
    try {
      const compressedDataUrl = await compressImageFile(file, 400, 400, 0.85);
      setPhotoURL(compressedDataUrl);
      setPhotoSource('upload');
    } catch (err: any) {
      setPhotoError(err.message || 'Erro ao processar imagem.');
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Pull Photo and Data from Google
  const handlePullFromGoogle = () => {
    const authUser = auth.currentUser || currentUser;
    if (authUser) {
      const gName = authUser.displayName || authUser.providerData?.[0]?.displayName;
      const gEmail = authUser.email || authUser.providerData?.[0]?.email;
      const gPhoto = authUser.photoURL || authUser.providerData?.[0]?.photoURL;
      const gPhone = authUser.phoneNumber || authUser.providerData?.[0]?.phoneNumber;

      let updated = false;
      if (gPhoto) {
        setPhotoURL(gPhoto);
        setPhotoSource('google');
        updated = true;
      }
      if (gName) {
        setName(gName);
        setNickname(gName);
        updated = true;
      }
      if (gEmail) {
        setEmail(gEmail);
        updated = true;
      }
      if (gPhone) {
        setPhone(gPhone);
        updated = true;
      }

      if (updated) {
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 1800);
      }
    }
  };

  // Apply custom URL
  const handleApplyCustomUrl = () => {
    if (!customUrl.trim()) return;
    setPhotoURL(customUrl.trim());
    setPhotoSource('url');
    setShowUrlInput(false);
    setCustomUrl('');
  };

  // Select Preset Avatar
  const handleSelectPreset = (url: string) => {
    setPhotoURL(url);
    setPhotoSource('preset');
  };

  // Remove Photo
  const handleRemovePhoto = () => {
    setPhotoURL('');
    setPhotoSource('upload');
  };

  // Handle Form Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedProfile: UserProfile = {
      name: name.trim() || undefined,
      nickname: nickname.trim() || undefined,
      email: email.trim() || undefined,
      phone: phone.trim() || undefined,
      pixKey: pixKey.trim() || undefined,
      pixKeyType,
      photoURL: photoURL.trim() || undefined,
      photoSource,
      cpf: cpf.trim() || undefined,
      birthDate: birthDate.trim() || undefined,
      occupation: occupation.trim() || undefined,
      bio: bio.trim() || undefined,
      
      notificationsEnabled,
      appLockEnabled,
      appLockPin,
      useBiometrics,
      budgets,

      updatedAt: new Date().toISOString(),
    };

    onSaveProfile(updatedProfile, syncWithPersonMe);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1000);
  };

  const hasGoogleAccount = Boolean(currentUser?.photoURL || currentUser?.email?.includes('@gmail.com') || currentUser?.providerData?.some((p: any) => p.providerId === 'google.com'));

  return (
    <>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
        <div className="bg-white dark:bg-[#1C1C1E] rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200/80 dark:border-white/[0.08] my-auto max-h-[92vh] flex flex-col justify-between overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 dark:border-white/[0.06] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold shadow-2xs">
              <User size={18} />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">
                Meu Perfil & Dados Pessoais
              </h2>
              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                Personalize sua foto, nome e informações de cobrança
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100/80 dark:bg-white/[0.04] rounded-2xl my-3 shrink-0">
          <button
            type="button"
            onClick={() => setActiveSubTab('geral')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'geral'
                ? 'bg-white dark:bg-[#2C2C2E] text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Identificação
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('foto')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeSubTab === 'foto'
                ? 'bg-white dark:bg-[#2C2C2E] text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Camera size={13} />
            <span>Foto de Perfil</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('pessoal')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'pessoal'
                ? 'bg-white dark:bg-[#2C2C2E] text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Dados Extras
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('prefs')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'prefs'
                ? 'bg-white dark:bg-[#2C2C2E] text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Preferências
          </button>
        </div>

        {/* Form Body - Scrollable */}
        <form onSubmit={handleSubmit} className="overflow-y-auto space-y-4 text-xs pr-1 py-1 flex-1">
          
          {/* ========================================================= */}
          {/* TAB 1: IDENTIFICAÇÃO E CHAVE PIX                         */}
          {/* ========================================================= */}
          {activeSubTab === 'geral' && (
            <div className="space-y-3.5 animate-in fade-in duration-150">
              {/* Profile Card Preview Banner */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100/70 dark:from-white/[0.04] dark:to-white/[0.02] border border-slate-200/80 dark:border-white/[0.08] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-slate-200 border-2 border-white dark:border-slate-800 shadow-sm flex items-center justify-center font-bold text-base shrink-0">
                    {photoURL ? (
                      <img 
                        src={photoURL} 
                        alt={nickname || name || 'Foto'} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover" 
                      />
                    ) : (
                      (nickname || name || 'U').charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                      {name || nickname || 'Seu Nome'}
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {email || userEmail || 'Sem e-mail informado'}
                    </p>
                    {occupation && (
                      <span className="inline-block mt-0.5 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                        {occupation}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveSubTab('foto')}
                  className="px-2.5 py-1.5 bg-white dark:bg-white/10 hover:bg-slate-50 dark:hover:bg-white/15 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-white/10 rounded-xl text-[11px] font-semibold transition-all shrink-0 cursor-pointer shadow-2xs flex items-center gap-1"
                >
                  <Camera size={12} />
                  <span>Trocar Foto</span>
                </button>
              </div>

              {hasGoogleAccount && (
                <div className="p-2.5 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/70 dark:border-blue-900/40 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-7 h-7 rounded-xl bg-white dark:bg-white/10 flex items-center justify-center text-blue-600 shadow-2xs shrink-0">
                      <Globe size={14} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] font-bold text-blue-900 dark:text-blue-200 truncate">
                        Conta Google Conectada
                      </p>
                      <p className="text-[10px] text-blue-700/80 dark:text-blue-300/70 truncate">
                        Puxe a foto original e dados da sua conta
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handlePullFromGoogle}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[11px] font-bold transition-all shadow-xs shrink-0 cursor-pointer flex items-center gap-1 active:scale-95"
                  >
                    <RefreshCw size={11} />
                    <span>Puxar do Google</span>
                  </button>
                </div>
              )}

              {/* Nome Completo */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nome Completo
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Pedro Otávio da Silva"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* Apelido */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Como quer ser chamado(a)? (Apelido no App)
                </label>
                <input
                  type="text"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  placeholder="Ex: Pedro, Mari, Dudu..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* E-mail */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Mail size={13} className="text-slate-400" />
                  E-mail de Contato
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu-email@gmail.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* Chave Pix */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <QrCode size={13} className="text-emerald-500" />
                    Sua Chave Pix para Recebimentos
                  </label>
                  <div className="flex items-center gap-1">
                    {(['cpf', 'email', 'telefone', 'aleatoria'] as const).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setPixKeyType(t)}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase transition-colors cursor-pointer ${
                          pixKeyType === t
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {t === 'aleatoria' ? 'Chave' : t}
                      </button>
                    ))}
                  </div>
                </div>
                <input
                  type="text"
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                  placeholder={
                    pixKeyType === 'cpf' ? '000.000.000-00' :
                    pixKeyType === 'telefone' ? '(11) 99999-9999' :
                    pixKeyType === 'email' ? 'seu-pix@email.com' : 'Chave aleatória'
                  }
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                  Esta chave será inserida automaticamente nas mensagens de cobrança no WhatsApp.
                </p>
              </div>

              {/* WhatsApp / Telefone */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Phone size={13} className="text-blue-500" />
                  WhatsApp / Telefone
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(11) 99999-9999"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* Sync with Person Me Checkbox */}
              <div className="flex items-start gap-2.5 pt-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/60 dark:border-white/[0.05]">
                <input
                  type="checkbox"
                  id="syncPersonMe"
                  checked={syncWithPersonMe}
                  onChange={(e) => setSyncWithPersonMe(e.target.checked)}
                  className="mt-0.5 rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="syncPersonMe" className="text-[11px] text-slate-600 dark:text-slate-300 select-none cursor-pointer leading-tight">
                  <strong className="block text-slate-800 dark:text-white font-semibold">Sincronizar com a aba de Divisão ("Titular / Você")</strong>
                  Atualiza automaticamente seu nome, foto e chave Pix nos rateios de cartão.
                </label>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: GERENCIAMENTO DE FOTO DE PERFIL                   */}
          {/* ========================================================= */}
          {activeSubTab === 'foto' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              
              {/* Active Avatar View & Actions */}
              <div className="flex flex-col items-center justify-center p-5 rounded-3xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/80 dark:border-white/[0.08] text-center">
                <div className="relative group">
                  <div className="w-24 h-24 rounded-full overflow-hidden bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-slate-200 border-4 border-white dark:border-slate-800 shadow-md flex items-center justify-center font-bold text-3xl">
                    {photoURL ? (
                      <img 
                        src={photoURL} 
                        alt={nickname || name || 'Foto de Perfil'} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover" 
                      />
                    ) : (
                      (nickname || name || 'U').charAt(0).toUpperCase()
                    )}
                  </div>

                  {photoURL && (
                    <button
                      type="button"
                      onClick={handleRemovePhoto}
                      title="Remover foto"
                      className="absolute -top-1 -right-1 p-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-full shadow-md transition-all active:scale-90 cursor-pointer"
                    >
                      <Trash2 size={13} />
                    </button>
                  )}
                </div>

                <div className="mt-3">
                  <p className="font-bold text-sm text-slate-900 dark:text-white">
                    {photoURL ? 'Foto de Perfil Definida' : 'Nenhuma foto personalizada'}
                  </p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                    {photoSource === 'google' ? 'Foto sincronizada da Conta Google' : 
                     photoSource === 'upload' ? 'Foto enviada do seu aparelho' : 
                     photoSource === 'preset' ? 'Avatar estilizado selecionado' : 'Usando inicial do nome'}
                  </p>
                </div>

                {photoError && (
                  <p className="mt-2 text-[11px] text-rose-600 dark:text-rose-400 font-semibold">
                    {photoError}
                  </p>
                )}

                {/* Upload Buttons Row */}
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  {/* 1. Escolher do Aparelho */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingPhoto}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 active:scale-95 cursor-pointer disabled:opacity-50"
                  >
                    <Upload size={14} />
                    <span>{isUploadingPhoto ? 'Processando...' : 'Carregar Foto'}</span>
                  </button>

                  {/* 2. Puxar do Google */}
                  {hasGoogleAccount && (
                    <button
                      type="button"
                      onClick={handlePullFromGoogle}
                      className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 active:scale-95 cursor-pointer"
                    >
                      <RefreshCw size={13} />
                      <span>Foto do Google</span>
                    </button>
                  )}

                  {/* 3. Inserir Link */}
                  <button
                    type="button"
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-white/10 dark:hover:bg-white/15 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <LinkIcon size={13} />
                    <span>Inserir Link</span>
                  </button>
                </div>
              </div>

              {/* Custom Image URL input */}
              {showUrlInput && (
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] space-y-2 animate-in fade-in duration-150">
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    URL da Imagem na Web
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="url"
                      value={customUrl}
                      onChange={(e) => setCustomUrl(e.target.value)}
                      placeholder="https://exemplo.com/minha-foto.jpg"
                      className="flex-1 px-3 py-2 bg-white dark:bg-black/40 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={handleApplyCustomUrl}
                      className="px-3 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold rounded-xl text-xs cursor-pointer active:scale-95"
                    >
                      Aplicar
                    </button>
                  </div>
                </div>
              )}

              {/* Preset Avatars Selection */}
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                  <Sparkles size={13} className="text-amber-500" />
                  Ou escolha um Avatar Rápido
                </label>
                <div className="grid grid-cols-6 gap-2">
                  {AVATAR_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleSelectPreset(preset.url)}
                      className={`relative aspect-square rounded-2xl overflow-hidden border-2 transition-all cursor-pointer ${
                        photoURL === preset.url
                          ? 'border-emerald-500 scale-105 shadow-md ring-2 ring-emerald-500/30'
                          : 'border-transparent opacity-75 hover:opacity-100 hover:scale-105'
                      }`}
                    >
                      <img 
                        src={preset.url} 
                        alt={preset.label} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover" 
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: DADOS EXTRAS & NOTA PESSOAL                        */}
          {/* ========================================================= */}
          {activeSubTab === 'pessoal' && (
            <div className="space-y-3.5 animate-in fade-in duration-150">
              {/* CPF / Documento */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <FileText size={13} className="text-slate-400" />
                  CPF ou Documento (Opcional)
                </label>
                <input
                  type="text"
                  value={cpf}
                  onChange={(e) => setCpf(e.target.value)}
                  placeholder="000.000.000-00"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                  Útil para emissão e personalização de relatórios em PDF.
                </p>
              </div>

              {/* Data de Nascimento */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Calendar size={13} className="text-slate-400" />
                  Data de Nascimento
                </label>
                <input
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* Profissão / Atividade */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Briefcase size={13} className="text-slate-400" />
                  Profissão ou Ocupação Principal
                </label>
                <input
                  type="text"
                  value={occupation}
                  onChange={(e) => setOccupation(e.target.value)}
                  placeholder="Ex: Motorista Uber, Engenheiro, Autônomo, Estudante..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* Meta Financeira / Frase de Foco */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Sparkles size={13} className="text-amber-500" />
                  Meta Financeira ou Frase de Foco
                </label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={2}
                  placeholder="Ex: 'Quero atingir R$ 20.000 na caixinha de reserva até o final do ano.'"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 resize-none transition-all"
                />
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 4: PREFERÊNCIAS DE APP E SEGURANÇA                   */}
          {/* ========================================================= */}
          {activeSubTab === 'prefs' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Notificações */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/60 dark:border-white/[0.05]">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                      <ShieldCheck size={15} />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800 dark:text-white">Lembretes de Vencimento</h3>
                      <p className="text-[10px] text-slate-500">Notificações sobre contas e cartões próximos do vencimento.</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={notificationsEnabled}
                      onChange={async (e) => {
                        const checked = e.target.checked;
                        if (checked) {
                          if ('Notification' in window) {
                            const permission = await Notification.requestPermission();
                            setNotificationsEnabled(permission === 'granted');
                            if (permission !== 'granted') {
                              alert('Você precisa permitir as notificações no navegador.');
                            }
                          } else {
                            alert('Seu navegador não suporta notificações Push. Alertas internos ainda funcionarão.');
                            setNotificationsEnabled(true);
                          }
                        } else {
                          setNotificationsEnabled(false);
                        }
                      }}
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-blue-500"></div>
                  </label>
                </div>
              </div>

              {/* Segurança / App Lock */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/60 dark:border-white/[0.05]">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                        <Lock size={15} />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-800 dark:text-white">Bloqueio do App (PIN)</h3>
                        <p className="text-[10px] text-slate-500">Solicitar senha ao abrir o app.</p>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input 
                        type="checkbox" 
                        className="sr-only peer" 
                        checked={appLockEnabled}
                        onChange={(e) => {
                          setAppLockEnabled(e.target.checked);
                          if (!e.target.checked) setAppLockPin('');
                        }}
                      />
                      <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-rose-500"></div>
                    </label>
                  </div>
                  
                  {appLockEnabled && (
                    <div className="mt-2 pl-10">
                      <input
                        type="password"
                        placeholder="Novo PIN (4 a 6 dígitos)"
                        value={appLockPin ? '••••' : ''} // We won't show the real hash
                        onChange={async (e) => {
                          const val = e.target.value.replace(/[^0-9]/g, '');
                          if (val.length >= 4 && val.length <= 6) {
                            const encoder = new TextEncoder();
                            const data = encoder.encode(val);
                            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
                            const hashArray = Array.from(new Uint8Array(hashBuffer));
                            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
                            setAppLockPin(hashHex);
                          } else if (val.length === 0) {
                            setAppLockPin('');
                          }
                        }}
                        className="w-full px-3 py-2 bg-white dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-lg text-xs outline-none focus:ring-1 focus:ring-rose-500"
                        maxLength={6}
                      />
                      <p className="text-[9px] text-slate-400 mt-1">Digite um novo PIN para alterar. Será salvo de forma criptografada.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Alertas de Orçamento */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/60 dark:border-white/[0.05]">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <Sparkles size={15} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 dark:text-white">Alertas de Orçamento</h3>
                    <p className="text-[10px] text-slate-500">Avisar ao atingir limites mensais.</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {['alimentacao', 'transporte', 'lazer'].map((cat) => (
                    <div key={cat} className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium text-slate-700 dark:text-slate-300 capitalize">{cat}</span>
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-slate-500">R$</span>
                        <input
                          type="number"
                          placeholder="Sem limite"
                          value={budgets[cat] || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setBudgets(prev => ({
                              ...prev,
                              [cat]: val ? Number(val) : 0
                            }));
                          }}
                          className="w-24 px-2 py-1.5 bg-white dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-lg text-xs outline-none focus:ring-1 focus:ring-amber-500 text-right"
                        />
                      </div>
                    </div>
                  ))}
                  <p className="text-[9px] text-slate-400">Você será avisado no painel ao atingir 80% e 100% destes valores.</p>
                </div>
              </div>

            </div>
          )}

          {/* Footer Buttons */}
          <div className="pt-3.5 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 dark:border-white/[0.06] shrink-0">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={onSignOut}
                className="px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <LogOut size={14} />
                <span>Sair</span>
              </button>

              {onOpenLegalTerms && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenLegalTerms();
                  }}
                  className="px-3 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ShieldCheck size={14} className="text-emerald-500" />
                  <span>Termos & Privacidade</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>

              <button
                type="submit"
                className="px-5 py-2.5 font-bold bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-xl shadow-xs transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                {savedSuccess && <Check size={14} />}
                <span>{savedSuccess ? 'Salvo!' : 'Salvar Alterações'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </>
);
}
