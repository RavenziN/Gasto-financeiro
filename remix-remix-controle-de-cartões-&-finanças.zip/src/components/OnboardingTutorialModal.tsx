import React, { useState } from 'react';
import { 
  X, 
  ChevronRight, 
  ChevronLeft,
  CreditCard, 
  Users, 
  PiggyBank, 
  Sparkles, 
  Wallet,
  CheckCircle2,
  ShieldCheck,
  Calendar,
  DollarSign,
  QrCode
} from 'lucide-react';

interface OnboardingTutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAddCard: () => void;
  onOpenAddPerson: () => void;
  onOpenAddExpense: () => void;
  onOpenAddWalletAccount?: () => void;
}

const STEPS = [
  {
    id: 'welcome',
    badge: 'Passo 1 de 5',
    title: 'Bem-vindo ao Gastô! 🚀',
    subtitle: 'Seu controle financeiro inteligente e descomplicado',
    description: 'O Gastô? foi desenhado para te dar clareza total: acompanhe faturas de cartão de crédito, divida compras com amigos de forma justa, controle suas contas bancárias e faça suas caixinhas renderem.',
    highlights: [
      { icon: ShieldCheck, text: 'Dados 100% privados na nuvem' },
      { icon: Calendar, text: 'Gestão automática de faturas de cartão' },
      { icon: QrCode, text: 'Cobrança rápida de terceiros via Pix' },
    ],
    icon: Sparkles,
    gradient: 'from-[#00D06C] to-emerald-600',
    iconBg: 'bg-emerald-500/10 text-[#00D06C]',
  },
  {
    id: 'cards',
    badge: 'Passo 2 de 5',
    title: 'Cartões de Crédito & Fechamento 💳',
    subtitle: 'Cadastre suas datas de corte e vencimento',
    description: 'Ao cadastrar seus cartões de crédito (Nubank, Itaú, Mercado Pago, etc.), informe o dia de fechamento da fatura. O app aloca automaticamente cada nova compra na fatura correta!',
    highlights: [
      { icon: Calendar, text: 'Separação automática de fatura atual e próxima' },
      { icon: DollarSign, text: 'Acompanhamento do limite utilizado' },
    ],
    icon: CreditCard,
    gradient: 'from-purple-600 to-indigo-600',
    iconBg: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
    actionText: 'Cadastrar Cartão',
    actionType: 'card',
  },
  {
    id: 'wallet',
    badge: 'Passo 3 de 5',
    title: 'Sua Carteira & Bancos 👛',
    subtitle: 'Centralize seus saldos e conta corrente',
    description: 'Na aba Carteira você cadastra suas contas (Itaú, Bradesco, Nubank, Dinheiro físico) e acompanha o saldo acumulado total. Tudo com movimentações de entradas e transferências.',
    highlights: [
      { icon: Wallet, text: 'Controle de saldo em conta corrente e dinheiro' },
      { icon: DollarSign, text: 'Extrato detalhado de receitas e despesas' },
    ],
    icon: Wallet,
    gradient: 'from-blue-600 to-cyan-600',
    iconBg: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
    actionText: 'Adicionar Conta',
    actionType: 'wallet',
  },
  {
    id: 'people',
    badge: 'Passo 4 de 5',
    title: 'Divisão de Gastos com Pessoas 👥',
    subtitle: 'Sem dor de cabeça para saber quem te deve',
    description: 'Emprestou o cartão para parentes ou comprou algo parcelado para um amigo? Atribua o responsável ao lançar a compra e gere um resumo com chave Pix para cobrar em segundos!',
    highlights: [
      { icon: Users, text: 'Resumo individual por pessoa' },
      { icon: QrCode, text: 'Copiar chave Pix pré-preenchida' },
    ],
    icon: Users,
    gradient: 'from-amber-500 to-orange-600',
    iconBg: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
    actionText: 'Adicionar Pessoa',
    actionType: 'person',
  },
  {
    id: 'boxes',
    badge: 'Passo 5 de 5',
    title: 'Caixinhas & Metas de Investimento 🐷',
    subtitle: 'Faça seu dinheiro trabalhar por você',
    description: 'Crie pastas de metas (Reserva de Emergência, Viagem, Carro Novo) e atribua rendimento mensal baseado no CDI. Registre aportes e resgates com simulação de rendimentos.',
    highlights: [
      { icon: PiggyBank, text: 'Simulador de rendimento CDI em tempo real' },
      { icon: CheckCircle2, text: 'Metas com barra de progresso' },
    ],
    icon: PiggyBank,
    gradient: 'from-emerald-500 to-teal-600',
    iconBg: 'bg-teal-500/10 text-teal-600 dark:text-teal-400',
    actionText: 'Lançar Primeiro Gasto',
    actionType: 'expense',
  },
];

export function OnboardingTutorialModal({
  isOpen,
  onClose,
  onOpenAddCard,
  onOpenAddPerson,
  onOpenAddExpense,
  onOpenAddWalletAccount,
}: OnboardingTutorialModalProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  if (!isOpen) return null;

  const currentStep = STEPS[currentStepIndex];
  const IconComp = currentStep.icon;
  const isLast = currentStepIndex === STEPS.length - 1;
  const isFirst = currentStepIndex === 0;

  const handleNext = () => {
    if (isLast) {
      onClose();
    } else {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (!isFirst) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  const handleAction = () => {
    if (currentStep.actionType === 'card' && onOpenAddCard) {
      onClose();
      onOpenAddCard();
    } else if (currentStep.actionType === 'wallet' && onOpenAddWalletAccount) {
      onClose();
      onOpenAddWalletAccount();
    } else if (currentStep.actionType === 'person' && onOpenAddPerson) {
      onClose();
      onOpenAddPerson();
    } else if (currentStep.actionType === 'expense' && onOpenAddExpense) {
      onClose();
      onOpenAddExpense();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#121214] rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl border border-slate-200/80 dark:border-white/10 relative overflow-hidden flex flex-col">
        
        {/* Top Decorative Banner Pattern */}
        <div className={`absolute top-0 left-0 right-0 h-2 bg-gradient-to-r ${currentStep.gradient}`} />

        {/* Close Button & Step Badge */}
        <div className="flex items-center justify-between mb-4 pt-1">
          <span className="text-[11px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-full bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300">
            {currentStep.badge}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="Fechar tutorial"
          >
            <X size={18} />
          </button>
        </div>

        {/* Main Content Card */}
        <div className="flex flex-col items-center text-center">
          {/* Icon Badge */}
          <div className={`w-16 h-16 rounded-3xl ${currentStep.iconBg} flex items-center justify-center mb-4 shadow-sm border border-current/10 transition-all duration-300 scale-100`}>
            <IconComp size={32} className="stroke-[2]" />
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {currentStep.title}
          </h2>
          <p className="text-xs sm:text-sm font-bold text-[#00D06C] mt-1">
            {currentStep.subtitle}
          </p>
          
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-3 leading-relaxed max-w-md">
            {currentStep.description}
          </p>

          {/* Key Highlights List */}
          {currentStep.highlights && currentStep.highlights.length > 0 && (
            <div className="w-full bg-slate-50 dark:bg-white/[0.04] border border-slate-200/60 dark:border-white/[0.06] rounded-2xl p-3 sm:p-4 mt-4 space-y-2 text-left">
              {currentStep.highlights.map((h, i) => {
                const HIcon = h.icon;
                return (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="w-5 h-5 rounded-full bg-emerald-500/15 text-[#00D06C] flex items-center justify-center shrink-0">
                      <HIcon size={12} className="stroke-[2.5]" />
                    </div>
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      {h.text}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Stepper Dots Progress Indicator */}
          <div className="flex items-center justify-center gap-2 mt-6 mb-6">
            {STEPS.map((_, index) => (
              <button
                key={index}
                type="button"
                onClick={() => setCurrentStepIndex(index)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  index === currentStepIndex
                    ? 'w-7 bg-[#00D06C]'
                    : index < currentStepIndex
                    ? 'w-2 bg-emerald-500/40'
                    : 'w-2 bg-slate-200 dark:bg-white/15'
                }`}
                title={`Ir para o passo ${index + 1}`}
              />
            ))}
          </div>

          {/* Action Buttons */}
          <div className="w-full flex items-center gap-2.5">
            {!isFirst && (
              <button
                type="button"
                onClick={handlePrev}
                className="py-3 px-4 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/15 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-1 shrink-0"
              >
                <ChevronLeft size={16} />
                <span className="hidden sm:inline">Anterior</span>
              </button>
            )}

            {currentStep.actionText && (
              <button
                type="button"
                onClick={handleAction}
                className="flex-1 py-3 px-3 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 text-xs font-extrabold rounded-2xl transition-all cursor-pointer shadow-sm active:scale-[0.98]"
              >
                {currentStep.actionText}
              </button>
            )}

            <button
              type="button"
              onClick={handleNext}
              className={`py-3 px-5 bg-[#00D06C] hover:bg-[#00B960] text-slate-950 text-xs font-black rounded-2xl shadow-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-[0.98] ${
                !currentStep.actionText ? 'flex-1' : ''
              }`}
            >
              <span>{isLast ? 'Começar a Usar!' : 'Próximo'}</span>
              {!isLast && <ChevronRight size={16} className="stroke-[2.5]" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

