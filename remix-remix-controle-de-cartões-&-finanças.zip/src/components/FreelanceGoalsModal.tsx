import React, { useState, useEffect } from 'react';
import { X, Target, CheckCircle2 } from 'lucide-react';
import { FreelanceGoals } from '../types';

interface FreelanceGoalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  goals: FreelanceGoals;
  onSave?: (newGoals: FreelanceGoals) => void;
  onSaveGoals?: (newGoals: FreelanceGoals) => void;
}

export function FreelanceGoalsModal({
  isOpen,
  onClose,
  goals,
  onSave,
  onSaveGoals
}: FreelanceGoalsModalProps) {
  const [monthlyGoal, setMonthlyGoal] = useState('');

  useEffect(() => {
    if (goals) {
      setMonthlyGoal(goals.monthlyIncomeGoal.toString());
    }
  }, [goals, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanGoal = parseFloat(monthlyGoal.replace(',', '.'));
    if (isNaN(cleanGoal) || cleanGoal < 0) return;

    const payload = {
      monthlyIncomeGoal: cleanGoal,
    };

    if (onSave) {
      onSave(payload);
    } else if (onSaveGoals) {
      onSaveGoals(payload);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-[#1C1C1E] border border-slate-200/80 dark:border-white/[0.1] rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Target size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Meta Mensal de Freelance
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Objetivo de faturamento para o mês
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Meta de Lucro Líquido / Faturamento Mensal (R$)
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-indigo-600 dark:text-indigo-400">
                R$
              </span>
              <input
                type="number"
                step="50"
                min="0"
                required
                value={monthlyGoal}
                onChange={e => setMonthlyGoal(e.target.value)}
                placeholder="Ex: 3000,00"
                className="w-full pl-11 pr-4 py-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-black/20 text-lg font-black text-indigo-600 dark:text-indigo-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
              Acompanhe seu progresso em tempo real conforme registra novos projetos e serviços.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-sm shadow-indigo-600/30 flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 size={16} />
              Salvar Meta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
