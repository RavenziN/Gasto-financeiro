import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  Plus, 
  ArrowDownRight, 
  ArrowUpRight, 
  ArrowLeftRight, 
  Sliders, 
  CreditCard, 
  QrCode, 
  Banknote, 
  Search, 
  Trash2, 
  Edit2, 
  Copy, 
  Check, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ChevronRight, 
  Filter,
  Calendar,
  Building2,
  AlertCircle,
  BarChart2,
  BarChart3,
  Table as TableIcon,
  ArrowDown,
  ArrowUp,
  ChevronDown,
  ChevronLeft
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Cell
} from 'recharts';
import { 
  WalletAccount, 
  WalletTransaction, 
  WalletTransactionType, 
  WalletCategory,
  CreditCard as CreditCardType,
  MonthSummary
} from '../types';
import { formatCurrency } from '../utils/financeCalculations';

interface WalletViewProps {
  accounts: WalletAccount[];
  transactions: WalletTransaction[];
  currentMonth: string;
  onMonthChange: (month: string) => void;
  onOpenAddAccount: () => void;
  onOpenEditAccount: (account: WalletAccount) => void;
  onOpenAddTransaction: (initialMode?: 'expense' | 'income' | 'transfer' | 'adjust', accountId?: string) => void;
  onDeleteTransaction: (id: string) => void;
  creditCards?: CreditCardType[];
  monthSummary?: MonthSummary;
}

const CATEGORY_LABELS: Record<string, { label: string; icon: string }> = {
  alimentacao: { label: 'Alimentação', icon: '🍽️' },
  mercado: { label: 'Mercado', icon: '🛒' },
  transporte: { label: 'Transporte', icon: '🚗' },
  combustivel: { label: 'Combustível', icon: '⛽' },
  moradia: { label: 'Moradia & Contas', icon: '🏠' },
  saude: { label: 'Saúde & Farmácia', icon: '💊' },
  lazer: { label: 'Lazer & Cinema', icon: '🍿' },
  educacao: { label: 'Educação', icon: '📚' },
  compras: { label: 'Compras', icon: '🛍️' },
  servicos: { label: 'Serviços', icon: '⚡' },
  salario: { label: 'Salário', icon: '💼' },
  renda_extra: { label: 'Renda Extra', icon: '💰' },
  vendas: { label: 'Vendas', icon: '🏷️' },
  transferencia: { label: 'Transferência', icon: '⇄' },
  ajuste: { label: 'Ajuste de Saldo', icon: '✏️' },
  outros: { label: 'Outros', icon: '📦' },
};

export function WalletView({
  accounts,
  transactions,
  currentMonth,
  onMonthChange,
  onOpenAddAccount,
  onOpenEditAccount,
  onOpenAddTransaction,
  onDeleteTransaction,
  creditCards = [],
  monthSummary,
}: WalletViewProps) {
  const [selectedAccountId, setSelectedAccountId] = useState<string>('all');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('all');
  const [extratoPeriodFilter, setExtratoPeriodFilter] = useState<'month' | '6m' | '12m' | 'all'>('month');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedPixKey, setCopiedPixKey] = useState<string | null>(null);
  const [overviewMode, setOverviewMode] = useState<'chart' | 'values'>('chart');
  const [periodFilter, setPeriodFilter] = useState<'month' | '3m' | '6m' | '12m' | 'all'>('month');

  const realCurrentMonth = useMemo(() => new Date().toISOString().slice(0, 7), []);
  const isCurrentMonth = currentMonth === realCurrentMonth;
  const isFutureMonth = currentMonth > realCurrentMonth;

  // Ensure wallet never opens on a future month
  React.useEffect(() => {
    if (isFutureMonth) {
      onMonthChange(realCurrentMonth);
    }
  }, [isFutureMonth, realCurrentMonth, onMonthChange]);

  // Month navigation helpers
  const handlePrevMonth = () => {
    const [year, month] = currentMonth.split('-').map(Number);
    const date = new Date(year, month - 2, 1);
    const prevMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    onMonthChange(prevMonth);
  };

  const handleNextMonth = () => {
    if (isCurrentMonth || isFutureMonth) return; // Prevent advancing into the future
    const [year, month] = currentMonth.split('-').map(Number);
    const date = new Date(year, month, 1);
    const nextMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    if (nextMonth <= realCurrentMonth) {
      onMonthChange(nextMonth);
    }
  };

  const monthLabel = useMemo(() => {
    const [year, month] = currentMonth.split('-').map(Number);
    const date = new Date(year, month - 1, 1);
    return date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  }, [currentMonth]);

  const monthShortLabel = useMemo(() => {
    const [year, month] = currentMonth.split('-').map(Number);
    const date = new Date(year, month - 1, 1);
    const raw = date.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  }, [currentMonth]);

  // Overall Balances Calculation
  const totalBalance = useMemo(() => {
    const accountsBalance = accounts
      .filter(a => a.includeInTotal)
      .reduce((sum, a) => sum + a.currentBalance, 0);

    // Also include transactions without accounts or not in accounts list
    const unlinkedBalance = transactions
      .filter(t => !t.accountId || !accounts.some(a => a.id === t.accountId))
      .reduce((sum, t) => {
        if (['pix_in', 'deposito', 'transferencia_entrada'].includes(t.type)) return sum + t.amount;
        if (['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(t.type)) return sum - t.amount;
        return sum;
      }, 0);

    return accountsBalance + unlinkedBalance;
  }, [accounts, transactions]);

  // Monthly stats for transactions
  const monthTransactions = useMemo(() => {
    return transactions.filter(t => t.date.startsWith(currentMonth));
  }, [transactions, currentMonth]);

  const monthlyDebitsPix = useMemo(() => {
    return monthTransactions
      .filter(t => ['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(t.type))
      .reduce((sum, t) => sum + t.amount, 0);
  }, [monthTransactions]);

  const monthlyIncomes = useMemo(() => {
    return monthTransactions
      .filter(t => ['pix_in', 'deposito', 'transferencia_entrada'].includes(t.type))
      .reduce((sum, t) => sum + t.amount, 0);
  }, [monthTransactions]);

  // Breakdown by transaction types in the current month for the values view
  const monthlyTypeBreakdown = useMemo(() => {
    const pixIn = monthTransactions.filter(t => t.type === 'pix_in').reduce((s, t) => s + t.amount, 0);
    const deposits = monthTransactions.filter(t => t.type === 'deposito').reduce((s, t) => s + t.amount, 0);
    const transfersIn = monthTransactions.filter(t => t.type === 'transferencia_entrada').reduce((s, t) => s + t.amount, 0);

    const pixOut = monthTransactions.filter(t => t.type === 'pix_out').reduce((s, t) => s + t.amount, 0);
    const debits = monthTransactions.filter(t => t.type === 'debito').reduce((s, t) => s + t.amount, 0);
    const cash = monthTransactions.filter(t => t.type === 'dinheiro_gasto').reduce((s, t) => s + t.amount, 0);
    const transfersOut = monthTransactions.filter(t => t.type === 'transferencia_saida').reduce((s, t) => s + t.amount, 0);

    return {
      pixIn,
      deposits,
      transfersIn,
      totalIncome: pixIn + deposits + transfersIn,
      pixOut,
      debits,
      cash,
      transfersOut,
      totalExpense: pixOut + debits + cash + transfersOut,
    };
  }, [monthTransactions]);

  // Pending credit card bills this month to compare liquidity
  const pendingCardBills = useMemo(() => {
    return monthSummary?.totalPending || 0;
  }, [monthSummary]);

  const projectedRemainingAfterCards = useMemo(() => {
    return totalBalance - pendingCardBills;
  }, [totalBalance, pendingCardBills]);

  // Chart Data calculation - Purely Month by Month comparison (no weeks)
  const chartData: { label: string; fullLabel: string; key: string; income: number; expense: number; isSelected?: boolean; count?: number }[] = useMemo(() => {
    const monthCount = periodFilter === '3m' ? 3 : periodFilter === '12m' ? 12 : periodFilter === 'all' ? 24 : 6;
    const result: { label: string; fullLabel: string; key: string; income: number; expense: number; isSelected?: boolean; count?: number }[] = [];
    const [cy, cm] = currentMonth.split('-').map(Number);
    const baseDate = new Date(cy, cm - 1, 1);

    for (let i = monthCount - 1; i >= 0; i--) {
      const d = new Date(baseDate.getFullYear(), baseDate.getMonth() - i, 1);
      const mKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const rawMonthName = d.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
      const label = rawMonthName.charAt(0).toUpperCase() + rawMonthName.slice(1);
      const fullLabel = d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

      const mTrans = transactions.filter(t => t.date.startsWith(mKey));
      const income = mTrans
        .filter(t => ['pix_in', 'deposito', 'transferencia_entrada'].includes(t.type))
        .reduce((sum, t) => sum + t.amount, 0);
      const expense = mTrans
        .filter(t => ['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(t.type))
        .reduce((sum, t) => sum + t.amount, 0);

      result.push({
        label,
        fullLabel,
        key: mKey,
        income,
        expense,
        isSelected: mKey === currentMonth,
        count: mTrans.length
      });
    }
    return result;
  }, [periodFilter, currentMonth, transactions]);

  const selectedPeriodTotals = useMemo(() => {
    const totalInc = chartData.reduce((sum, item) => sum + item.income, 0);
    const totalExp = chartData.reduce((sum, item) => sum + item.expense, 0);
    return {
      income: totalInc,
      expense: totalExp,
      monthIncome: monthlyIncomes,
      monthExpense: monthlyDebitsPix
    };
  }, [chartData, monthlyIncomes, monthlyDebitsPix]);

  // Filtered transactions for the list
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      // Month filter: only show current month or if searching allow all
      const matchesMonth = searchTerm.trim() ? true : t.date.startsWith(currentMonth);
      if (!matchesMonth) return false;

      // Account filter
      if (selectedAccountId !== 'all') {
        if (t.accountId !== selectedAccountId && t.toAccountId !== selectedAccountId) {
          return false;
        }
      }

      // Type filter
      if (selectedTypeFilter === 'pix') {
        if (!['pix_out', 'pix_in'].includes(t.type)) return false;
      } else if (selectedTypeFilter === 'debito') {
        if (t.type !== 'debito') return false;
      } else if (selectedTypeFilter === 'dinheiro') {
        if (t.type !== 'dinheiro_gasto') return false;
      } else if (selectedTypeFilter === 'saidas') {
        if (!['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(t.type)) return false;
      } else if (selectedTypeFilter === 'entradas') {
        if (!['pix_in', 'deposito', 'transferencia_entrada'].includes(t.type)) return false;
      }

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const descMatch = t.description.toLowerCase().includes(query);
        const recipientMatch = t.recipientOrPayer?.toLowerCase().includes(query);
        const catMatch = t.category.toLowerCase().includes(query);
        const notesMatch = t.notes?.toLowerCase().includes(query);
        if (!descMatch && !recipientMatch && !catMatch && !notesMatch) return false;
      }

      return true;
    }).sort((a, b) => {
      // Sort newest first
      return new Date(`${b.date}T${b.time || '00:00'}`).getTime() - new Date(`${a.date}T${a.time || '00:00'}`).getTime();
    });
  }, [transactions, currentMonth, selectedAccountId, selectedTypeFilter, searchTerm]);

  const handleCopyPix = (pixKey?: string) => {
    if (!pixKey) return;
    navigator.clipboard.writeText(pixKey);
    setCopiedPixKey(pixKey);
    setTimeout(() => setCopiedPixKey(null), 2000);
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      
      {/* ========================================================================= */}
      {/* 🌟 STATISTIC & TOTAL BALANCE HERO (DESIGN INSPIRADO NO MOCKUP) */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-zinc-900 rounded-[32px] p-6 sm:p-7 border border-slate-200/90 dark:border-zinc-800 shadow-sm space-y-6">
        
        {/* Top title, Total Balance & Action Buttons */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-200/50 dark:border-purple-800/40 text-purple-600 dark:text-purple-400 flex items-center justify-center shadow-2xs">
                <BarChart3 size={18} className="stroke-[2.2]" />
              </div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                Statistic
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                Tempo Real
              </span>
            </div>
            
            <p className="text-xs font-semibold text-slate-400 dark:text-slate-500 tracking-wide pt-1">
              Total Balance
            </p>
            
            <div className="pt-0.5">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 dark:text-white tracking-tight tabular-nums">
                {formatCurrency(totalBalance)}
              </h2>
            </div>
            
            <p className="text-xs text-slate-500 dark:text-slate-400 pt-0.5">
              Saldo consolidado em <strong className="text-slate-800 dark:text-slate-200 font-semibold">{accounts.filter(a => a.includeInTotal).length} contas ativas</strong> para movimentação imediata.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            <button
              type="button"
              onClick={() => onOpenAddTransaction('expense')}
              className="px-3.5 py-2.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowDownRight size={15} className="stroke-[2.5]" />
              <span>- Saída (Pix / Débito)</span>
            </button>

            <button
              type="button"
              onClick={() => onOpenAddTransaction('income')}
              className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowUpRight size={15} className="stroke-[2.5]" />
              <span>+ Entrada / Depósito</span>
            </button>

            <button
              type="button"
              onClick={() => onOpenAddTransaction('transfer')}
              className="px-3 py-2.5 bg-slate-50 dark:bg-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-700 text-slate-800 dark:text-slate-200 border border-slate-200/90 dark:border-zinc-700 rounded-xl text-xs font-semibold shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
              title="Transferência entre contas próprias"
            >
              <ArrowLeftRight size={14} />
              <span className="hidden sm:inline">Transferir</span>
            </button>

            <button
              type="button"
              onClick={onOpenAddAccount}
              className="px-3.5 py-2.5 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={15} className="stroke-[2.5]" />
              <span className="hidden sm:inline">Nova Conta</span>
            </button>
          </div>
        </div>

        {/* Overview Header with Gráfico / Valores Switch and Period selector */}
        <div className="pt-4 border-t border-slate-100 dark:border-zinc-800/80">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-5">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
                  Overview
                </h3>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-200/50 dark:border-purple-800/40">
                  {periodFilter === '3m' ? 'Últimos 3 Meses' : periodFilter === '12m' ? 'Últimos 12 Meses' : periodFilter === 'all' ? 'Histórico Completo' : 'Últimos 6 Meses'}
                </span>
              </div>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
                {overviewMode === 'chart' 
                  ? 'Acompanhe quanto entrou e quanto saiu a cada mês' 
                  : 'Demonstrativo e análise detalhada dos valores por mês'}
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Month Navigation for Quick browsing past months ("caso a pessoa queira puxar antes") */}
              <div className="flex items-center p-1 bg-slate-100 dark:bg-zinc-800 rounded-xl border border-slate-200/60 dark:border-zinc-700/60">
                <button
                  type="button"
                  onClick={handlePrevMonth}
                  title="Mês Anterior"
                  className="p-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-zinc-700 transition-all cursor-pointer"
                >
                  <ChevronLeft size={15} />
                </button>

                <span className="px-2 text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 select-none capitalize">
                  <Calendar size={13} className="text-purple-600 dark:text-purple-400" />
                  {monthLabel}
                </span>

                <button
                  type="button"
                  onClick={handleNextMonth}
                  disabled={isCurrentMonth || isFutureMonth}
                  title={isCurrentMonth ? 'Você já está no mês atual' : 'Próximo Mês'}
                  className={`p-1.5 rounded-lg transition-all ${
                    isCurrentMonth || isFutureMonth
                      ? 'text-slate-300 dark:text-zinc-600 cursor-not-allowed opacity-40'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-zinc-700 cursor-pointer'
                  }`}
                >
                  <ChevronRight size={15} />
                </button>
              </div>

              {/* Quick Jump back to current month if viewing history */}
              {!isCurrentMonth && (
                <button
                  type="button"
                  onClick={() => onMonthChange(realCurrentMonth)}
                  className="px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/50 text-purple-700 dark:text-purple-300 rounded-xl text-xs font-bold border border-purple-200/80 dark:border-purple-800/60 transition-all cursor-pointer"
                >
                  Voltar ao Mês Atual
                </button>
              )}

              {/* Toggle Gráfico / Valores */}
              <div className="flex items-center p-1 bg-slate-100 dark:bg-zinc-800 rounded-xl border border-slate-200/60 dark:border-zinc-700/60">
                <button
                  type="button"
                  onClick={() => setOverviewMode('chart')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    overviewMode === 'chart'
                      ? 'bg-white dark:bg-zinc-900 text-purple-700 dark:text-purple-400 shadow-2xs'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <BarChart3 size={14} />
                  <span>Gráfico</span>
                </button>

                <button
                  type="button"
                  onClick={() => setOverviewMode('values')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    overviewMode === 'values'
                      ? 'bg-white dark:bg-zinc-900 text-purple-700 dark:text-purple-400 shadow-2xs'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <TableIcon size={14} />
                  <span>Valores</span>
                </button>
              </div>

              {/* Period Dropdown */}
              <select
                value={periodFilter}
                onChange={(e) => setPeriodFilter(e.target.value as any)}
                aria-label="Filtrar período do overview"
                className="px-3 py-1.5 bg-slate-50 dark:bg-zinc-800 border border-slate-200/90 dark:border-zinc-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
              >
                <option value="6m">Últimos 6 meses</option>
                <option value="3m">Últimos 3 meses</option>
                <option value="12m">Últimos 12 meses (1 ano)</option>
                <option value="all">Todo o Histórico</option>
              </select>
            </div>
          </div>

          {/* MAIN OVERVIEW CONTENT: CHART OR VALUES */}
          <AnimatePresence mode="wait">
            {overviewMode === 'chart' ? (
              <motion.div
                key="chart"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Bar Chart Container */}
                <div className="w-full h-64 sm:h-72 pt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={chartData}
                      margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                      barGap={6}
                    >
                      <CartesianGrid 
                        strokeDasharray="4 4" 
                        vertical={false} 
                        stroke="#E2E8F0" 
                        className="dark:opacity-15"
                      />
                      <XAxis 
                        dataKey="label" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 600 }}
                        dy={8}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94A3B8', fontSize: 11 }}
                        tickFormatter={(val) => {
                          if (val >= 1000000) return `${(val / 1000000).toFixed(1)}M`;
                          if (val >= 1000) return `${(val / 1000).toFixed(0)}k`;
                          return `${val}`;
                        }}
                      />
                      <RechartsTooltip 
                        cursor={{ fill: 'rgba(0, 0, 0, 0.03)' }}
                        content={({ active, payload, label }) => {
                          if (active && payload && payload.length) {
                            const inc = Number(payload.find((p: any) => p.dataKey === 'income')?.value || 0);
                            const exp = Number(payload.find((p: any) => p.dataKey === 'expense')?.value || 0);
                            const itemData = chartData.find(d => d.label === label);
                            return (
                              <div className="bg-slate-900 dark:bg-zinc-950 text-white p-3.5 rounded-2xl shadow-xl border border-slate-800 text-xs space-y-2 min-w-[190px]">
                                <p className="font-bold text-slate-300 border-b border-slate-800 pb-1.5 capitalize">
                                  {itemData?.fullLabel || label}
                                </p>
                                <div className="flex items-center justify-between gap-3 text-slate-200">
                                  <div className="flex items-center gap-1.5">
                                    <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-white" />
                                    <span>Entrada (Quanto entrou):</span>
                                  </div>
                                  <span className="font-bold tabular-nums text-white">+{formatCurrency(inc)}</span>
                                </div>
                                <div className="flex items-center justify-between gap-3 text-purple-300">
                                  <div className="flex items-center gap-1.5">
                                    <span className="w-2.5 h-2.5 rounded-full bg-[#8B5CF6]" />
                                    <span>Saída (Quanto saiu):</span>
                                  </div>
                                  <span className="font-bold tabular-nums text-purple-200">-{formatCurrency(exp)}</span>
                                </div>
                                <div className="flex items-center justify-between gap-3 pt-1.5 border-t border-slate-800 text-slate-400">
                                  <span className="font-semibold">Saldo Líquido:</span>
                                  <span className={`font-black tabular-nums ${inc - exp >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {formatCurrency(inc - exp)}
                                  </span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      {/* Entrada Bar: Dark Slate / Black rounded pill */}
                      <Bar 
                        dataKey="income" 
                        name="Entrada (Quanto entrou)" 
                        fill="#0F172A" 
                        radius={[8, 8, 8, 8]} 
                        maxBarSize={22}
                        className="dark:fill-slate-200"
                      />
                      {/* Saída Bar: Bright Purple / Violet rounded pill */}
                      <Bar 
                        dataKey="expense" 
                        name="Saída (Quanto saiu)" 
                        fill="#8B5CF6" 
                        radius={[8, 8, 8, 8]} 
                        maxBarSize={22} 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Legend */}
                <div className="flex items-center justify-center gap-6 pt-1 text-xs font-semibold text-slate-600 dark:text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#0F172A] dark:bg-white" />
                    <span>Entrada (Quanto entrou)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#8B5CF6]" />
                    <span>Saída (Quanto saiu)</span>
                  </div>
                </div>
              </motion.div>
            ) : (
              /* VALUES VIEW (Detailed and Fixed Breakdown) */
              <motion.div
                key="values"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Consolidated Summary Banner */}
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-900/10 via-slate-50 to-slate-100 dark:from-purple-950/20 dark:via-zinc-900/60 dark:to-zinc-900 border border-purple-200/50 dark:border-purple-900/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-purple-700 dark:text-purple-400">
                        Resumo do Período ({periodFilter === '3m' ? 'Últimos 3 Meses' : periodFilter === '12m' ? 'Últimos 12 Meses' : periodFilter === 'all' ? 'Histórico Completo' : 'Últimos 6 Meses'})
                      </span>
                    </div>
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mt-0.5">
                      {chartData.reduce((s, d) => s + (d.count || 0), 0)} movimentações no período selecionado
                    </p>
                  </div>

                  <div className="flex items-center gap-3 sm:gap-6 flex-wrap">
                    <div>
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block">Total Entradas (Quanto entrou)</span>
                      <span className="text-base sm:text-lg font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                        +{formatCurrency(selectedPeriodTotals.income)}
                      </span>
                    </div>

                    <div className="w-px h-8 bg-slate-200 dark:bg-zinc-700 hidden sm:block" />

                    <div>
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block">Total Saídas (Quanto saiu)</span>
                      <span className="text-base sm:text-lg font-black text-rose-600 dark:text-rose-400 tabular-nums">
                        -{formatCurrency(selectedPeriodTotals.expense)}
                      </span>
                    </div>

                    <div className="w-px h-8 bg-slate-200 dark:bg-zinc-700 hidden sm:block" />

                    <div>
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block">Saldo Líquido</span>
                      <span className={`text-base sm:text-lg font-black tabular-nums ${
                        (selectedPeriodTotals.income - selectedPeriodTotals.expense) >= 0 
                          ? 'text-emerald-600 dark:text-emerald-400' 
                          : 'text-rose-600 dark:text-rose-400'
                      }`}>
                        {formatCurrency(selectedPeriodTotals.income - selectedPeriodTotals.expense)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Breakdown by Payment/Transaction Method for Month View */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-1">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200/70 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Pix Recebido</span>
                    <p className="text-xs sm:text-sm font-bold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
                      +{formatCurrency(monthlyTypeBreakdown.pixIn)}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200/70 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Depósitos</span>
                    <p className="text-xs sm:text-sm font-bold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
                      +{formatCurrency(monthlyTypeBreakdown.deposits)}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200/70 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Pix Enviado</span>
                    <p className="text-xs sm:text-sm font-bold text-purple-600 dark:text-purple-400 tabular-nums mt-0.5">
                      -{formatCurrency(monthlyTypeBreakdown.pixOut)}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200/70 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Débito em Conta</span>
                    <p className="text-xs sm:text-sm font-bold text-purple-600 dark:text-purple-400 tabular-nums mt-0.5">
                      -{formatCurrency(monthlyTypeBreakdown.debits)}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200/70 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Dinheiro Gasto</span>
                    <p className="text-xs sm:text-sm font-bold text-amber-600 dark:text-amber-400 tabular-nums mt-0.5">
                      -{formatCurrency(monthlyTypeBreakdown.cash)}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-200/70 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Transf. Internas</span>
                    <p className="text-xs sm:text-sm font-bold text-blue-600 dark:text-blue-400 tabular-nums mt-0.5">
                      {formatCurrency(monthlyTypeBreakdown.transfersIn)}
                    </p>
                  </div>
                </div>

                {/* Monthly Cards Breakdown */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
                  {chartData.map((item, idx) => {
                    const net = item.income - item.expense;
                    const hasActivity = item.income > 0 || item.expense > 0;
                    return (
                      <div 
                        key={idx}
                        className={`p-4 rounded-2xl border space-y-2.5 transition-all ${
                          item.isSelected 
                            ? 'bg-purple-50/50 dark:bg-purple-950/20 border-purple-300 dark:border-purple-800/80 shadow-xs' 
                            : 'bg-slate-50 dark:bg-zinc-800/60 border-slate-200/70 dark:border-zinc-700/60 hover:border-purple-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 capitalize">
                              {item.fullLabel || item.label}
                            </span>
                            {item.isSelected && (
                              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-600 text-white">
                                Selecionado
                              </span>
                            )}
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            !hasActivity
                              ? 'bg-slate-100 text-slate-500 dark:bg-zinc-700/50 dark:text-slate-400'
                              : net >= 0 
                                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' 
                                : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
                          }`}>
                            {!hasActivity ? 'Sem Movimento' : net >= 0 ? 'Superávit' : 'Déficit'}
                          </span>
                        </div>

                        <div className="space-y-1.5 text-xs">
                          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                            <span className="flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-[#0F172A] dark:bg-white" />
                              Entrada (Quanto entrou):
                            </span>
                            <span className="font-bold text-slate-900 dark:text-white tabular-nums">
                              +{formatCurrency(item.income)}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                            <span className="flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-[#8B5CF6]" />
                              Saída (Quanto saiu):
                            </span>
                            <span className="font-bold text-purple-600 dark:text-purple-400 tabular-nums">
                              -{formatCurrency(item.expense)}
                            </span>
                          </div>

                          <div className="flex items-center justify-between pt-1.5 border-t border-slate-200/60 dark:border-zinc-700">
                            <span className="font-semibold text-slate-700 dark:text-slate-300">Resultado Líquido:</span>
                            <span className={`font-bold tabular-nums ${net >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                              {formatCurrency(net)}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* TWO SIGNATURE CARDS: ENTRADA & SAÍDA (QUANTO ENTROU & QUANTO SAIU) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          
          {/* ENTRADA CARD (Dark Navy/Black Gradient with Down Arrow) */}
          <div className="relative overflow-hidden rounded-[26px] p-5 sm:p-6 bg-gradient-to-br from-[#0B091F] via-[#141233] to-[#0A081D] text-white shadow-md">
            {/* Concentric circles and arrow watermark */}
            <div className="absolute right-3 bottom-0 w-36 h-36 border border-white/5 rounded-full pointer-events-none" />
            <div className="absolute right-8 bottom-0 w-24 h-24 border border-white/5 rounded-full pointer-events-none" />
            <div className="absolute right-4 bottom-2 text-white/[0.08] pointer-events-none select-none">
              <ArrowDown size={110} strokeWidth={2.5} />
            </div>

            <div className="relative z-10 flex flex-col justify-between h-full min-h-[120px]">
              {/* White badge with down arrow */}
              <div className="w-9 h-9 rounded-full bg-white text-[#0B091F] flex items-center justify-center shadow-md">
                <ArrowDown size={18} className="stroke-[2.8]" />
              </div>

              <div className="mt-6 space-y-0.5">
                <span className="text-xs font-bold text-slate-300">
                  Entrada (Quanto entrou)
                </span>
                <p className="text-2xl sm:text-3xl font-black text-white tracking-tight tabular-nums">
                  +{formatCurrency(monthlyIncomes)}
                </p>
                <p className="text-[11px] text-slate-400">
                  {monthTransactions.filter(t => ['pix_in', 'deposito', 'transferencia_entrada'].includes(t.type)).length} entradas em {monthLabel}
                </p>
              </div>
            </div>
          </div>

          {/* SAÍDA CARD (Bright Purple/Violet Gradient with Up Arrow) */}
          <div className="relative overflow-hidden rounded-[26px] p-5 sm:p-6 bg-gradient-to-br from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] text-white shadow-md">
            {/* Concentric circles and arrow watermark */}
            <div className="absolute right-3 bottom-0 w-36 h-36 border border-white/15 rounded-full pointer-events-none" />
            <div className="absolute right-8 bottom-0 w-24 h-24 border border-white/15 rounded-full pointer-events-none" />
            <div className="absolute right-4 bottom-2 text-white/15 pointer-events-none select-none">
              <ArrowUp size={110} strokeWidth={2.5} />
            </div>

            <div className="relative z-10 flex flex-col justify-between h-full min-h-[120px]">
              {/* White badge with up arrow */}
              <div className="w-9 h-9 rounded-full bg-white text-[#7C3AED] flex items-center justify-center shadow-md">
                <ArrowUp size={18} className="stroke-[2.8]" />
              </div>

              <div className="mt-6 space-y-0.5">
                <span className="text-xs font-bold text-purple-100">
                  Saída (Quanto saiu)
                </span>
                <p className="text-2xl sm:text-3xl font-black text-white tracking-tight tabular-nums">
                  -{formatCurrency(monthlyDebitsPix)}
                </p>
                <p className="text-[11px] text-purple-200">
                  {monthTransactions.filter(t => ['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(t.type)).length} saídas em {monthLabel}
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Month Navigator Header (History & Current Month only) */}
      <div className="flex items-center justify-between bg-white dark:bg-zinc-900 p-3 sm:px-4 rounded-2xl border border-slate-200/90 dark:border-zinc-800 shadow-xs">
        <div className="flex items-center gap-2">
          <Calendar size={16} className="text-emerald-500" />
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 capitalize">
              Extrato: {monthLabel}
            </span>
            {isCurrentMonth ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                Mês Atual (Tempo Real)
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-400">
                Histórico Passado
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handlePrevMonth}
            className="px-2.5 py-1 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1"
            title="Ver extrato do mês anterior"
          >
            ← Anterior
          </button>
          
          {!isCurrentMonth && (
            <button
              type="button"
              onClick={() => onMonthChange(realCurrentMonth)}
              className="px-2.5 py-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 rounded-lg hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors cursor-pointer"
            >
              Voltar ao Mês Atual
            </button>
          )}

          <button
            type="button"
            onClick={handleNextMonth}
            disabled={isCurrentMonth}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
              isCurrentMonth
                ? 'text-slate-300 dark:text-slate-600 bg-slate-50 dark:bg-white/5 cursor-not-allowed opacity-50'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer'
            }`}
            title={isCurrentMonth ? 'Não é possível avançar: o saldo bancário reflete apenas o momento atual e histórico.' : 'Próximo mês'}
          >
            Próximo →
          </button>
        </div>
      </div>

      {/* KPI Top Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        
        {/* Total Available Balance */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Saldo Atual em Contas</span>
            </div>
            <div className="w-7 h-7 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Wallet size={14} />
            </div>
          </div>
          <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {formatCurrency(totalBalance)}
          </p>
          <div className="flex items-center justify-between mt-1 text-[11px] text-slate-400 dark:text-slate-500">
            <span>{accounts.filter(a => a.includeInTotal).length} contas ativas</span>
            <span className="font-medium text-emerald-600 dark:text-emerald-400">Tempo real</span>
          </div>
        </div>

        {/* Monthly Debits & Pix Out */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
            <span className="text-xs font-semibold">Gastos Pix / Débito (Mês)</span>
            <div className="w-7 h-7 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
              <ArrowDownRight size={14} />
            </div>
          </div>
          <p className="text-xl sm:text-2xl font-black text-rose-600 dark:text-rose-400 tracking-tight">
            {formatCurrency(monthlyDebitsPix)}
          </p>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
            {monthTransactions.filter(t => ['pix_out', 'debito', 'dinheiro_gasto'].includes(t.type)).length} movimentações no mês
          </p>
        </div>

        {/* Monthly Incomes / Pix In */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
            <span className="text-xs font-semibold">Entradas / Depósitos (Mês)</span>
            <div className="w-7 h-7 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <ArrowUpRight size={14} />
            </div>
          </div>
          <p className="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-tight">
            {formatCurrency(monthlyIncomes)}
          </p>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
            Depósitos e Pix recebidos
          </p>
        </div>

        {/* Liquidity Post-Cards */}
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1.5">
            <span className="text-xs font-semibold">Saldo pós-faturas do Mês</span>
            <div className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold ${
              projectedRemainingAfterCards >= 0 
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400' 
                : 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400'
            }`}>
              <DollarSign size={14} />
            </div>
          </div>
          <p className={`text-xl sm:text-2xl font-black tracking-tight ${
            projectedRemainingAfterCards >= 0 
              ? 'text-slate-900 dark:text-white' 
              : 'text-amber-600 dark:text-amber-400'
          }`}>
            {formatCurrency(projectedRemainingAfterCards)}
          </p>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
            Subtraindo {formatCurrency(pendingCardBills)} em cartões
          </p>
        </div>
      </div>

      {/* Bank Accounts Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 size={16} className="text-emerald-500" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-white tracking-tight">
              Minhas Contas Bancárias & Carteiras ({accounts.length})
            </h2>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-200/60 dark:border-emerald-800/40">
              Total: {formatCurrency(totalBalance)}
            </span>
          </div>
          <button
            type="button"
            onClick={onOpenAddAccount}
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer flex items-center gap-1"
          >
            <Plus size={14} />
            <span>Adicionar Conta</span>
          </button>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {accounts.map((account) => {
            return (
              <motion.div
                key={account.id}
                whileHover={{ y: -2 }}
                className="relative rounded-3xl p-5 bg-white dark:bg-zinc-900 border border-slate-200/90 dark:border-zinc-800 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group"
              >
                {/* Decorative top accent glow */}
                <div 
                  className="absolute top-0 inset-x-0 h-1.5" 
                  style={{ backgroundColor: account.color }}
                />

                {/* Account Top Row */}
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div 
                        className="w-9 h-9 rounded-2xl flex items-center justify-center font-bold text-white shadow-2xs shrink-0 text-xs"
                        style={{ backgroundColor: account.color }}
                      >
                        {account.accountType === 'dinheiro' ? <Banknote size={16} /> : account.institution.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                            {account.name}
                          </h3>
                          {account.isDefault && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300">
                              Padrão
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 dark:text-slate-500 capitalize">
                          {account.accountType === 'corrente' && 'Conta Corrente'}
                          {account.accountType === 'pagamentos' && 'Conta Pagamentos / Digital'}
                          {account.accountType === 'poupanca' && 'Poupança'}
                          {account.accountType === 'dinheiro' && 'Dinheiro Físico'}
                          {account.accountType === 'investimento' && 'Investimentos'}
                          {account.accountType === 'outros' && 'Outro'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenEditAccount(account)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                      title="Editar conta"
                    >
                      <Edit2 size={14} />
                    </button>
                  </div>

                  {/* Current Balance */}
                  <div className="mt-4">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 dark:text-slate-500">
                      Saldo Disponível
                    </span>
                    <p className={`text-2xl font-black tracking-tight mt-0.5 ${
                      account.currentBalance >= 0 ? 'text-slate-900 dark:text-white' : 'text-rose-600 dark:text-rose-400'
                    }`}>
                      {formatCurrency(account.currentBalance)}
                    </p>
                  </div>
                </div>

                {/* Pix Key & Bottom Quick Actions */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-white/[0.06] space-y-2.5">
                  {account.pixKey && (
                    <div className="flex items-center justify-between text-[11px] bg-slate-50 dark:bg-black/20 p-2 rounded-xl border border-slate-200/60 dark:border-white/[0.04]">
                      <span className="text-slate-500 dark:text-slate-400 truncate flex items-center gap-1">
                        <QrCode size={12} className="text-emerald-500" />
                        Pix: <strong className="text-slate-800 dark:text-slate-200 font-mono">{account.pixKey}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopyPix(account.pixKey)}
                        className="text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors cursor-pointer p-0.5"
                        title="Copiar Chave Pix"
                      >
                        {copiedPixKey === account.pixKey ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                      </button>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onOpenAddTransaction('expense', account.id)}
                      className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-200 rounded-xl text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <ArrowDownRight size={13} className="text-rose-500" />
                      <span>- Gasto</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenAddTransaction('income', account.id)}
                      className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-200 rounded-xl text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <ArrowUpRight size={13} className="text-emerald-500" />
                      <span>+ Entrada</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenAddTransaction('adjust', account.id)}
                      className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-600 dark:text-slate-300 rounded-xl text-[11px] font-semibold transition-colors cursor-pointer flex items-center justify-center"
                      title="Ajustar saldo desta conta"
                    >
                      <Sliders size={13} />
                    </button>
                  </div>
                </div>

              </motion.div>
            );
          })}

          {/* Quick Add Account Card */}
          <button
            type="button"
            onClick={onOpenAddAccount}
            className="min-h-[220px] rounded-3xl border-2 border-dashed border-slate-200 dark:border-white/10 hover:border-emerald-500/50 hover:bg-emerald-50/20 dark:hover:bg-emerald-950/10 p-5 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group select-none"
          >
            <div className="w-11 h-11 rounded-2xl bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-400 group-hover:bg-emerald-500 group-hover:text-white flex items-center justify-center transition-all shadow-2xs">
              <Plus size={20} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Cadastrar Outra Conta
              </p>
              <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                Nubank, Inter, Itaú, Mercado Pago ou Dinheiro
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Transactions History (Extrato) */}
      <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-slate-200/90 dark:border-zinc-800 shadow-xs overflow-hidden">
        
        {/* Extrato Header & Filters */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-zinc-800/80 space-y-3.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">
                Extrato da Carteira & Movimentações
              </h2>
              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                Histórico detalhado de Pix, compras no débito, dinheiro e depósitos
              </p>
            </div>

            {/* Account Selector Dropdown */}
            <div className="flex items-center gap-2">
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-[#2C2C2E] border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 font-semibold cursor-pointer"
              >
                <option value="all">Todas as Contas</option>
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => onOpenAddTransaction('expense')}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
              >
                <Plus size={14} />
                <span>Novo</span>
              </button>
            </div>
          </div>

          {/* Search and Type Filter Pills */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por descrição, lugar, valor..."
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Type Filters */}
            <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              {[
                { id: 'all', label: 'Todos' },
                { id: 'pix', label: 'Pix' },
                { id: 'debito', label: 'Débito' },
                { id: 'dinheiro', label: 'Dinheiro' },
                { id: 'saidas', label: 'Saídas' },
                { id: 'entradas', label: 'Entradas' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  type="button"
                  onClick={() => setSelectedTypeFilter(filter.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                    selectedTypeFilter === filter.id
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-2xs font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Transactions List */}
        {filteredTransactions.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-white/10 text-slate-400 mx-auto flex items-center justify-center mb-3">
              <Wallet size={24} />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Nenhuma movimentação encontrada
            </h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-sm mx-auto">
              {searchTerm 
                ? 'Nenhum lançamento corresponde ao termo buscado.'
                : 'Registre seus gastos no Pix, Débito ou entradas para atualizar seu saldo.'}
            </p>
            <button
              type="button"
              onClick={() => onOpenAddTransaction('expense')}
              className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={14} />
              <span>Registrar Primeiro Gasto</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-white/[0.05]">
            {filteredTransactions.map((tx) => {
              const account = accounts.find(a => a.id === tx.accountId);
              const isExit = ['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(tx.type);
              const categoryInfo = CATEGORY_LABELS[tx.category] || { label: tx.category, icon: '📦' };

              return (
                <div
                  key={tx.id}
                  className="p-3.5 sm:p-4 hover:bg-slate-50/80 dark:hover:bg-white/[0.02] transition-colors flex items-center justify-between gap-3 group"
                >
                  {/* Left: Type Icon & Info */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs ${
                      tx.type === 'pix_out' ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400' :
                      tx.type === 'debito' ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400' :
                      tx.type === 'dinheiro_gasto' ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400' :
                      tx.type === 'transferencia_saida' || tx.type === 'transferencia_entrada' ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400' :
                      tx.type === 'ajuste' ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400' :
                      'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                    }`}>
                      {tx.type === 'pix_out' && <QrCode size={18} />}
                      {tx.type === 'pix_in' && <QrCode size={18} />}
                      {tx.type === 'debito' && <CreditCard size={18} />}
                      {tx.type === 'dinheiro_gasto' && <Banknote size={18} />}
                      {tx.type === 'deposito' && <ArrowUpRight size={18} />}
                      {tx.type === 'transferencia_saida' && <ArrowLeftRight size={18} />}
                      {tx.type === 'transferencia_entrada' && <ArrowLeftRight size={18} />}
                      {tx.type === 'ajuste' && <Sliders size={18} />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {tx.description}
                        </h4>
                        
                        {/* Type Badge */}
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                          tx.type === 'pix_out' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
                          tx.type === 'debito' ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400' :
                          tx.type === 'dinheiro_gasto' ? 'bg-teal-500/10 text-teal-600 dark:text-teal-400' :
                          tx.type === 'pix_in' || tx.type === 'deposito' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
                          'bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-400'
                        }`}>
                          {tx.type === 'pix_out' && 'Pix Pago'}
                          {tx.type === 'pix_in' && 'Pix Recebido'}
                          {tx.type === 'debito' && 'Débito'}
                          {tx.type === 'dinheiro_gasto' && 'Dinheiro'}
                          {tx.type === 'deposito' && 'Depósito'}
                          {tx.type === 'transferencia_saida' && 'Transferência (Saída)'}
                          {tx.type === 'transferencia_entrada' && 'Transferência (Entrada)'}
                          {tx.type === 'ajuste' && 'Ajuste'}
                        </span>
                      </div>

                      {/* Details row */}
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 dark:text-slate-500 mt-0.5 flex-wrap">
                        <span className="font-medium text-slate-600 dark:text-slate-300">
                          {account?.name || 'Conta'}
                        </span>
                        <span>•</span>
                        <span>{categoryInfo.icon} {categoryInfo.label}</span>
                        {tx.recipientOrPayer && (
                          <>
                            <span>•</span>
                            <span className="truncate">{tx.recipientOrPayer}</span>
                          </>
                        )}
                        <span>•</span>
                        <span>{new Date(tx.date + 'T12:00:00').toLocaleDateString('pt-BR')} {tx.time && `às ${tx.time}`}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Amount & Actions */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <p className={`text-sm font-black tracking-tight ${
                        isExit ? 'text-slate-900 dark:text-white' : 'text-emerald-600 dark:text-emerald-400'
                      }`}>
                        {isExit ? `- ${formatCurrency(tx.amount)}` : `+ ${formatCurrency(tx.amount)}`}
                      </p>
                      {tx.type === 'ajuste' && (
                        <span className="text-[10px] text-amber-500 font-medium">Conciliação</span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteTransaction(tx.id)}
                      className="p-1.5 text-slate-300 hover:text-rose-600 dark:text-slate-600 dark:hover:text-rose-400 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer opacity-0 group-hover:opacity-100"
                      title="Excluir movimentação"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
}
