import React, { useState, useEffect } from 'react';
import { X, CreditCard as CardIcon, DollarSign, Calendar, Sparkles, Trash2, Search, ChevronDown, Check } from 'lucide-react';
import { CreditCard } from '../types';
import { BankLogo } from './BankLogo';
import { CurrencyInput } from './CurrencyInput';

interface AddCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (cardData: Partial<CreditCard>) => void;
  editingCard?: CreditCard | null;
  onDelete?: (cardId: string) => void;
}

const ALL_BANKS = [
  { bank: 'Nubank', name: 'Nubank Ultravioleta', color: '#8A05BE', gradient: 'from-purple-950 via-purple-700 to-indigo-950' },
  { bank: 'Itaú', name: 'Itaú Black', color: '#EC7000', gradient: 'from-amber-800 via-orange-600 to-stone-950' },
  { bank: 'Inter', name: 'Inter Mastercard', color: '#FF7A00', gradient: 'from-orange-600 via-amber-500 to-yellow-600' },
  { bank: 'C6 Bank', name: 'C6 Carbon', color: '#242424', gradient: 'from-stone-900 via-neutral-800 to-black' },
  { bank: 'Bradesco', name: 'Bradesco Elo Nanquim', color: '#CC092F', gradient: 'from-rose-900 via-red-700 to-slate-950' },
  { bank: 'Santander', name: 'Santander Unlimited', color: '#EC0000', gradient: 'from-red-900 via-red-700 to-stone-950' },
  { bank: 'Banco do Brasil', name: 'BB Altus Visa', color: '#003882', gradient: 'from-blue-900 via-blue-800 to-slate-950' },
  { bank: 'Caixa', name: 'Caixa Visa Infinite', color: '#005CA9', gradient: 'from-blue-900 via-cyan-800 to-stone-950' },
  { bank: 'Mercado Pago', name: 'Mercado Pago Visa', color: '#00A650', gradient: 'from-teal-700 via-emerald-600 to-cyan-950' },
  { bank: 'XP', name: 'XP Visa Infinite', color: '#000000', gradient: 'from-zinc-950 via-neutral-900 to-black' },
  { bank: 'BTG Pactual', name: 'BTG Black', color: '#0B1E36', gradient: 'from-slate-950 via-blue-950 to-neutral-900' },
  { bank: 'PicPay', name: 'PicPay Card Black', color: '#11C76F', gradient: 'from-emerald-900 via-teal-700 to-slate-950' },
  { bank: 'PagBank', name: 'PagBank Visa', color: '#00A868', gradient: 'from-emerald-800 via-green-600 to-stone-950' },
  { bank: 'Neon', name: 'Neon Visa Platinum', color: '#00D1FF', gradient: 'from-cyan-900 via-blue-700 to-slate-950' },
  { bank: 'Sicredi', name: 'Sicredi Mastercard Black', color: '#004A26', gradient: 'from-emerald-950 via-green-800 to-slate-950' },
  { bank: 'Sicoob', name: 'Sicoobcard Black', color: '#003641', gradient: 'from-teal-950 via-emerald-900 to-slate-950' },
  { bank: 'Outro', name: 'Cartão de Crédito', color: '#3B82F6', gradient: 'from-blue-950 via-slate-900 to-slate-950' },
];

export function AddCardModal({ isOpen, onClose, onSave, editingCard, onDelete }: AddCardModalProps) {
  const [name, setName] = useState('');
  const [bank, setBank] = useState('');
  const [searchBank, setSearchBank] = useState('');
  const [lastDigits, setLastDigits] = useState('');
  const [limit, setLimit] = useState<number>(5000);
  const [closingDay, setClosingDay] = useState('8');
  const [dueDay, setDueDay] = useState('15');
  const [selectedTheme, setSelectedTheme] = useState(ALL_BANKS[0]);
  const [showAllBanks, setShowAllBanks] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSearchBank('');
      setShowAllBanks(false);
      if (editingCard) {
        setName(editingCard.name || '');
        setBank(editingCard.bank || '');
        setLastDigits(editingCard.lastDigits || '');
        setLimit(editingCard.limit || 5000);
        setClosingDay(String(editingCard.closingDay || '8'));
        setDueDay(String(editingCard.dueDay || '15'));

        const matchedPreset = ALL_BANKS.find(
          p => p.bank.toLowerCase() === (editingCard.bank || '').toLowerCase()
        );
        if (matchedPreset) {
          setSelectedTheme({
            ...matchedPreset,
            color: editingCard.color || matchedPreset.color,
            gradient: editingCard.gradient || matchedPreset.gradient,
          });
        } else {
          setSelectedTheme({
            bank: editingCard.bank || 'Outro',
            name: editingCard.name || 'Personalizado',
            color: editingCard.color || '#3b82f6',
            gradient: editingCard.gradient || 'from-blue-950 via-slate-900 to-slate-950',
          });
        }
      } else {
        setName('');
        setBank('');
        setLastDigits('');
        setLimit(5000);
        setClosingDay('8');
        setDueDay('15');
        setSelectedTheme(ALL_BANKS[0]);
      }
    }
  }, [isOpen, editingCard]);

  if (!isOpen) return null;

  const handleSelectPreset = (preset: typeof ALL_BANKS[0]) => {
    setBank(preset.bank);
    if (!name || name.trim() === '' || ALL_BANKS.some(b => b.name === name)) {
      setName(preset.name);
    }
    setSelectedTheme(preset);
  };

  const filteredBanks = ALL_BANKS.filter(b => 
    b.bank.toLowerCase().includes(searchBank.toLowerCase()) || 
    b.name.toLowerCase().includes(searchBank.toLowerCase())
  );

  const displayedBanks = searchBank ? filteredBanks : (showAllBanks ? ALL_BANKS : ALL_BANKS.slice(0, 8));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !bank.trim()) return;

    onSave({
      ...(editingCard ? { id: editingCard.id } : {}),
      name: name.trim(),
      bank: bank.trim(),
      lastDigits: lastDigits.trim() || undefined,
      limit: limit || 1000,
      closingDay: parseInt(closingDay, 10) || 8,
      dueDay: parseInt(dueDay, 10) || 15,
      color: selectedTheme.color,
      gradient: selectedTheme.gradient,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1C1C1E] rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-white/[0.12] max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <CardIcon size={18} />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {editingCard ? 'Editar Dados do Cartão' : 'Cadastrar Novo Cartão'}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {editingCard ? 'Altere limites, datas ou dados incorretos' : 'Adicione um novo cartão à sua carteira'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-white/10"
          >
            <X size={18} />
          </button>
        </div>

        {/* Bank Selection Section */}
        <div className="mt-4 bg-slate-50 dark:bg-white/5 p-3.5 rounded-2xl border border-slate-200/80 dark:border-white/10 space-y-2.5">
          <div className="flex items-center justify-between">
            <label className="font-bold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
              <span>Selecione a Instituição / Banco</span>
              {bank && (
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-md font-bold">
                  {bank}
                </span>
              )}
            </label>
            {!searchBank && (
              <button
                type="button"
                onClick={() => setShowAllBanks(!showAllBanks)}
                className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
              >
                {showAllBanks ? 'Mostrar menos' : `Ver todos (${ALL_BANKS.length})`}
              </button>
            )}
          </div>

          {/* Quick Bank Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchBank}
              onChange={(e) => setSearchBank(e.target.value)}
              placeholder="Buscar banco (Nubank, Itaú, Santander, Caixa...)"
              className="w-full pl-8 pr-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-slate-900 dark:text-white text-xs placeholder:text-slate-400 focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          {/* Grid of Bank Options */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 max-h-44 overflow-y-auto pr-1">
            {displayedBanks.map((preset) => {
              const isSelected = bank.toLowerCase() === preset.bank.toLowerCase();
              return (
                <button
                  key={preset.bank}
                  type="button"
                  onClick={() => handleSelectPreset(preset)}
                  className={`px-2 py-2 rounded-xl border flex items-center gap-2 transition-all text-xs font-semibold select-none cursor-pointer ${
                    isSelected
                      ? 'border-emerald-500 bg-emerald-500 text-white shadow-xs scale-[1.02]'
                      : 'border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-emerald-300 dark:hover:border-emerald-700'
                  }`}
                >
                  <BankLogo bankName={preset.bank} size={20} className="shrink-0" />
                  <span className="truncate text-left">{preset.bank}</span>
                  {isSelected && <Check size={12} className="ml-auto shrink-0 text-white" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Form Fields */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nome do Cartão *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Nubank Ultravioleta, Itaú Click..."
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Banco Emissor *
              </label>
              <input
                type="text"
                value={bank}
                onChange={(e) => setBank(e.target.value)}
                placeholder="Ex: Nubank, Itaú, Bradesco..."
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Últimos 4 Dígitos
              </label>
              <input
                type="text"
                maxLength={4}
                value={lastDigits}
                onChange={(e) => setLastDigits(e.target.value.replace(/\D/g, ''))}
                placeholder="Ex: 8492"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-slate-900 dark:text-white text-xs font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Limite Total
              </label>
              <CurrencyInput
                value={limit}
                onChange={setLimit}
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Dia Fechamento
              </label>
              <input
                type="number"
                min="1"
                max="31"
                value={closingDay}
                onChange={(e) => setClosingDay(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-slate-900 dark:text-white text-xs font-bold"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Dia Vencimento
              </label>
              <input
                type="number"
                min="1"
                max="31"
                value={dueDay}
                onChange={(e) => setDueDay(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-slate-900 dark:text-white text-xs font-bold"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 flex items-center justify-between gap-3 border-t border-slate-100 dark:border-white/[0.08]">
            {editingCard && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  onDelete(editingCard.id);
                  onClose();
                }}
                className="px-3 py-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl flex items-center gap-1.5 font-bold transition-colors cursor-pointer"
              >
                <Trash2 size={15} />
                <span>Excluir</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer"
              >
                {editingCard ? 'Atualizar Cartão' : 'Salvar Cartão'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}


