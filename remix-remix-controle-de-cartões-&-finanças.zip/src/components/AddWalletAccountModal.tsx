import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wallet, 
  Building2, 
  DollarSign, 
  CreditCard, 
  Sparkles, 
  Check, 
  Trash2,
  CheckCircle2
} from 'lucide-react';
import { WalletAccount, WalletAccountType } from '../types';
import { BANK_PRESETS, BankPreset } from '../data/initialWalletData';
import { formatCurrency } from '../utils/financeCalculations';
import { CurrencyInput } from './CurrencyInput';
import { triggerHaptic } from '../utils/haptics';

interface AddWalletAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (account: Partial<WalletAccount>) => void;
  onDelete?: (id: string) => void;
  editingAccount?: WalletAccount | null;
}

export function AddWalletAccountModal({
  isOpen,
  onClose,
  onSave,
  onDelete,
  editingAccount,
}: AddWalletAccountModalProps) {
  const [name, setName] = useState('');
  const [institution, setInstitution] = useState('Nubank');
  const [accountType, setAccountType] = useState<WalletAccountType>('corrente');
  const [initialBalance, setInitialBalance] = useState<number>(0);
  const [currentBalance, setCurrentBalance] = useState<number>(0);
  const [color, setColor] = useState('#820AD1');
  const [gradient, setGradient] = useState('from-purple-900 via-purple-700 to-indigo-900');
  const [pixKey, setPixKey] = useState('');
  const [includeInTotal, setIncludeInTotal] = useState(true);
  const [isDefault, setIsDefault] = useState(false);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editingAccount) {
      setName(editingAccount.name || '');
      setInstitution(editingAccount.institution || 'Nubank');
      setAccountType(editingAccount.accountType || 'corrente');
      setInitialBalance(editingAccount.initialBalance || 0);
      setCurrentBalance(editingAccount.currentBalance || 0);
      setColor(editingAccount.color || '#820AD1');
      setGradient(editingAccount.gradient || 'from-purple-900 via-purple-700 to-indigo-900');
      setPixKey(editingAccount.pixKey || '');
      setIncludeInTotal(editingAccount.includeInTotal !== false);
      setIsDefault(Boolean(editingAccount.isDefault));
      setNotes(editingAccount.notes || '');
    } else {
      // Default to first preset
      const preset = BANK_PRESETS[0];
      setName('Nubank (Conta Principal)');
      setInstitution(preset.institution);
      setAccountType(preset.accountType);
      setInitialBalance(0);
      setCurrentBalance(0);
      setColor(preset.color);
      setGradient(preset.gradient);
      setPixKey('');
      setIncludeInTotal(true);
      setIsDefault(false);
      setNotes('');
    }
  }, [editingAccount, isOpen]);

  if (!isOpen) return null;

  const handleSelectPreset = (preset: BankPreset) => {
    setInstitution(preset.institution);
    setAccountType(preset.accountType);
    setColor(preset.color);
    setGradient(preset.gradient);
    if (!name || name === 'Nubank (Conta Principal)' || BANK_PRESETS.some(p => p.name === name)) {
      setName(preset.name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    triggerHaptic(12);
    const parsedInitial = initialBalance || 0;
    const parsedCurrent = editingAccount 
      ? (currentBalance || 0)
      : parsedInitial;

    onSave({
      id: editingAccount?.id,
      name: name.trim(),
      institution: institution.trim(),
      accountType,
      initialBalance: parsedInitial,
      currentBalance: parsedCurrent,
      color,
      gradient,
      pixKey: pixKey.trim() || undefined,
      includeInTotal,
      isDefault,
      notes: notes.trim() || undefined,
      updatedAt: new Date().toISOString(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      <div className="bg-white dark:bg-[#1C1C1E] rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200/80 dark:border-white/[0.08] my-auto max-h-[92vh] flex flex-col justify-between overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 dark:border-white/[0.06] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold shadow-2xs">
              <Wallet size={18} />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">
                {editingAccount ? 'Editar Conta Bancária' : 'Nova Conta ou Carteira'}
              </h2>
              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                Cadastre suas contas para controlar o saldo real e compras no débito/Pix
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-3.5 space-y-4 text-xs overflow-y-auto pr-1 flex-1">
          
          {/* Preset Selector */}
          {!editingAccount && (
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Sparkles size={13} className="text-amber-500" />
                Selecione o Banco ou Instituição
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
                {BANK_PRESETS.map((preset) => {
                  const isSelected = institution === preset.institution;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className={`p-2 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2 ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30 text-slate-900 dark:text-white ring-1 ring-emerald-500'
                          : 'border-slate-200/80 dark:border-white/[0.08] bg-slate-50 dark:bg-white/[0.02] text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/[0.05]'
                      }`}
                    >
                      <span 
                        className="w-3 h-3 rounded-full shrink-0 shadow-2xs" 
                        style={{ backgroundColor: preset.color }}
                      />
                      <span className="text-[11px] font-bold truncate">{preset.institution}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Account Name */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nome da Conta / Identificação *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Nubank (Principal), Inter, Carteira de Dinheiro..."
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
            />
          </div>

          {/* Type & Balances Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Account Type */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Tipo de Conta
              </label>
              <select
                value={accountType}
                onChange={(e) => setAccountType(e.target.value as WalletAccountType)}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-[#2C2C2E] border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="corrente">Conta Corrente</option>
                <option value="pagamentos">Conta de Pagamentos / Digital</option>
                <option value="poupanca">Conta Poupança</option>
                <option value="dinheiro">Dinheiro Físico (Espécie)</option>
                <option value="investimento">Conta Investimentos</option>
                <option value="outros">Outro Tipo</option>
              </select>
            </div>

            {/* Initial / Current Balance */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {editingAccount ? 'Saldo Atual em Conta' : 'Saldo Inicial Atual'}
              </label>
              <CurrencyInput
                value={editingAccount ? currentBalance : initialBalance}
                onChange={(val) => {
                  if (editingAccount) {
                    setCurrentBalance(val);
                  } else {
                    setInitialBalance(val);
                  }
                }}
              />
            </div>
          </div>

          {/* Pix Key */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Chave Pix vinculada a esta conta (opcional)
            </label>
            <input
              type="text"
              value={pixKey}
              onChange={(e) => setPixKey(e.target.value)}
              placeholder="Ex: seu-pix@email.com, celular ou CPF"
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Color Tag Selection */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Cor do Banco / Cartão
            </label>
            <div className="flex items-center gap-2 flex-wrap">
              {[
                { c: '#820AD1', g: 'from-purple-900 via-purple-700 to-indigo-900' },
                { c: '#FF7A00', g: 'from-orange-700 via-orange-500 to-amber-900' },
                { c: '#EC7000', g: 'from-blue-900 via-amber-700 to-orange-600' },
                { c: '#CC092F', g: 'from-red-900 via-red-700 to-rose-900' },
                { c: '#11C76F', g: 'from-emerald-800 via-green-600 to-teal-900' },
                { c: '#00A650', g: 'from-sky-700 via-blue-600 to-teal-800' },
                { c: '#005CA9', g: 'from-blue-900 via-sky-700 to-blue-950' },
                { c: '#10B981', g: 'from-emerald-800 via-teal-700 to-emerald-950' },
                { c: '#242424', g: 'from-zinc-900 via-stone-800 to-neutral-900' },
              ].map((item) => (
                <button
                  key={item.c}
                  type="button"
                  onClick={() => {
                    setColor(item.c);
                    setGradient(item.g);
                  }}
                  className={`w-7 h-7 rounded-xl transition-all cursor-pointer shadow-2xs ${
                    color === item.c ? 'ring-2 ring-offset-2 ring-emerald-500 scale-110' : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: item.c }}
                />
              ))}
            </div>
          </div>

          {/* Options: Include in Total & Set Default */}
          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 select-none cursor-pointer">
              <input
                type="checkbox"
                checked={includeInTotal}
                onChange={(e) => setIncludeInTotal(e.target.checked)}
                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
              />
              <span className="text-xs">
                Somar este saldo no <strong>Saldo Total Disponível</strong> da Carteira
              </span>
            </label>

            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 select-none cursor-pointer">
              <input
                type="checkbox"
                checked={isDefault}
                onChange={(e) => setIsDefault(e.target.checked)}
                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
              />
              <span className="text-xs">
                Definir como <strong>Conta Padrão</strong> para novos gastos Pix e Débito
              </span>
            </label>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Observações (opcional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Agência 0001, Conta 12345-6..."
              className="w-full px-3.5 py-2 bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-900 dark:text-white text-xs outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3.5 flex items-center justify-between border-t border-slate-100 dark:border-white/[0.06] shrink-0">
            {editingAccount && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  onDelete(editingAccount.id);
                  onClose();
                }}
                className="px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 size={14} />
                <span>Excluir Conta</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>

              <button
                type="submit"
                className="px-5 py-2.5 font-bold bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-xl shadow-xs transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                <Check size={14} />
                <span>{editingAccount ? 'Salvar Alterações' : 'Criar Conta'}</span>
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
}
