import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Edit2, 
  DollarSign, 
  Calendar, 
  Clock, 
  FileText, 
  Briefcase, 
  User, 
  Wallet,
  CheckCircle2
} from 'lucide-react';
import { FreelanceEntry, FreelanceCategory, FreelanceStatus, WalletAccount } from '../types';
import { FREELANCE_CATEGORY_CONFIG } from '../data/initialFreelanceData';
import { formatCurrency } from '../utils/financeCalculations';
import { CurrencyInput } from './CurrencyInput';
import { triggerHaptic } from '../utils/haptics';

interface AddFreelanceEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entryData: Omit<FreelanceEntry, 'id' | 'createdAt'>, editId?: string) => void;
  accounts: WalletAccount[];
  editingEntry?: FreelanceEntry | null;
  currentMonth?: string;
}

export function AddFreelanceEntryModal({
  isOpen,
  onClose,
  onSave,
  accounts,
  editingEntry
}: AddFreelanceEntryModalProps) {
  const defaultAccount = accounts.find(a => a.isDefault) || accounts[0];

  const [title, setTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [category, setCategory] = useState<FreelanceCategory>('design');
  const [amount, setAmount] = useState<number>(0);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState(new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
  const [status, setStatus] = useState<FreelanceStatus>('recebido');
  const [accountId, setAccountId] = useState(defaultAccount?.id || '');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editingEntry) {
      setTitle(editingEntry.title);
      setClientName(editingEntry.clientName || '');
      setCategory(editingEntry.category);
      setAmount(editingEntry.amount || 0);
      setDate(editingEntry.date);
      setTime(editingEntry.time || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
      setStatus(editingEntry.status);
      setAccountId(editingEntry.accountId || defaultAccount?.id || '');
      setNotes(editingEntry.notes || '');
    } else {
      setTitle('');
      setClientName('');
      setCategory('design');
      setAmount(0);
      setDate(new Date().toISOString().split('T')[0]);
      setTime(new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
      setStatus('recebido');
      setAccountId(defaultAccount?.id || accounts[0]?.id || '');
      setNotes('');
    }
  }, [editingEntry, isOpen, defaultAccount, accounts]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || amount <= 0) return;

    triggerHaptic(12);
    const defaultTitle = title.trim() || `Serviço ${FREELANCE_CATEGORY_CONFIG[category]?.label || 'Freelance'}`;
    onSave({
      title: defaultTitle,
      clientName: clientName.trim() || undefined,
      category,
      amount,
      date,
      time: time || undefined,
      status,
      accountId: accountId || accounts[0]?.id || '',
      notes: notes.trim() || undefined,
    }, editingEntry?.id);

    onClose();
  };

  const selectedAccount = accounts.find(a => a.id === accountId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-[#1C1C1E] border border-slate-200/80 dark:border-white/[0.1] rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-white/[0.08] bg-slate-50/50 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              {editingEntry ? <Edit2 size={18} /> : <Plus size={20} />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {editingEntry ? 'Editar Entrada de Freelance' : 'Nova Entrada / Receita Freela'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Registrar pagamento de projeto ou serviço avulso
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          
          {/* Title & Client */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Título do Serviço / Projeto *
              </label>
              <div className="relative">
                <Briefcase size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="Ex: Criação de Identidade Visual, Edição de Reels, Site..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-black/20 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Cliente / Empresa (Opcional)
              </label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Ex: Studio Alpha, Marcos Oliveira, Loja X"
                  value={clientName}
                  onChange={e => setClientName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-black/20 text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Amount & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Valor Recebido *
              </label>
              <CurrencyInput
                value={amount}
                onChange={setAmount}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Categoria
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as FreelanceCategory)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#252528] text-sm text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                {Object.entries(FREELANCE_CATEGORY_CONFIG).map(([key, config]) => (
                  <option key={key} value={key}>
                    {config.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Account Sync Selection (Minha Carteira) */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-500/20 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                <Wallet size={14} className="text-emerald-600 dark:text-emerald-400" />
                Conta de Destino (Sincronizar com a Carteira)
              </label>
              <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-full bg-emerald-500/10">
                Crédito Automático
              </span>
            </div>

            <select
              value={accountId}
              onChange={e => setAccountId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-emerald-500/30 bg-white dark:bg-[#1C1C1E] text-sm font-semibold text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            >
              {accounts.map(acc => (
                <option key={acc.id} value={acc.id}>
                  {acc.name} ({acc.institution}) - Saldo atual: {formatCurrency(acc.currentBalance)}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80">
              O valor de <strong>{formatCurrency(amount)}</strong> será somado diretamente no saldo desta conta bancária.
            </p>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Data
              </label>
              <div className="relative">
                <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-black/20 text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Horário
              </label>
              <div className="relative">
                <Clock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="time"
                  value={time}
                  onChange={e => setTime(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-black/20 text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Observações (Opcional)
            </label>
            <div className="relative">
              <FileText size={16} className="absolute left-3 top-3 text-slate-400" />
              <textarea
                rows={2}
                placeholder="Detalhes sobre o escopo, link do drive, feedback..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-black/20 text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 resize-none"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-sm shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 size={16} />
              {editingEntry ? 'Salvar Alterações' : 'Confirmar Entrada & Creditar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
