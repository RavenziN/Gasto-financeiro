import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  CreditCard as CardIcon, 
  User, 
  Calendar, 
  Tag, 
  ChevronDown, 
  Delete, 
  Check, 
  ArrowRight,
  Sparkles,
  Info,
  CheckCircle2
} from 'lucide-react';
import { CreditCard, ExpenseItem, Person } from '../types';
import { BankLogo } from './BankLogo';
import { triggerHaptic } from '../utils/haptics';
import { formatCurrency, formatMonthDisplay } from '../utils/financeCalculations';

interface AddExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (expenseData: Partial<ExpenseItem>) => void;
  editingExpense: ExpenseItem | null;
  cards: CreditCard[];
  people: Person[];
  currentMonth: string;
  defaultPersonId?: string;
  defaultCardId?: string;
}

const CATEGORIES = [
  { id: 'alimentacao', label: 'Alimentação & Restaurante', icon: '🍔' },
  { id: 'mercado', label: 'Supermercado & Compras', icon: '🛒' },
  { id: 'transporte', label: 'Transporte & Combustível', icon: '🚗' },
  { id: 'eletronicos', label: 'Eletrônicos & Tecnologia', icon: '📱' },
  { id: 'vestuario', label: 'Vestuário & Moda', icon: '👕' },
  { id: 'saude', label: 'Saúde & Farmácia', icon: '💊' },
  { id: 'educacao', label: 'Educação & Cursos', icon: '📚' },
  { id: 'lazer', label: 'Lazer & Viagem', icon: '✈️' },
  { id: 'servicos', label: 'Assinaturas & Serviços', icon: '📺' },
  { id: 'casa', label: 'Casa & Decoração', icon: '🏠' },
  { id: 'outros', label: 'Outros / Diversos', icon: '🏷️' },
];

export function AddExpenseModal({
  isOpen,
  onClose,
  onSave,
  editingExpense,
  cards,
  people,
  currentMonth,
  defaultPersonId,
  defaultCardId,
}: AddExpenseModalProps) {
  // Step navigation: 1 = Valor, Cartão & Parcelamento, 2 = Detalhes (Descrição, Dono, Categoria)
  const [step, setStep] = useState<1 | 2>(1);

  // Form State
  const [amountCents, setAmountCents] = useState<number>(0);
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('outros');
  const [type, setType] = useState<'unica' | 'parcelada' | 'fixa'>('unica');
  const [cardId, setCardId] = useState('');
  const [personId, setPersonId] = useState('');
  const [totalInstallments, setTotalInstallments] = useState(2);
  const [currentInstallment, setCurrentInstallment] = useState(1);
  const [startMonthYear, setStartMonthYear] = useState(currentMonth);
  const [date, setDate] = useState('');
  const [notes, setNotes] = useState('');
  const [showCardPicker, setShowCardPicker] = useState(false);

  // Calculate actual numeric amount from cents
  const numericAmount = amountCents / 100;

  // Synchronize state on open or when editing
  useEffect(() => {
    if (isOpen) {
      if (editingExpense) {
        setAmountCents(Math.round((editingExpense.amount || 0) * 100));
        setDescription(editingExpense.description || '');
        setCategory(editingExpense.category || 'outros');
        setType(editingExpense.type || 'unica');
        setCardId(editingExpense.cardId || (cards[0]?.id || ''));
        setPersonId(editingExpense.personId || (people[0]?.id || ''));
        setTotalInstallments(editingExpense.totalInstallments || 2);
        setCurrentInstallment(editingExpense.currentInstallment || 1);
        setStartMonthYear(editingExpense.startMonthYear || currentMonth);
        setDate(editingExpense.date || `${currentMonth}-01`);
        setNotes(editingExpense.notes || '');
        setStep(1);
      } else {
        setAmountCents(0);
        setDescription('');
        setCategory('outros');
        setType('unica');
        setCardId(defaultCardId || (cards[0]?.id || ''));
        setPersonId(defaultPersonId || (people[0]?.id || ''));
        setTotalInstallments(2);
        setCurrentInstallment(1);
        setStartMonthYear(currentMonth);
        setDate(`${currentMonth}-01`);
        setNotes('');
        setStep(1);
      }
      setShowCardPicker(false);
    }
  }, [isOpen, editingExpense, currentMonth, defaultPersonId, defaultCardId, cards, people]);

  // Handle Keypad presses for Step 1
  const handleKeypadPress = (key: string) => {
    triggerHaptic(8);
    if (key === 'backspace') {
      setAmountCents((prev) => Math.floor(prev / 10));
    } else if (key === 'clear') {
      setAmountCents(0);
    } else {
      const digit = parseInt(key, 10);
      if (!isNaN(digit)) {
        setAmountCents((prev) => {
          if (prev > 99999999) return prev;
          return prev * 10 + digit;
        });
      }
    }
  };

  // Listen to physical keyboard on Step 1
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
        return;
      }
      if (step === 1) {
        if (e.key >= '0' && e.key <= '9') {
          handleKeypadPress(e.key);
        } else if (e.key === 'Backspace') {
          handleKeypadPress('backspace');
        } else if (e.key === 'Enter') {
          if (numericAmount > 0) {
            triggerHaptic(12);
            setStep(2);
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, step, numericAmount, onClose]);

  if (!isOpen) return null;

  const selectedCard = cards.find((c) => c.id === cardId) || cards[0];
  const selectedPerson = people.find((p) => p.id === personId) || people[0];

  // Advance to Step 2
  const handleContinueToStep2 = () => {
    if (numericAmount <= 0) {
      triggerHaptic(20);
      return;
    }
    triggerHaptic(10);
    setStep(2);
  };

  // Quick Direct Save from Step 1
  const handleQuickSaveDirect = () => {
    if (numericAmount <= 0) {
      triggerHaptic(20);
      return;
    }

    triggerHaptic(15);
    const defaultDesc = description.trim() || (type === 'parcelada' ? `Compra parcelada ${totalInstallments}x` : type === 'fixa' ? 'Assinatura / Fixo' : 'Gasto no Cartão');
    const payload: Partial<ExpenseItem> = {
      ...(editingExpense ? { id: editingExpense.id } : {}),
      description: defaultDesc,
      category,
      amount: numericAmount,
      type,
      cardId: cardId || undefined,
      personId: personId || undefined,
      startMonthYear,
      date,
      notes: notes.trim() || undefined,
    };

    if (type === 'parcelada') {
      const total = totalInstallments || 2;
      const curr = currentInstallment || 1;
      payload.totalInstallments = total;
      payload.currentInstallment = curr;
      payload.totalAmount = numericAmount * total;
    }

    onSave(payload);
    onClose();
  };

  // Submit complete expense
  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (numericAmount <= 0) {
      triggerHaptic(20);
      return;
    }

    triggerHaptic(15);
    const defaultDesc = description.trim() || (type === 'parcelada' ? `Compra parcelada ${totalInstallments}x` : type === 'fixa' ? 'Assinatura / Fixo' : 'Gasto no Cartão');
    const payload: Partial<ExpenseItem> = {
      ...(editingExpense ? { id: editingExpense.id } : {}),
      description: defaultDesc,
      category,
      amount: numericAmount,
      type,
      cardId: cardId || undefined,
      personId: personId || undefined,
      startMonthYear,
      date,
      notes: notes.trim() || undefined,
    };

    if (type === 'parcelada') {
      const total = totalInstallments || 2;
      const curr = currentInstallment || 1;
      payload.totalInstallments = total;
      payload.currentInstallment = curr;
      payload.totalAmount = numericAmount * total;
    }

    onSave(payload);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-[100] bg-slate-100 dark:bg-zinc-950 overflow-y-auto flex flex-col w-full h-full min-h-screen"
    >
      
      {/* Full-Screen Header with Circular Back Button */}
      <header className="sticky top-0 z-30 bg-white dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800 px-4 sm:px-6 py-3.5 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              if (step === 2) {
                setStep(1);
                triggerHaptic(8);
              } else {
                onClose();
              }
            }}
            className="w-10 h-10 rounded-full bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-xs"
            title={step === 2 ? "Voltar para valor" : "Voltar"}
          >
            <ArrowLeft size={18} className="stroke-[2.5]" />
          </button>

          <div>
            <h1 className="text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight">
              {editingExpense ? 'Editar Despesa' : 'Novo Lançamento'}
            </h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {step === 1 ? 'Etapa 1 de 2 • Valor, Cartão & Parcelas' : 'Etapa 2 de 2 • Detalhes & Categoria'}
            </p>
          </div>
        </div>

        {/* Progress Indicator Pill */}
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-zinc-800 px-3 py-1.5 rounded-full">
          <span className={`w-2 h-2 rounded-full transition-all ${step === 1 ? 'bg-indigo-600 dark:bg-indigo-400 w-5' : 'bg-emerald-500'}`} />
          <span className={`w-2 h-2 rounded-full transition-all ${step === 2 ? 'bg-indigo-600 dark:bg-indigo-400 w-5' : 'bg-slate-300 dark:bg-zinc-600'}`} />
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-between">
        
        {/* ========================================================================= */}
        {/* ETAPA 1: VALOR, CARTÃO E DURAÇÃO/PARCELAS (Inspirado na Tela de Referência) */}
        {/* ========================================================================= */}
        {step === 1 && (
          <div className="space-y-5">
            
            {/* Card / Bank Capsule Banner (Inspirado no Bloco "Home Loan" da Imagem) */}
            <div className="bg-white dark:bg-zinc-900 p-4 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs relative">
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-2">
                Cartão Selecionado
              </span>

              <button
                type="button"
                onClick={() => setShowCardPicker(!showCardPicker)}
                className="w-full flex items-center justify-between p-2 hover:bg-slate-50 dark:hover:bg-white/[0.04] rounded-2xl transition-all cursor-pointer select-none"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-white/10 flex items-center justify-center p-2 shrink-0">
                    <BankLogo bankName={selectedCard?.bank || selectedCard?.name} size={34} />
                  </div>
                  <div className="text-left truncate">
                    <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white truncate">
                      {selectedCard?.name || 'Selecione o Cartão'}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {selectedCard?.bank ? `Banco ${selectedCard.bank}` : 'Cartão de Crédito'}
                      {selectedCard?.limit ? ` • Limite ${formatCurrency(selectedCard.limit)}` : ''}
                    </p>
                  </div>
                </div>

                <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-white/10 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
                  <ChevronDown size={16} className={`transition-transform duration-200 ${showCardPicker ? 'rotate-180' : ''}`} />
                </div>
              </button>

              {/* Dropdown Card Picker */}
              {showCardPicker && (
                <div className="mt-3 p-1.5 bg-slate-50 dark:bg-[#202024] border border-slate-200 dark:border-white/15 rounded-2xl shadow-lg max-h-56 overflow-y-auto space-y-1">
                  {cards.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setCardId(c.id);
                        setShowCardPicker(false);
                        triggerHaptic(8);
                      }}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-colors cursor-pointer ${
                        cardId === c.id
                          ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 font-bold'
                          : 'hover:bg-white dark:hover:bg-white/[0.06] text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <BankLogo bankName={c.bank || c.name} size={28} />
                        <div className="text-left truncate">
                          <p className="text-xs font-bold truncate">{c.name}</p>
                          <p className="text-[10px] text-slate-400">{c.bank || 'Cartão'}</p>
                        </div>
                      </div>
                      {cardId === c.id && <Check size={16} className="text-indigo-600 dark:text-indigo-400 shrink-0" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Duration / Cobrança: À Vista vs Parcelado vs Fixo (Inspirado no bloco "Duration" da Imagem) */}
            <div className="bg-white dark:bg-zinc-900 p-4 sm:p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs space-y-3">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Tipo de Cobrança
              </span>

              {/* Mode Toggle Buttons */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => { setType('unica'); triggerHaptic(8); }}
                  className={`py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer text-center ${
                    type === 'unica'
                      ? 'border-2 border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200/70'
                  }`}
                >
                  À Vista
                </button>

                <button
                  type="button"
                  onClick={() => { setType('parcelada'); triggerHaptic(8); }}
                  className={`py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer text-center ${
                    type === 'parcelada'
                      ? 'border-2 border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200/70'
                  }`}
                >
                  Parcelado
                </button>

                <button
                  type="button"
                  onClick={() => { setType('fixa'); triggerHaptic(8); }}
                  className={`py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer text-center ${
                    type === 'fixa'
                      ? 'border-2 border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200/70'
                  }`}
                >
                  Assinatura / Fixo
                </button>
              </div>

              {/* Installment Pill Chips (Se for Parcelado) */}
              {type === 'parcelada' && (
                <div className="pt-2 border-t border-slate-100 dark:border-zinc-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Número de Parcelas</span>
                    <span className="font-black text-indigo-600 dark:text-indigo-400">{totalInstallments}x de {formatCurrency(numericAmount)}</span>
                  </div>

                  <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                    {[2, 3, 4, 5, 6, 8, 10, 12, 18, 24].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => { setTotalInstallments(num); triggerHaptic(6); }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-black shrink-0 transition-all cursor-pointer ${
                          totalInstallments === num
                            ? 'border-2 border-indigo-600 bg-indigo-600 text-white shadow-sm scale-105'
                            : 'bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200/80'
                        }`}
                      >
                        {num}x
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Big Amount Display (Hero Value Center) */}
            <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs text-center space-y-3">
              <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
                {type === 'parcelada' ? 'Valor de Cada Parcela' : 'Valor Total do Gasto'}
              </span>

              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-slate-900 dark:text-white tabular-nums">
                {formatCurrency(numericAmount)}
              </h1>

              {/* Quick Amount Presets */}
              <div className="flex items-center justify-center flex-wrap gap-1.5 pt-1">
                {[
                  { label: '+R$ 20', add: 2000 },
                  { label: '+R$ 50', add: 5000 },
                  { label: '+R$ 100', add: 10000 },
                  { label: '+R$ 200', add: 20000 },
                  { label: '+R$ 500', add: 50000 },
                ].map((chip) => (
                  <button
                    key={chip.label}
                    type="button"
                    onClick={() => {
                      triggerHaptic(8);
                      setAmountCents(prev => Math.min(prev + chip.add, 99999999));
                    }}
                    className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-zinc-800 hover:bg-indigo-500/15 hover:text-indigo-600 dark:hover:text-indigo-400 text-[11px] font-bold text-slate-600 dark:text-slate-300 transition-colors active:scale-95 cursor-pointer"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>

              {type === 'parcelada' && numericAmount > 0 && (
                <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400 pt-1">
                  Total Final: {formatCurrency(numericAmount * totalInstallments)} ({totalInstallments} parcelas)
                </p>
              )}
            </div>

            {/* Numeric Keypad (Teclado Limpo de 1-9, Clear, 0, Backspace) */}
            <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clear', '0', 'backspace'].map((key) => {
                if (key === 'backspace') {
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handleKeypadPress('backspace')}
                      className="h-12 sm:h-14 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 active:scale-95 flex items-center justify-center text-slate-700 dark:text-slate-300 font-bold transition-all cursor-pointer shadow-xs"
                      title="Apagar dígito"
                    >
                      <Delete size={22} className="stroke-[2.2]" />
                    </button>
                  );
                }

                if (key === 'clear') {
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handleKeypadPress('clear')}
                      className="h-12 sm:h-14 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 active:scale-95 flex items-center justify-center text-slate-500 dark:text-slate-400 font-bold text-xs transition-all cursor-pointer uppercase tracking-wider shadow-xs"
                      title="Limpar valor"
                    >
                      Limpar
                    </button>
                  );
                }

                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => handleKeypadPress(key)}
                    className="h-12 sm:h-14 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 active:scale-95 flex items-center justify-center text-slate-900 dark:text-white font-black text-xl transition-all cursor-pointer select-none shadow-xs"
                  >
                    {key}
                  </button>
                );
              })}
            </div>

            {/* Actions in Step 1: Quick Confirm or Details */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                id="btn-add-expense-quick-save"
                disabled={numericAmount <= 0}
                onClick={handleQuickSaveDirect}
                className={`py-4 px-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                  numericAmount > 0
                    ? 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white shadow-indigo-600/30'
                    : 'bg-slate-200 dark:bg-zinc-800 text-slate-400 dark:text-slate-600 cursor-not-allowed shadow-none'
                }`}
              >
                <Check size={18} className="stroke-[2.5]" />
                <span>Confirmar Gasto Direto</span>
              </button>

              <button
                type="button"
                id="btn-add-expense-continue"
                disabled={numericAmount <= 0}
                onClick={handleContinueToStep2}
                className={`py-4 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  numericAmount > 0
                    ? 'bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 active:scale-[0.98]'
                    : 'bg-slate-100 dark:bg-zinc-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                }`}
              >
                <span>Mais Detalhes</span>
                <ArrowRight size={18} className="stroke-[2.5]" />
              </button>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* ETAPA 2: DETALHES, RESUMO & INFORMAÇÕES (Inspirado na 2ª Tela de Referência) */}
        {/* ========================================================================= */}
        {step === 2 && (
          <form onSubmit={handleFinalSubmit} className="space-y-5">
            
            {/* Reckoning / Resumo Financeiro da Cobrança */}
            <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  Resumo do Pagamento
                </span>
                <button
                  type="button"
                  onClick={() => { setStep(1); triggerHaptic(8); }}
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                >
                  Alterar Valor
                </button>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Cartão</span>
                  <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <BankLogo bankName={selectedCard?.bank || selectedCard?.name} size={18} />
                    {selectedCard?.name}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Tipo de Cobrança</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {type === 'unica' ? 'Compra À Vista' : type === 'parcelada' ? `Parcelado em ${totalInstallments}x` : 'Assinatura / Fixo'}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Valor por Mês</span>
                  <span className="text-base font-black text-slate-900 dark:text-white tabular-nums">
                    {formatCurrency(numericAmount)}
                  </span>
                </div>

                {type === 'parcelada' && (
                  <div className="flex items-center justify-between text-indigo-600 dark:text-indigo-400 font-bold">
                    <span>Total da Compra</span>
                    <span className="tabular-nums">{formatCurrency(numericAmount * totalInstallments)}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Enter Your Information / Informações do Gasto */}
            <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs space-y-4">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Detalhes do Lançamento
              </span>

              {/* 1. Descrição do Gasto & Sugestões */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Descrição do Gasto (Opcional)
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ex: Supermercado, Almoço, Uber, Farmácia..."
                  autoFocus
                  className="w-full px-4 py-3.5 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none"
                />

                {/* Quick Suggestion Chips */}
                <div className="flex items-center flex-wrap gap-1.5 mt-2">
                  {[
                    { label: '🍽️ Almoço / Lanche', cat: 'Alimentação' },
                    { label: '🛒 Supermercado', cat: 'Mercado' },
                    { label: '🚗 Uber / Transporte', cat: 'Transporte' },
                    { label: '⛽ Combustível', cat: 'Transporte' },
                    { label: '💊 Farmácia', cat: 'Saúde' },
                    { label: '🛍️ Shopping', cat: 'Lazer' },
                  ].map((sug) => (
                    <button
                      key={sug.label}
                      type="button"
                      onClick={() => {
                        triggerHaptic(6);
                        setDescription(sug.label.replace(/^[^\s]+\s/, ''));
                        setCategory(sug.cat);
                      }}
                      className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-zinc-800/80 hover:bg-indigo-500/15 hover:text-indigo-600 dark:hover:text-indigo-400 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
                    >
                      {sug.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Quem Gastou / Dono */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <User size={14} className="text-indigo-500" />
                  <span>Quem Gastou / Dono</span>
                </label>
                <select
                  value={personId}
                  onChange={(e) => setPersonId(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs font-semibold cursor-pointer outline-none focus:ring-2 focus:ring-indigo-600"
                >
                  {people.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} {p.isSelf ? '(Você)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. Categoria */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Tag size={14} className="text-amber-500" />
                  <span>Categoria</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs font-semibold cursor-pointer outline-none focus:ring-2 focus:ring-indigo-600"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.icon} {c.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. Mês Inicial de Cobrança */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Calendar size={14} className="text-purple-500" />
                  <span>Mês Inicial de Cobrança</span>
                </label>
                <input
                  type="month"
                  value={startMonthYear}
                  onChange={(e) => setStartMonthYear(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>

              {/* 5. Observações (opcional) */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Observações (opcional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Compra com desconto, frete grátis..."
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-4 px-4 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 rounded-2xl font-bold text-sm transition-colors cursor-pointer text-center"
              >
                Voltar
              </button>

              <button
                type="submit"
                id="btn-save-expense-final"
                className="flex-[2] py-4 px-6 font-black text-white rounded-2xl text-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer bg-indigo-600 hover:bg-indigo-700 active:scale-95 shadow-indigo-600/30"
              >
                <Check size={18} className="stroke-[2.5]" />
                <span>Salvar Lançamento</span>
              </button>
            </div>

          </form>
        )}

      </main>
    </div>
  );
}
