import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Car, 
  Fuel, 
  UtensilsCrossed, 
  Sparkles, 
  Check, 
  TrendingUp, 
  DollarSign, 
  Wallet, 
  Clock, 
  Layers,
  ArrowRight,
  Droplets,
  Wrench
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  DriverAppType, 
  DriverExpenseCategory, 
  WalletAccount, 
  ExtraProfileConfig,
  DriverTrip,
  DriverExpense 
} from '../types';
import { DriverAppLogo } from './DriverAppLogo';
import { APP_CONFIGS } from '../data/initialDriverData';
import { formatCurrency } from '../utils/financeCalculations';

interface DriverDayShiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ExtraProfileConfig;
  accounts: WalletAccount[];
  onSaveShift: (
    trips: Omit<DriverTrip, 'id' | 'createdAt'>[],
    expenses: Omit<DriverExpense, 'id' | 'createdAt'>[]
  ) => void;
}

export function DriverDayShiftModal({
  isOpen,
  onClose,
  config,
  accounts,
  onSaveShift
}: DriverDayShiftModalProps) {
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [hoursWorked, setHoursWorked] = useState<string>('');
  const [kmDriven, setKmDriven] = useState<string>('');
  
  // Platform earnings { uber: "120.00", 99: "80.00", ... }
  const activeApps = config.selectedApps && config.selectedApps.length > 0 
    ? config.selectedApps 
    : (['uber', '99', 'indrive'] as DriverAppType[]);

  const [platformEarnings, setPlatformEarnings] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    activeApps.forEach(app => {
      init[app] = '';
    });
    return init;
  });

  const [platformTripsCount, setPlatformTripsCount] = useState<Record<string, string>>({});

  // Expenses { combustivel: "80.00", alimentacao: "25.00", lavagem: "", pedagio: "", outros: "" }
  const [expenseAmounts, setExpenseAmounts] = useState<{
    combustivel: string;
    alimentacao: string;
    lavagem: string;
    manutencao: string;
    pedagio: string;
    outros: string;
  }>({
    combustivel: '',
    alimentacao: '',
    lavagem: '',
    manutencao: '',
    pedagio: '',
    outros: ''
  });

  const defaultAcc = accounts.find(a => a.id === config.defaultAccountId) || accounts[0];
  const [accountId, setAccountId] = useState<string>(defaultAcc?.id || '');

  if (!isOpen) return null;

  const handlePlatformChange = (app: string, value: string) => {
    setPlatformEarnings(prev => ({ ...prev, [app]: value }));
  };

  const handleExpenseChange = (cat: keyof typeof expenseAmounts, value: string) => {
    setExpenseAmounts(prev => ({ ...prev, [cat]: value }));
  };

  // Calculations
  const parseVal = (v?: string | null): number => {
    if (!v) return 0;
    const clean = parseFloat(String(v).replace(',', '.'));
    return isNaN(clean) ? 0 : clean;
  };

  const totalEarnings: number = (Object.values(platformEarnings) as string[]).reduce((acc: number, v: string) => acc + parseVal(v), 0);
  const totalExpenses: number = (Object.values(expenseAmounts) as string[]).reduce((acc: number, v: string) => acc + parseVal(v), 0);
  const netProfit: number = totalEarnings - totalExpenses;

  const handleSave = () => {
    if (totalEarnings === 0 && totalExpenses === 0) return;

    const tripsToSave: Omit<DriverTrip, 'id' | 'createdAt'>[] = [];
    const expensesToSave: Omit<DriverExpense, 'id' | 'createdAt'>[] = [];

    const hours = parseFloat(hoursWorked.replace(',', '.')) || 0;
    const km = parseFloat(kmDriven.replace(',', '.')) || 0;

    // Platform trips
    (Object.entries(platformEarnings) as [string, string][]).forEach(([appKey, valStr]) => {
      const amount = parseVal(valStr);
      if (amount > 0) {
        const appType = appKey as DriverAppType;
        const appConfig = APP_CONFIGS[appType];
        const feePercent = appConfig?.defaultFee || 0;
        const tripsCount = parseInt(platformTripsCount[appKey] || '0', 10) || undefined;

        tripsToSave.push({
          app: appType,
          type: 'fechamento_dia',
          grossAmount: amount,
          feePercent: 0, // In shift closing, the entered value is usually the platform net received
          feeAmount: 0,
          netAmount: amount,
          date,
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          durationMinutes: hours > 0 ? Math.round((hours * 60) / Object.keys(platformEarnings).filter(k => parseVal(platformEarnings[k]) > 0).length) : undefined,
          distanceKm: km > 0 ? Math.round(km / Object.keys(platformEarnings).filter(k => parseVal(platformEarnings[k]) > 0).length) : undefined,
          tripsCount,
          accountId,
          notes: `Fechamento do dia (${appConfig?.name || appKey})`,
          syncToIncome: true
        });
      }
    });

    // Expenses
    const expenseLabels: Record<keyof typeof expenseAmounts, { name: string; cat: DriverExpenseCategory }> = {
      combustivel: { name: 'Combustível / Gasolina', cat: 'combustivel' },
      alimentacao: { name: 'Almoço / Alimentação', cat: 'alimentacao' },
      lavagem: { name: 'Lavagem do Veículo', cat: 'lavagem' },
      manutencao: { name: 'Manutenção / Óleo', cat: 'manutencao' },
      pedagio: { name: 'Pedágio / Estacionamento', cat: 'pedagio' },
      outros: { name: 'Outros Gastos Operacionais', cat: 'outros' }
    };

    (Object.keys(expenseAmounts) as Array<keyof typeof expenseAmounts>).forEach(key => {
      const amount = parseVal(expenseAmounts[key]);
      if (amount > 0) {
        const info = expenseLabels[key];
        expensesToSave.push({
          category: info.cat,
          description: info.name,
          amount,
          date,
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          accountId,
          fuelType: key === 'combustivel' ? (config.fuelType === 'outro' ? undefined : config.fuelType) || 'gasolina' : undefined,
          notes: `Despesa do dia lançada no fechamento`
        });
      }
    });

    onSaveShift(tripsToSave, expensesToSave);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
      />

      {/* Modal Card */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 10 }}
        className="relative w-full max-w-xl bg-white dark:bg-[#1C1C1E] rounded-3xl shadow-2xl border border-slate-200 dark:border-white/10 overflow-hidden flex flex-col max-h-[92vh] z-10"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
              <Sparkles size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Lançar Fechamento do Dia
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Ganhos separados por app e despesas do dia em um só lugar
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          {/* General Data: Date, Account, Hours */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Data do Dia
              </label>
              <div className="relative">
                <Calendar size={14} className="absolute left-3 top-3 text-slate-400" />
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Conta da Carteira
              </label>
              <div className="relative">
                <Wallet size={14} className="absolute left-3 top-3 text-slate-400" />
                <select
                  value={accountId}
                  onChange={e => setAccountId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 truncate"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Horas / KM (Opcional)
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  type="text"
                  placeholder="Horas (ex: 8)"
                  value={hoursWorked}
                  onChange={e => setHoursWorked(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-center"
                />
                <input
                  type="text"
                  placeholder="KM (ex: 150)"
                  value={kmDriven}
                  onChange={e => setKmDriven(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-center"
                />
              </div>
            </div>
          </div>

          {/* Section 1: Earnings by Platform */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <TrendingUp size={14} className="text-emerald-500" />
                1. Quanto você fez em cada App hoje?
              </h4>
              <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                Total: {formatCurrency(totalEarnings)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {activeApps.map(appId => {
                const appConfig = APP_CONFIGS[appId];
                return (
                  <div
                    key={appId}
                    className="p-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-white/[0.02] flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <DriverAppLogo app={appId} size="md" />
                      <div className="truncate">
                        <span className="font-bold text-xs text-slate-900 dark:text-white block truncate">
                          {appConfig?.name || appId}
                        </span>
                        <span className="text-[10px] text-slate-400">Faturamento</span>
                      </div>
                    </div>

                    <div className="relative w-28">
                      <span className="absolute left-2.5 top-2 text-[11px] font-bold text-slate-400">R$</span>
                      <input
                        type="text"
                        placeholder="0,00"
                        value={platformEarnings[appId] || ''}
                        onChange={e => handlePlatformChange(appId, e.target.value)}
                        className="w-full pl-8 pr-2 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1C1C1E] text-xs font-black text-slate-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 2: Expenses of the Day */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <Fuel size={14} className="text-rose-500" />
                2. Despesas & Gastos de Hoje
              </h4>
              <span className="text-xs font-black text-rose-600 dark:text-rose-400">
                Total: {formatCurrency(totalExpenses)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Combustivel */}
              <div className="p-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-white/[0.02] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
                    <Fuel size={16} />
                  </div>
                  <div>
                    <span className="font-bold text-xs text-slate-900 dark:text-white block">
                      Combustível / Gasolina
                    </span>
                    <span className="text-[10px] text-slate-400">Abastecimento</span>
                  </div>
                </div>
                <div className="relative w-28">
                  <span className="absolute left-2.5 top-2 text-[11px] font-bold text-slate-400">R$</span>
                  <input
                    type="text"
                    placeholder="0,00"
                    value={expenseAmounts.combustivel}
                    onChange={e => handleExpenseChange('combustivel', e.target.value)}
                    className="w-full pl-8 pr-2 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1C1C1E] text-xs font-black text-slate-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              {/* Alimentação / Almoço */}
              <div className="p-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-white/[0.02] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                    <UtensilsCrossed size={16} />
                  </div>
                  <div>
                    <span className="font-bold text-xs text-slate-900 dark:text-white block">
                      Almoço / Lanche
                    </span>
                    <span className="text-[10px] text-slate-400">Refeição na rua</span>
                  </div>
                </div>
                <div className="relative w-28">
                  <span className="absolute left-2.5 top-2 text-[11px] font-bold text-slate-400">R$</span>
                  <input
                    type="text"
                    placeholder="0,00"
                    value={expenseAmounts.alimentacao}
                    onChange={e => handleExpenseChange('alimentacao', e.target.value)}
                    className="w-full pl-8 pr-2 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1C1C1E] text-xs font-black text-slate-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              {/* Lavagem */}
              <div className="p-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-white/[0.02] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center">
                    <Droplets size={16} />
                  </div>
                  <div>
                    <span className="font-bold text-xs text-slate-900 dark:text-white block">
                      Lavagem / Ducha
                    </span>
                    <span className="text-[10px] text-slate-400">Limpeza</span>
                  </div>
                </div>
                <div className="relative w-28">
                  <span className="absolute left-2.5 top-2 text-[11px] font-bold text-slate-400">R$</span>
                  <input
                    type="text"
                    placeholder="0,00"
                    value={expenseAmounts.lavagem}
                    onChange={e => handleExpenseChange('lavagem', e.target.value)}
                    className="w-full pl-8 pr-2 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1C1C1E] text-xs font-black text-slate-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              {/* Outros */}
              <div className="p-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-white/[0.02] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center">
                    <Wrench size={16} />
                  </div>
                  <div>
                    <span className="font-bold text-xs text-slate-900 dark:text-white block">
                      Pedágio / Manutenção / Outros
                    </span>
                    <span className="text-[10px] text-slate-400">Diversos</span>
                  </div>
                </div>
                <div className="relative w-28">
                  <span className="absolute left-2.5 top-2 text-[11px] font-bold text-slate-400">R$</span>
                  <input
                    type="text"
                    placeholder="0,00"
                    value={expenseAmounts.outros}
                    onChange={e => handleExpenseChange('outros', e.target.value)}
                    className="w-full pl-8 pr-2 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1C1C1E] text-xs font-black text-slate-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Summary Real Profit Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 text-white dark:from-white/10 dark:to-white/5 border border-slate-800 dark:border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">Resumo do Fechamento</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold">
                Sincronizado na Carteira
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1 border-t border-white/10 text-center">
              <div>
                <span className="text-[10px] text-slate-400 block">Faturamento</span>
                <span className="text-xs sm:text-sm font-black text-white">
                  {formatCurrency(totalEarnings)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Despesas</span>
                <span className="text-xs sm:text-sm font-black text-rose-400">
                  - {formatCurrency(totalExpenses)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Lucro no Bolso</span>
                <span className={`text-xs sm:text-sm font-black ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {formatCurrency(netProfit)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-white/[0.02]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white transition-all cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            onClick={handleSave}
            disabled={totalEarnings === 0 && totalExpenses === 0}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-2 cursor-pointer"
          >
            Salvar Fechamento
            <Check size={16} />
          </button>
        </div>
      </motion.div>
    </div>
  );
}
