import React, { useState, useEffect } from 'react';
import { Car, Play, Square, Plus, Clock, DollarSign, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { DriverAppType } from '../types';
import { formatCurrency } from '../utils/financeCalculations';
import { APP_CONFIGS } from '../data/initialDriverData';

export interface ActiveShift {
  startTime: string; // ISO datetime
  startedAt: Date;
  totalGross: number;
  tripsCount: number;
  appInUse: DriverAppType | null;
}

interface DriverShiftModeProps {
  activeShift: ActiveShift | null;
  onStartShift: (app: DriverAppType) => void;
  onEndShift: () => void;
  onQuickAddTrip: () => void;
}

export function DriverShiftMode({
  activeShift,
  onStartShift,
  onEndShift,
  onQuickAddTrip,
}: DriverShiftModeProps) {
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [selectedAppForStart, setSelectedAppForStart] = useState<DriverAppType>('uber');
  const [isStartingModalOpen, setIsStartingModalOpen] = useState(false);

  useEffect(() => {
    if (!activeShift) {
      setElapsedSeconds(0);
      return;
    }

    const start = new Date(activeShift.startTime).getTime();
    const interval = setInterval(() => {
      const now = Date.now();
      setElapsedSeconds(Math.floor((now - start) / 1000));
    }, 1000);

    return () => clearInterval(interval);
  }, [activeShift]);

  const formatTime = (secs: number) => {
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  if (!activeShift) {
    return (
      <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-slate-950 p-4 sm:p-5 rounded-3xl text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Car size={26} className="stroke-[2.2]" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm sm:text-base">Modo Turno de Trabalho</h3>
            <p className="text-xs text-slate-300">Inicie seu turno para rastrear tempo, ganhos e km em tempo real.</p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedAppForStart}
            onChange={(e) => setSelectedAppForStart(e.target.value as DriverAppType)}
            aria-label="Selecionar aplicativo de transporte"
            className="bg-white/10 border border-white/20 text-white text-xs rounded-xl px-3 py-2.5 focus:outline-hidden cursor-pointer"
          >
            {Object.entries(APP_CONFIGS).map(([key, cfg]) => (
              <option key={key} value={key} className="bg-slate-900 text-white">
                {cfg.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => onStartShift(selectedAppForStart)}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-95"
          >
            <Play size={16} className="fill-current" />
            <span>Iniciar Turno</span>
          </button>
        </div>
      </div>
    );
  }

  const appCfg = activeShift.appInUse ? APP_CONFIGS[activeShift.appInUse] : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border border-emerald-500/30 p-4 sm:p-5 rounded-3xl text-white shadow-xl relative overflow-hidden"
    >
      <div className="absolute right-0 top-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-950 font-black flex items-center justify-center shrink-0 shadow-lg animate-pulse">
            <Car size={26} className="stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Turno Ativo {appCfg ? `• ${appCfg.name}` : ''}
              </span>
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-xl sm:text-2xl font-black tabular-nums font-mono text-white">
                {formatTime(elapsedSeconds)}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-left sm:text-right bg-white/5 border border-white/10 px-3 py-1.5 rounded-2xl">
            <span className="text-[10px] uppercase opacity-75 block">Bruto no Turno</span>
            <span className="text-base sm:text-lg font-black text-emerald-400 tabular-nums">
              {formatCurrency(activeShift.totalGross)}
            </span>
          </div>

          <div className="text-left sm:text-right bg-white/5 border border-white/10 px-3 py-1.5 rounded-2xl">
            <span className="text-[10px] uppercase opacity-75 block">Corridas</span>
            <span className="text-base sm:text-lg font-black text-white tabular-nums">
              {activeShift.tripsCount}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-white/10">
          <button
            type="button"
            onClick={onQuickAddTrip}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-95"
          >
            <Plus size={16} className="stroke-[3]" />
            <span>+ Corrida</span>
          </button>

          <button
            type="button"
            onClick={onEndShift}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-95"
          >
            <Square size={14} className="fill-current" />
            <span>Encerrar Turno</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}
