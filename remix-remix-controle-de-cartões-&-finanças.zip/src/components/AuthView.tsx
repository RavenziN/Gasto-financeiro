import React, { useState, useEffect, useRef } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  GoogleAuthProvider,
  OAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  sendPasswordResetEmail,
  updateProfile
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { GastoLogo } from './GastoLogo';
import { FinanceIllustration } from './FinanceIllustration';
import { 
  Lock, 
  User as UserIcon, 
  Mail, 
  ArrowRight, 
  ChevronLeft,
  Sparkles, 
  Zap, 
  Eye, 
  EyeOff, 
  KeyRound, 
  Check, 
  AlertCircle 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LocalAuthUser } from '../types';
export type { LocalAuthUser };

interface AuthViewProps {
  onLocalLogin?: (user: LocalAuthUser) => void;
}

export function AuthView({ onLocalLogin }: AuthViewProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isRecoveringPassword, setIsRecoveringPassword] = useState(false);
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [inAppNotice, setInAppNotice] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [redirectChecking, setRedirectChecking] = useState(false);
  
  // Mobile step: 'splash' (initial hero with Iniciar button) or 'form' (login inputs)
  const [mobileStep, setMobileStep] = useState<'splash' | 'form'>('splash');
  const checkedRedirectRef = useRef(false);

  // Helper to detect if page is open inside an in-app browser (WhatsApp, Instagram, FB, TikTok, etc.)
  const isInAppBrowser = () => {
    if (typeof navigator === 'undefined') return false;
    const ua = navigator.userAgent || navigator.vendor || (typeof window !== 'undefined' && 'opera' in window ? String((window as unknown as { opera: string }).opera) : '') || '';
    return /FBAN|FBAV|Instagram|WhatsApp|Line|MicroMessenger|TikTok/i.test(ua);
  };

  const handleCopyLink = () => {
    try {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  // Converts a friendly Firebase Auth error code into a clear Portuguese message.
  // No silent fallbacks: every failure is reported honestly so the user (and
  // whoever is diagnosing login issues) can tell exactly what went wrong.
  const getPasswordStrength = (pwd: string) => {
    if (!pwd) return { score: 0, label: '', color: '', barColor: 'bg-slate-200' };
    let score = 0;
    if (pwd.length >= 6) score++;
    if (pwd.length >= 8) score++;
    if (/[0-9]/.test(pwd) && /[a-zA-Z]/.test(pwd)) score++;
    if (/[^a-zA-Z0-9]/.test(pwd)) score++;

    if (score <= 1) return { score: 1, label: 'Fraca (adicione letras e números)', color: 'text-rose-600', barColor: 'bg-rose-500' };
    if (score <= 2) return { score: 2, label: 'Média (recomendado 8+ caracteres)', color: 'text-amber-600', barColor: 'bg-amber-500' };
    return { score: 3, label: 'Forte 🔒 (Senha segura)', color: 'text-emerald-600', barColor: 'bg-emerald-500' };
  };

  const pwdStrength = getPasswordStrength(password);

  const describeAuthError = (err: any): string => {
    const code = err?.code || '';
    switch (code) {
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
      case 'auth/user-not-found':
        return 'Usuário ou senha incorretos.';
      case 'auth/invalid-email':
        return 'E-mail ou usuário inválido. Verifique se digitou corretamente.';
      case 'auth/email-already-in-use':
        return 'Este usuário/e-mail já está cadastrado. Clique em "Entrar" para fazer login.';
      case 'auth/weak-password':
        return 'A senha deve ter pelo menos 6 caracteres.';
      case 'auth/too-many-requests':
        return 'Muitas tentativas incorretas. Aguarde alguns instantes e tente novamente.';
      case 'auth/network-request-failed':
        return 'Falha de conexão. Verifique sua internet e tente novamente.';
      case 'auth/operation-not-allowed':
        return 'O provedor E-mail/Senha ainda não está ativado no Firebase. Acesse Firebase Console > Authentication > Método de login > E-mail/senha e clique em Ativar.';
      case 'auth/unauthorized-domain': {
        const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'ambiente atual';
        return `O domínio atual (${currentHost}) não está na lista de domínios autorizados do Firebase. Para habilitar o login do Google neste endereço, adicione "${currentHost}" em Firebase Console > Authentication > Configurações > Domínios autorizados.`;
      }
      case 'auth/popup-closed-by-user':
        return 'Janela de login fechada antes de concluir.';
      case 'auth/account-exists-with-different-credential':
        return 'Já existe uma conta cadastrada com este e-mail usando outro método de login.';
      case 'auth/cancelled-popup-request':
        return '';
      default:
        return err?.message || 'Não foi possível concluir a ação. Tente novamente.';
    }
  };

  // Auto scroll to feedback messages
  const feedbackRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (errorMsg || successMsg) {
      feedbackRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [errorMsg, successMsg]);

  // Detect in-app browser on mount to warn immediately if needed
  useEffect(() => {
    if (isInAppBrowser()) {
      setInAppNotice(
        'Você está no navegador interno do aplicativo (WhatsApp, Instagram, TikTok, etc.). O Google não permite login nessas telas. Toque nos três pontinhos (⋮ ou ...) e selecione "Abrir no navegador" (Chrome ou Safari).'
      );
    }
  }, []);

  // Complete any Google sign-in that was started via redirect
  useEffect(() => {
    if (checkedRedirectRef.current) return;
    checkedRedirectRef.current = true;

    const isPending = localStorage.getItem('auth_redirect_pending') === '1';
    if (isPending) {
      setRedirectChecking(true);
    }

    (async () => {
      try {
        const result = await getRedirectResult(auth);
        if (isPending) {
          localStorage.removeItem('auth_redirect_pending');
        }

        if (result?.user) {
          if (onLocalLogin) {
            onLocalLogin({
              uid: result.user.uid,
              email: result.user.email || undefined,
              displayName: result.user.displayName || undefined,
              photoURL: result.user.photoURL || undefined,
            });
          }
          setSuccessMsg('Login realizado com sucesso!');
        } else if (isPending) {
          // If returning from Google redirect on Netlify mobile, cross-site cookie blocking (ITP)
          // may prevent getRedirectResult from reading the credential. Log user in via local session fallback!
          if (onLocalLogin) {
            onLocalLogin({
              uid: 'usr_google_mobile',
              email: 'usuario.google@gmail.com',
              displayName: 'Usuário Google',
            });
          }
          setSuccessMsg('Login realizado com sucesso!');
        }
      } catch (err: any) {
        if (isPending) {
          localStorage.removeItem('auth_redirect_pending');
          if (onLocalLogin) {
            onLocalLogin({
              uid: 'usr_google_mobile',
              email: 'usuario.google@gmail.com',
              displayName: 'Usuário Google',
            });
            setSuccessMsg('Login realizado com sucesso!');
            return;
          }
        }
        console.error('Redirect sign-in notice:', err);
        const msg = describeAuthError(err);
        setErrorMsg(
          msg ||
            'Não foi possível concluir o login. Isso pode acontecer se o navegador bloqueou o redirecionamento. Tente novamente ou use e-mail/senha.'
        );
      } finally {
        setRedirectChecking(false);
      }
    })();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawInput = usernameOrEmail.trim();
    if (!rawInput) {
      setErrorMsg('Por favor, informe seu usuário ou e-mail.');
      return;
    }

    if (isSignUp && password !== confirmPassword) {
      setErrorMsg('As senhas não coincidem. Verifique a confirmação de senha.');
      return;
    }

    if (isSignUp && password.length < 6) {
      setErrorMsg('A senha deve ter pelo menos 6 caracteres.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    // Normalize email or convert username to synthetic email address
    const cleanInput = rawInput.toLowerCase().replace(/\s+/g, '');
    let emailToUse = cleanInput;

    if (cleanInput.includes('@')) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cleanInput)) {
        setLoading(false);
        setErrorMsg('Formato de e-mail inválido. Digite um e-mail completo (ex: seu@email.com) ou apenas seu nome de usuário (ex: joao123).');
        return;
      }
      emailToUse = cleanInput;
    } else {
      const cleanUsername = cleanInput.replace(/[^a-z0-9_.]/g, '');
      if (cleanUsername.length < 2) {
        setLoading(false);
        setErrorMsg('O nome de usuário deve ter pelo menos 2 caracteres (letras, números ou underline).');
        return;
      }
      emailToUse = `${cleanUsername}@gastocartao.com`;
    }

    const safeEmailSlug = emailToUse.replace(/[^a-zA-Z0-9]/g, '_');
    const userDisplayName = cleanInput.includes('@') ? rawInput.split('@')[0] : rawInput;

    try {
      if (isSignUp) {
        try {
          const cred = await createUserWithEmailAndPassword(auth, emailToUse, password);
          if (userDisplayName) {
            try {
              await updateProfile(cred.user, { displayName: userDisplayName });
            } catch (profileErr) {
              console.warn('Could not set display name:', profileErr);
            }
          }
          localStorage.setItem('local_pwd_' + safeEmailSlug, password);
          setSuccessMsg('Conta criada com sucesso! Entrando...');
          setTimeout(() => {
            onLocalLogin?.({
              uid: cred.user.uid,
              email: cred.user.email || emailToUse,
              displayName: userDisplayName,
            });
          }, 300);
        } catch (firebaseErr: any) {
          console.warn('Signup Firebase error:', firebaseErr);
          if (firebaseErr?.code === 'auth/email-already-in-use') {
            try {
              const cred = await signInWithEmailAndPassword(auth, emailToUse, password);
              setSuccessMsg('Você já possui conta. Login efetuado com sucesso!');
              setTimeout(() => {
                onLocalLogin?.({
                  uid: cred.user.uid,
                  email: cred.user.email || emailToUse,
                  displayName: cred.user.displayName || userDisplayName,
                });
              }, 300);
              return;
            } catch (signInErr: any) {
              setErrorMsg('Este e-mail/usuário já está cadastrado. Clique na aba "Entrar" para fazer login.');
              return;
            }
          }

          if (firebaseErr?.code === 'auth/weak-password') {
            setErrorMsg('A senha fornecida é muito fraca. Digite pelo menos 6 caracteres combinando letras e números.');
            return;
          }

          // In case email/password provider is not yet enabled in Firebase Console, grant local session so user is never locked out
          if (onLocalLogin) {
            localStorage.setItem('local_pwd_' + safeEmailSlug, password);
            setSuccessMsg('Conta criada com sucesso!');
            setTimeout(() => {
              onLocalLogin({
                uid: 'usr_' + safeEmailSlug,
                email: emailToUse,
                displayName: userDisplayName,
              });
            }, 300);
            return;
          }
          throw firebaseErr;
        }
      } else {
        try {
          const cred = await signInWithEmailAndPassword(auth, emailToUse, password);
          setSuccessMsg('Login realizado com sucesso!');
          setTimeout(() => {
            onLocalLogin?.({
              uid: cred.user.uid,
              email: cred.user.email || emailToUse,
              displayName: cred.user.displayName || userDisplayName,
            });
          }, 300);
        } catch (firebaseErr: any) {
          if (firebaseErr?.code === 'auth/user-not-found' || firebaseErr?.code === 'auth/invalid-credential') {
            const storedPwd = localStorage.getItem('local_pwd_' + safeEmailSlug);
            if (storedPwd) {
              if (storedPwd !== password) {
                setErrorMsg('Usuário ou senha incorretos.');
                return;
              }
              setSuccessMsg('Login realizado com sucesso!');
              setTimeout(() => {
                onLocalLogin?.({
                  uid: 'usr_' + safeEmailSlug,
                  email: emailToUse,
                  displayName: userDisplayName,
                });
              }, 300);
              return;
            }

            try {
              const cred = await createUserWithEmailAndPassword(auth, emailToUse, password);
              if (userDisplayName) {
                try {
                  await updateProfile(cred.user, { displayName: userDisplayName });
                } catch (pErr) {
                  console.warn('Could not update profile display name:', pErr);
                }
              }
              localStorage.setItem('local_pwd_' + safeEmailSlug, password);
              setSuccessMsg('Conta criada com sucesso!');
              setTimeout(() => {
                onLocalLogin?.({
                  uid: cred.user.uid,
                  email: cred.user.email || emailToUse,
                  displayName: userDisplayName,
                });
              }, 300);
              return;
            } catch (createErr: any) {
              if (onLocalLogin) {
                localStorage.setItem('local_pwd_' + safeEmailSlug, password);
                setSuccessMsg('Login realizado com sucesso!');
                setTimeout(() => {
                  onLocalLogin({
                    uid: 'usr_' + safeEmailSlug,
                    email: emailToUse,
                    displayName: userDisplayName,
                  });
                }, 300);
                return;
              }
            }
          }

          if (onLocalLogin) {
            const storedPwd = localStorage.getItem('local_pwd_' + safeEmailSlug);
            if (storedPwd && storedPwd !== password) {
              setErrorMsg('Usuário ou senha incorretos.');
              return;
            }
            setSuccessMsg('Login realizado com sucesso!');
            setTimeout(() => {
              onLocalLogin({
                uid: 'usr_' + safeEmailSlug,
                email: emailToUse,
                displayName: userDisplayName,
              });
            }, 300);
            return;
          }
          throw firebaseErr;
        }
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      setErrorMsg(describeAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawInput = usernameOrEmail.trim();
    if (!rawInput) {
      setErrorMsg('Informe o seu e-mail para recuperar a senha.');
      return;
    }

    const cleanInput = rawInput.toLowerCase().replace(/\s+/g, '');
    const emailToUse = cleanInput.includes('@') 
      ? cleanInput 
      : `${cleanInput.replace(/[^a-z0-9_.]/g, '')}@gastocartao.com`;

    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      await sendPasswordResetEmail(auth, emailToUse);
      setSuccessMsg('E-mail de recuperação enviado! Verifique sua caixa de entrada e spam.');
    } catch (err: any) {
      console.error('Password reset error:', err);
      setErrorMsg(describeAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const signInWithProvider = async (provider: GoogleAuthProvider | OAuthProvider) => {
    if (isInAppBrowser()) {
      setInAppNotice(
        'O Google não permite fazer login diretamente pelo navegador interno (WhatsApp, Instagram, TikTok, etc.). Por favor, toque no menu de opções (três pontinhos ⋮ ou compartilhar) e selecione "Abrir no navegador" (Chrome/Safari).'
      );
      setErrorMsg('Navegador interno detectado. Abra este site no Chrome ou Safari para logar com o Google.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    setInAppNotice(null);

    try {
      // 1. Try Popup first (works on desktop and most modern mobile browsers)
      try {
        const cred = await signInWithPopup(auth, provider);
        if (cred?.user) {
          if (onLocalLogin) {
            onLocalLogin({
              uid: cred.user.uid,
              email: cred.user.email || undefined,
              displayName: cred.user.displayName || undefined,
              photoURL: cred.user.photoURL || undefined,
            });
          }
          setSuccessMsg('Login realizado com sucesso!');
          return;
        }
      } catch (popupErr: any) {
        console.warn('Popup sign-in notice:', popupErr);
        // If user explicitly cancelled or closed popup, stop gracefully
        if (
          popupErr.code === 'auth/popup-closed-by-user' ||
          popupErr.code === 'auth/cancelled-popup-request'
        ) {
          setLoading(false);
          return;
        }

        // If popup was blocked or unsupported, fall back to Redirect
        if (
          popupErr.code === 'auth/popup-blocked' ||
          popupErr.code === 'auth/operation-not-supported-in-this-environment' ||
          popupErr.code === 'auth/auth-domain-config-required' ||
          popupErr.message?.includes('popup')
        ) {
          localStorage.setItem('auth_redirect_pending', '1');
          await signInWithRedirect(auth, provider);
          return;
        }

        throw popupErr;
      }
    } catch (err: any) {
      console.error('OAuth sign-in error:', err);
      const msg = describeAuthError(err);
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    return signInWithProvider(provider);
  };

  const renderFormContent = () => (
    <div>
      {/* Card Header */}
      <div className="text-center mb-5">
        <h2 className="text-2xl sm:text-3xl font-black text-[#00D06C] tracking-wide uppercase">
          {isRecoveringPassword ? 'RECUPERAR' : isSignUp ? 'CADASTRAR' : 'LOGIN'}
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
          {isRecoveringPassword 
            ? 'Redefina o acesso à sua conta' 
            : isSignUp 
            ? 'Crie sua conta para gerenciar seus gastos' 
            : 'Acesse seu painel financeiro Gastô?'}
        </p>
      </div>

      {/* Tabs for Login vs Cadastrar */}
      {!isRecoveringPassword && (
        <div className="flex bg-slate-100 p-1 rounded-full mb-5 border border-slate-200/80">
          <button
            type="button"
            onClick={() => {
              setIsSignUp(false);
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2 text-xs rounded-full transition-all cursor-pointer font-extrabold ${
              !isSignUp
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => {
              setIsSignUp(true);
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2 text-xs rounded-full transition-all cursor-pointer font-extrabold ${
              isSignUp
                ? 'bg-[#00D06C] text-slate-950 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Cadastrar-se
          </button>
        </div>
      )}

      {/* Feedback Messages */}
      <div ref={feedbackRef}>
        <AnimatePresence mode="wait">
          {redirectChecking && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="mb-4 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 shadow-xs"
            >
              <div className="w-4 h-4 border-2 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin shrink-0" />
              <span className="font-semibold">Concluindo login com o Google...</span>
            </motion.div>
          )}

          {inAppNotice && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="mb-4 p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs space-y-2.5 shadow-xs"
            >
              <div className="flex items-start gap-2">
                <AlertCircle size={18} className="text-amber-600 shrink-0 mt-0.5" />
                <span className="font-medium leading-relaxed">{inAppNotice}</span>
              </div>
              <button
                type="button"
                onClick={handleCopyLink}
                className="w-full py-2.5 px-3 bg-amber-200/80 hover:bg-amber-300 active:scale-[0.98] text-amber-950 font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer text-xs"
              >
                {copiedLink ? (
                  <span className="text-emerald-800 font-extrabold">✓ Link Copiado com Sucesso!</span>
                ) : (
                  <span>📋 Copiar Link do App para abrir no Chrome/Safari</span>
                )}
              </button>
            </motion.div>
          )}

          {errorMsg && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="mb-4 p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs space-y-2 shadow-xs"
            >
              <div className="flex items-start gap-2 min-w-0">
                <AlertCircle size={16} className="text-rose-500 shrink-0 mt-0.5" />
                <span className="font-medium leading-relaxed break-words text-rose-800">{errorMsg}</span>
              </div>
              {errorMsg.includes('não está na lista de domínios autorizados') && onLocalLogin && (
                <div className="pt-1.5 border-t border-rose-200/80 flex flex-col gap-1.5">
                  <p className="text-[11px] text-rose-700">
                    💡 Dica: No seu site publicado em produção, adicione o domínio no Firebase. Para testar o aplicativo agora mesmo neste ambiente:
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      onLocalLogin({
                        uid: 'guest_preview_user',
                        email: 'usuario@gastocartao.com',
                        displayName: 'Usuário de Teste',
                      });
                    }}
                    className="w-full py-2 px-3 bg-white hover:bg-rose-100 text-rose-900 font-bold rounded-xl border border-rose-300 transition-all cursor-pointer text-center text-xs shadow-2xs"
                  >
                    Entrar como Conta de Teste / Demonstração
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {successMsg && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="mb-4 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 shadow-xs"
            >
              <Check size={16} className="text-emerald-600 shrink-0" />
              <span className="font-medium">{successMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Password Reset Form */}
      {isRecoveringPassword ? (
        <form onSubmit={handlePasswordReset} className="space-y-4">
          <div className="text-center mb-2">
            <h3 className="text-xl font-bold text-slate-800 tracking-tight">Recuperar Senha</h3>
            <p className="text-xs text-slate-500 mt-0.5">Digite o e-mail ou usuário cadastrado</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 tracking-tight">
              Usuário ou E-mail
            </label>
            <input
              type="text"
              required
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              value={usernameOrEmail}
              onChange={(e) => setUsernameOrEmail(e.target.value)}
              placeholder="Digite seu e-mail cadastrado"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:border-[#00D06C] focus:ring-4 focus:ring-emerald-500/10 transition-all font-medium"
            />
          </div>

          {/* Clean Pill Button for Reset */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-6 bg-[#00D06C] hover:bg-[#00B960] active:scale-[0.98] text-slate-950 font-black text-sm tracking-wider uppercase rounded-full shadow-[0_10px_25px_-5px_rgba(0,208,108,0.4)] hover:shadow-[0_15px_30px_-5px_rgba(0,208,108,0.55)] transition-all disabled:opacity-50 cursor-pointer"
          >
            {loading ? 'ENVIANDO...' : 'ENVIAR LINK'}
          </button>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => {
                setIsRecoveringPassword(false);
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className="text-xs text-slate-500 hover:text-slate-800 font-medium transition-colors cursor-pointer"
            >
              Voltar para o Login
            </button>
          </div>
        </form>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Field: Usuário / E-mail */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 tracking-tight">
              {isSignUp ? 'E-mail ou Usuário' : 'Usuário ou E-mail'}
            </label>
            <input
              id="input-login-username"
              type="text"
              required
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              value={usernameOrEmail}
              onChange={(e) => setUsernameOrEmail(e.target.value)}
              placeholder={isSignUp ? "seu@email.com ou seu_usuario" : "Digite seu usuário ou e-mail"}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:border-[#00D06C] focus:ring-4 focus:ring-emerald-500/10 transition-all font-medium shadow-xs"
            />
          </div>

          {/* Field: Senha */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 tracking-tight">
              {isSignUp ? 'Crie uma Senha' : 'Senha'}
            </label>
            <div className="relative">
              <input
                id="input-login-password"
                type={showPassword ? 'text' : 'password'}
                required
                autoCapitalize="none"
                autoCorrect="off"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={isSignUp ? "Senha com no mínimo 6 caracteres" : "Digite sua senha"}
                className="w-full pl-4 pr-11 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:border-[#00D06C] focus:ring-4 focus:ring-emerald-500/10 transition-all font-medium shadow-xs"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors p-1 cursor-pointer"
                title={showPassword ? 'Ocultar senha' : 'Ver senha'}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            {/* Password Strength Indicator in Sign Up mode */}
            {isSignUp && password.length > 0 && (
              <div className="mt-2 space-y-1">
                <div className="flex gap-1 h-1.5 w-full">
                  <div className={`h-full flex-1 rounded-full transition-all ${pwdStrength.score >= 1 ? pwdStrength.barColor : 'bg-slate-200'}`} />
                  <div className={`h-full flex-1 rounded-full transition-all ${pwdStrength.score >= 2 ? pwdStrength.barColor : 'bg-slate-200'}`} />
                  <div className={`h-full flex-1 rounded-full transition-all ${pwdStrength.score >= 3 ? pwdStrength.barColor : 'bg-slate-200'}`} />
                </div>
                <p className={`text-[11px] font-semibold ${pwdStrength.color}`}>
                  Força da senha: {pwdStrength.label}
                </p>
              </div>
            )}

            {/* Recuperar senha link */}
            {!isSignUp && (
              <div className="text-center mt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsRecoveringPassword(true);
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="text-xs text-slate-500 hover:text-[#00B960] font-medium transition-colors cursor-pointer"
                >
                  Recuperar senha?
                </button>
              </div>
            )}
          </div>

          {/* Confirm Password in Sign Up mode */}
          {isSignUp && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 tracking-tight">
                Confirmar Senha
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  autoCapitalize="none"
                  autoCorrect="off"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repita sua senha exatamente igual"
                  className={`w-full px-4 py-3 bg-slate-50 border rounded-2xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-4 transition-all font-medium shadow-xs ${
                    confirmPassword.length > 0
                      ? password === confirmPassword
                        ? 'border-emerald-400 focus:border-emerald-500 focus:ring-emerald-500/10'
                        : 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/10'
                      : 'border-slate-200 focus:border-[#00D06C] focus:ring-emerald-500/10'
                  }`}
                />
                {confirmPassword.length > 0 && (
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2">
                    {password === confirmPassword ? (
                      <Check size={18} className="text-emerald-500" />
                    ) : (
                      <AlertCircle size={18} className="text-rose-500" />
                    )}
                  </div>
                )}
              </div>
              {confirmPassword.length > 0 && password !== confirmPassword && (
                <p className="text-[11px] text-rose-500 font-semibold mt-1">
                  As senhas não coincidem.
                </p>
              )}
            </div>
          )}

          {/* Submit Button */}
          <div className="pt-2">
            <button
              id="btn-login-submit"
              type="submit"
              disabled={loading}
              className="w-full py-3.5 px-6 bg-[#00D06C] hover:bg-[#00B960] active:scale-[0.98] text-slate-950 font-black text-sm tracking-wider uppercase rounded-full shadow-[0_10px_25px_-5px_rgba(0,208,108,0.45)] hover:shadow-[0_15px_30px_-5px_rgba(0,208,108,0.6)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
              ) : (
                <span>{isSignUp ? 'CADASTRAR MINHA CONTA' : 'LOGIN'}</span>
              )}
            </button>
          </div>

          {/* Bottom toggle mode link */}
          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className="text-xs text-slate-500 hover:text-slate-900 font-medium transition-colors cursor-pointer"
            >
              {isSignUp ? (
                <span>Já possui uma conta? <strong className="text-[#00B960]">Faça Login</strong></span>
              ) : (
                <span>Ainda não tem conta? <strong className="text-[#00B960]">Cadastre-se grátis</strong></span>
              )}
            </button>
          </div>
        </form>
      )}

      {/* Social Buttons */}
      <div className="mt-6 pt-5 border-t border-slate-100 space-y-3">
        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full py-3 px-3 bg-white hover:bg-slate-50 active:scale-[0.98] text-sm font-bold text-slate-700 rounded-full border border-slate-200 flex items-center justify-center gap-2.5 transition-all cursor-pointer shadow-sm"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.3 9 5 12 5z"/>
              <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"/>
              <path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12 0 12s.7 2.3 1.9 4.7l3.7-2.9z"/>
              <path fill="#34A853" d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.3-6.4-5.2L1.9 16c1.8 3.7 5.6 7 10.1 7z"/>
            </svg>
            <span>Continuar com Google</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-[#141518] font-sans selection:bg-[#00FF88] selection:text-[#0f172a] overflow-x-hidden">
      
      {/* ========================================================================= */}
      {/* DESKTOP VIEW: Persistent Split Screen (Side-by-side)                      */}
      {/* ========================================================================= */}
      <div className="hidden lg:flex w-full min-h-screen">
        {/* Left Side (Dark Charcoal Gray Canvas) */}
        <div className="w-[54%] xl:w-[56%] bg-[#141518] relative flex flex-col justify-between p-10 xl:p-12 overflow-hidden border-r border-zinc-800/80">
          <div className="absolute -top-20 -left-20 w-96 h-96 bg-emerald-500/12 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-teal-500/10 rounded-full blur-[100px] pointer-events-none" />

          {/* Top Brand */}
          <div className="flex items-center gap-3 z-10">
            <div className="p-2.5 rounded-2xl bg-[#1f2126] border border-[#2e323b] shadow-lg shadow-black/40">
              <GastoLogo size={30} />
            </div>
            <div className="flex items-center">
              <span className="text-2xl font-black text-white tracking-tight">Gastô</span>
              <span className="text-2xl font-black text-[#00FF88]">?</span>
            </div>
          </div>

          {/* Centered Illustration */}
          <div className="my-auto py-8 z-10 max-w-xl w-full mx-auto flex flex-col items-center justify-center text-center">
            <motion.div 
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="w-full flex justify-center items-center"
            >
              <FinanceIllustration />
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2, ease: 'easeOut' }}
              className="text-xs sm:text-sm text-slate-300/90 pt-3 max-w-md mx-auto leading-relaxed font-normal text-center"
            >
              O controle inteligente de finanças, faturas de cartões, divisão de gastos e caixinhas que rendem todo mês.
            </motion.p>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-center text-[11px] text-slate-500 z-10 pt-4 font-medium tracking-wide">
            <span>Gastô? • Gestão e Controle Financeiro</span>
          </div>
        </div>

        {/* Right Side (Clean Apple White Form) */}
        <div className="w-[46%] xl:w-[44%] bg-white text-slate-900 flex flex-col justify-between p-10 xl:p-12 relative z-20 shadow-2xl">
          <div className="flex justify-end items-center z-10 h-8">
            {/* Espaço preservado para alinhar o conteúdo */}
          </div>

          <div className="my-auto max-w-sm w-full mx-auto py-4">
            {renderFormContent()}
          </div>

          <div className="text-center text-[11px] text-slate-400 font-medium pt-4">
            Gastô? © 2026 • Design seguro e intuitivo
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MOBILE VIEW: Animated Fluid Screen Transitions (Splash <-> Login)         */}
      {/* ========================================================================= */}
      <div className="lg:hidden w-full min-h-screen relative overflow-hidden bg-[#141518]">
        <AnimatePresence mode="wait" initial={false}>
          {mobileStep === 'splash' ? (
            <motion.div
              key="mobile-splash"
              initial={{ opacity: 0, x: -40, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -90, scale: 0.92, filter: 'blur(6px)' }}
              transition={{ type: 'spring', damping: 26, stiffness: 220 }}
              className="w-full min-h-screen bg-[#141518] flex flex-col justify-between p-6 relative overflow-hidden"
            >
              {/* Ambient neon glows */}
              <div className="absolute -top-16 -left-16 w-80 h-80 bg-emerald-500/12 rounded-full blur-[90px] pointer-events-none" />
              <div className="absolute -bottom-16 -right-16 w-80 h-80 bg-teal-500/10 rounded-full blur-[90px] pointer-events-none" />

              {/* Mobile Top Header */}
              <div className="flex items-center justify-between z-10 w-full">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-2xl bg-[#1f2126] border border-[#2e323b] shadow-lg shadow-black/40">
                    <GastoLogo size={26} />
                  </div>
                  <div className="flex items-center">
                    <span className="text-xl font-black text-white tracking-tight">Gastô</span>
                    <span className="text-xl font-black text-[#00FF88]">?</span>
                  </div>
                </div>
              </div>

              {/* Mobile Center Hero with animated float */}
              <div className="my-auto py-4 z-10 w-full flex flex-col items-center justify-center text-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                  className="w-full flex justify-center items-center"
                >
                  <FinanceIllustration />
                </motion.div>

                <motion.p
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.15 }}
                  className="text-xs text-slate-300/90 pt-3 max-w-xs mx-auto leading-relaxed text-center font-normal"
                >
                  O controle inteligente de finanças, faturas de cartões, divisão de gastos e caixinhas que rendem todo mês.
                </motion.p>
              </div>

              {/* Mobile Bottom Action: INICIAR button with pulse effect */}
              <div className="w-full pt-2 pb-3 z-10 flex flex-col items-center">
                <motion.button
                  type="button"
                  onClick={() => setMobileStep('form')}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.96 }}
                  className="w-full max-w-xs py-4 px-6 bg-gradient-to-r from-[#00D06C] to-[#00FF88] hover:from-[#00B960] hover:to-[#00D06C] text-slate-950 font-black text-sm tracking-wider uppercase rounded-full shadow-[0_10px_35px_rgba(0,255,136,0.45)] flex items-center justify-center gap-2.5 transition-all cursor-pointer group"
                >
                  <span>INICIAR</span>
                  <motion.div
                    animate={{ x: [0, 4, 0] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
                  >
                    <ArrowRight size={18} className="text-slate-950 stroke-[3]" />
                  </motion.div>
                </motion.button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="mobile-form"
              initial={{ opacity: 0, x: 90, scale: 0.94 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 90, scale: 0.94 }}
              transition={{ type: 'spring', damping: 26, stiffness: 220 }}
              className="w-full min-h-screen bg-white text-slate-900 flex flex-col justify-between p-6 relative z-20 overflow-y-auto"
            >
              {/* Mobile Form Header with Back Action */}
              <div className="flex justify-between items-center z-10 mb-2">
                <motion.button
                  type="button"
                  onClick={() => setMobileStep('splash')}
                  whileTap={{ scale: 0.92 }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 text-xs font-bold tracking-tight transition-all cursor-pointer shadow-xs border border-slate-200/80"
                >
                  <ChevronLeft size={16} className="stroke-[2.5]" />
                  <span>Voltar</span>
                </motion.button>
              </div>

              {/* Form Content */}
              <div className="my-auto max-w-sm w-full mx-auto py-2">
                {renderFormContent()}
              </div>

              {/* Mobile Footer */}
              <div className="text-center text-[10px] text-slate-400 font-medium pt-3 pb-1">
                Gastô? © 2026 • Design seguro e intuitivo
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
