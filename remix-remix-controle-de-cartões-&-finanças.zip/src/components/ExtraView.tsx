import React, { useState } from 'react';
import { 
  Briefcase, 
  Car, 
  Zap, 
  SlidersHorizontal, 
  Sparkles, 
  Plus, 
  Target 
} from 'lucide-react';
import { 
  ExtraProfileConfig, 
  DriverTrip, 
  DriverExpense, 
  DriverGoals, 
  FreelanceEntry, 
  FreelanceExpense, 
  FreelanceGoals, 
  WalletAccount 
} from '../types';
import { ExtraSetupModal } from './ExtraSetupModal';
import { ExtraDriverView } from './ExtraDriverView';
import { FreelanceView } from './FreelanceView';

interface ExtraViewProps {
  config: ExtraProfileConfig;
  onSaveConfig: (newConfig: ExtraProfileConfig) => void;
  // Driver Data
  driverTrips: DriverTrip[];
  driverExpenses: DriverExpense[];
  driverGoals: DriverGoals;
  onAddDriverTrip: (tripData: Omit<DriverTrip, 'id'>, editId?: string) => void;
  onDeleteDriverTrip: (tripId: string) => void;
  onAddDriverExpense: (expenseData: Omit<DriverExpense, 'id'>, editId?: string) => void;
  onDeleteDriverExpense: (expenseId: string) => void;
  onSaveDriverGoals: (newGoals: DriverGoals) => void;
  onSaveDriverShift: (
    trips: Omit<DriverTrip, 'id' | 'createdAt'>[],
    expenses: Omit<DriverExpense, 'id' | 'createdAt'>[]
  ) => void;
  // Freelance Data
  freelanceEntries: FreelanceEntry[];
  freelanceExpenses: FreelanceExpense[];
  freelanceGoals: FreelanceGoals;
  onOpenAddFreelanceEntry: () => void;
  onOpenEditFreelanceEntry: (entry: FreelanceEntry) => void;
  onDeleteFreelanceEntry: (entryId: string) => void;
  onOpenAddFreelanceExpense: () => void;
  onOpenEditFreelanceExpense: (expense: FreelanceExpense) => void;
  onDeleteFreelanceExpense: (expenseId: string) => void;
  onOpenFreelanceGoals: () => void;
  // Common
  accounts: WalletAccount[];
  currentMonth: string;
  onNavigateToWallet?: () => void;
}

export function ExtraView({
  config,
  onSaveConfig,
  driverTrips,
  driverExpenses,
  driverGoals,
  onAddDriverTrip,
  onDeleteDriverTrip,
  onAddDriverExpense,
  onDeleteDriverExpense,
  onSaveDriverGoals,
  onSaveDriverShift,
  freelanceEntries,
  freelanceExpenses,
  freelanceGoals,
  onOpenAddFreelanceEntry,
  onOpenEditFreelanceEntry,
  onDeleteFreelanceEntry,
  onOpenAddFreelanceExpense,
  onOpenEditFreelanceExpense,
  onDeleteFreelanceExpense,
  onOpenFreelanceGoals,
  accounts,
  currentMonth,
  onNavigateToWallet
}: ExtraViewProps) {
  const [isSetupOpen, setIsSetupOpen] = useState(!config.setupCompleted);

  return (
    <div className="space-y-6">
      {/* If Motorista de App is active */}
      {config.workType === 'motorista_app' && (
        <ExtraDriverView
          trips={driverTrips}
          expenses={driverExpenses}
          goals={driverGoals}
          config={config}
          accounts={accounts}
          currentMonth={currentMonth}
          onOpenSetup={() => setIsSetupOpen(true)}
          onAddTrip={onAddDriverTrip}
          onDeleteTrip={onDeleteDriverTrip}
          onAddExpense={onAddDriverExpense}
          onDeleteExpense={onDeleteDriverExpense}
          onSaveGoals={onSaveDriverGoals}
          onSaveShift={onSaveDriverShift}
          onNavigateToWallet={onNavigateToWallet}
        />
      )}

      {/* If Freelancer / Outro is active */}
      {(config.workType === 'freelancer' || config.workType === 'outro') && (
        <div className="space-y-4">
          {/* Top Bar with switch profile */}
          <div className="flex items-center justify-between bg-white dark:bg-[#1C1C1E] px-5 py-3 rounded-2xl border border-slate-200 dark:border-white/10 shadow-2xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                <Briefcase size={18} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Perfil Atual: {config.workType === 'freelancer' ? 'Freelancer & Projetos' : 'Outros Bicos Extras'}
                </span>
                <span className="text-[10px] text-slate-400">
                  Gerencie projetos, clientes, despesas operacionais e lucro líquido
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsSetupOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/15 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <SlidersHorizontal size={13} />
              <span>Trocar Atividade</span>
            </button>
          </div>

          <FreelanceView
            entries={freelanceEntries}
            expenses={freelanceExpenses}
            goals={freelanceGoals}
            accounts={accounts}
            onOpenAddEntry={onOpenAddFreelanceEntry}
            onOpenEditEntry={onOpenEditFreelanceEntry}
            onDeleteEntry={onDeleteFreelanceEntry}
            onOpenAddExpense={onOpenAddFreelanceExpense}
            onOpenEditExpense={onOpenEditFreelanceExpense}
            onDeleteExpense={onDeleteFreelanceExpense}
            onOpenGoals={onOpenFreelanceGoals}
            currentMonth={currentMonth}
            onNavigateToWallet={onNavigateToWallet}
          />
        </div>
      )}

      {/* Setup Wizard Modal */}
      <ExtraSetupModal
        isOpen={isSetupOpen}
        onClose={() => setIsSetupOpen(false)}
        config={config}
        accounts={accounts}
        onSaveConfig={(newCfg) => {
          onSaveConfig(newCfg);
          setIsSetupOpen(false);
        }}
      />
    </div>
  );
}
