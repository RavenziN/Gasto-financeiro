import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Wallet, 
  CreditCard, 
  Grid3x3, 
  Plus, 
  X, 
  TrendingDown, 
  TrendingUp, 
  ArrowLeftRight, 
  Car, 
  Briefcase, 
  Bell, 
  TrendingUp as ChartIcon, 
  Users, 
  User as UserIcon,
  Sparkles,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MainTabType } from '../types';

interface MobileBottomNavProps {
  activeTab: MainTabType;
  onTabChange: (tab: MainTabType) => void;
  onOpenAddExpense: () => void;
  onOpenAddIncome?: () => void;
  onOpenAddWalletTransaction?: () => void;
  onOpenProfile?: () => void;
}

export function MobileBottomNav({
  activeTab,
  onTabChange,
  onOpenAddExpense,
  onOpenAddIncome,
  onOpenAddWalletTransaction,
  onOpenProfile,
}: MobileBottomNavProps) {
  const [isSpeedDialOpen, setIsSpeedDialOpen] = useState(false);
  const [isMoreSheetOpen, setIsMoreSheetOpen] = useState(false);

  const handleSelectSpeedAction = (action: () => void) => {
    setIsSpeedDialOpen(false);
    action();
  };

  return (
    <>
      {/* Backdrop for Speed Dial */}
      <AnimatePresence>
        {isSpeedDialOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSpeedDialOpen(false)}
            className="md:hidden fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs"
          />
        )}
      </AnimatePresence>

      {/* Speed Dial Menu items */}
      <AnimatePresence>
        {isSpeedDialOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="md:hidden fixed bottom-24 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2.5 w-11/12 max-w-xs p-3 bg-white dark:bg-[#1C1C1E] rounded-3xl shadow-2xl border border-slate-200/80 dark:border-white/10"
          >
            <div className="flex items-center justify-between px-2 pt-1 pb-1 border-b border-slate-100 dark:border-white/[0.08]">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles size={13} className="text-emerald-500" />
                <span>Ação Rápida</span>
              </span>
              <button
                type="button"
                onClick={() => setIsSpeedDialOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <button
              type="button"
              onClick={() => handleSelectSpeedAction(onOpenAddExpense)}
              className="flex items-center gap-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 hover:bg-rose-100 transition-colors cursor-pointer text-left"
            >
              <div className="w-9 h-9 rounded-xl bg-rose-500 text-white flex items-center justify-center shrink-0">
                <TrendingDown size={18} />
              </div>
              <div>
                <p className="text-xs font-bold">Registrar Nova Despesa</p>
                <p className="text-[10px] opacity-80">Gasto no cartão ou à vista</p>
              </div>
            </button>

            {onOpenAddIncome && (
              <button
                type="button"
                onClick={() => handleSelectSpeedAction(onOpenAddIncome)}
                className="flex items-center gap-3 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
                  <TrendingUp size={18} />
                </div>
                <div>
                  <p className="text-xs font-bold">Registrar Nova Receita</p>
                  <p className="text-[10px] opacity-80">Salário, freela ou ganho extra</p>
                </div>
              </button>
            )}

            {onOpenAddWalletTransaction && (
              <button
                type="button"
                onClick={() => handleSelectSpeedAction(onOpenAddWalletTransaction)}
                className="flex items-center gap-3 p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 transition-colors cursor-pointer text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-indigo-500 text-white flex items-center justify-center shrink-0">
                  <ArrowLeftRight size={18} />
                </div>
                <div>
                  <p className="text-xs font-bold">Transferência / Depósito</p>
                  <p className="text-[10px] opacity-80">Movimentar saldo entre contas</p>
                </div>
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* "Mais" Bottom Sheet Grid */}
      <AnimatePresence>
        {isMoreSheetOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMoreSheetOpen(false)}
              className="md:hidden fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="md:hidden fixed bottom-0 inset-x-0 z-50 bg-white dark:bg-[#1C1C1E] rounded-t-3xl p-5 border-t border-slate-200 dark:border-white/10 shadow-2xl max-h-[85vh] overflow-y-auto"
            >
              <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-4" />
              
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">Menu de Módulos</h3>
                  <p className="text-xs text-slate-400">Acesse todas as ferramentas do Gasto</p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsMoreSheetOpen(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 bg-slate-100 dark:bg-white/10 cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Grid 2x3 */}
              <div className="grid grid-cols-2 gap-3 pb-6">
                <button
                  type="button"
                  onClick={() => { setIsMoreSheetOpen(false); onTabChange('meuuber'); }}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer ${
                    activeTab === 'meuuber'
                      ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04] text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                    <Car size={24} className="stroke-[2.2]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Motorista App</p>
                    <p className="text-[10px] text-slate-400">Uber, 99, inDrive</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMoreSheetOpen(false); onTabChange('freelancer'); }}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer ${
                    activeTab === 'freelancer'
                      ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04] text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-violet-500/10 dark:bg-violet-500/20 text-violet-600 dark:text-violet-400 flex items-center justify-center">
                    <Briefcase size={24} className="stroke-[2.2]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Freelancer</p>
                    <p className="text-[10px] text-slate-400">Projetos & Ganhos</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMoreSheetOpen(false); onTabChange('assinaturas'); }}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer ${
                    activeTab === 'assinaturas'
                      ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04] text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-purple-500/10 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                    <Bell size={24} className="stroke-[2.2]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Assinaturas</p>
                    <p className="text-[10px] text-slate-400">Streaming & Contas</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMoreSheetOpen(false); onTabChange('investimentos'); }}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer ${
                    activeTab === 'investimentos'
                      ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04] text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-sky-500/10 dark:bg-sky-500/20 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                    <ChartIcon size={24} className="stroke-[2.2]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Investimentos</p>
                    <p className="text-[10px] text-slate-400">Caixinhas & Metas</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMoreSheetOpen(false); onTabChange('pessoas'); }}
                  className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer ${
                    activeTab === 'pessoas'
                      ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04] text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                    <Users size={24} className="stroke-[2.2]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Divisão & Pessoas</p>
                    <p className="text-[10px] text-slate-400">Rateio de despesas</p>
                  </div>
                </button>

                {onOpenProfile && (
                  <button
                    type="button"
                    onClick={() => { setIsMoreSheetOpen(false); onOpenProfile(); }}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04] text-slate-800 dark:text-slate-200 flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                      <UserIcon size={24} className="stroke-[2.2]" />
                    </div>
                    <div>
                      <p className="text-xs font-bold">Meu Perfil</p>
                      <p className="text-[10px] text-slate-400">Dados & Chave Pix</p>
                    </div>
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ========================================================================= */}
      {/* Clean Docked Bottom Navigation Bar with Top Straight Line Indicator */}
      {/* ========================================================================= */}
      <div className="md:hidden fixed bottom-0 inset-x-0 z-40">
        
        {/* Navigation Bar Container docked to bottom with clean white background and straight top wire */}
        <div className="w-full bg-white/95 dark:bg-[#18181B]/95 backdrop-blur-md text-slate-600 dark:text-slate-300 pb-[max(6px,env(safe-area-inset-bottom))] shadow-[0_-2px_12px_rgba(0,0,0,0.06)] dark:shadow-[0_-2px_12px_rgba(0,0,0,0.3)] border-t border-slate-200 dark:border-white/10">
          
          <nav 
            id="mobile-docked-navbar"
            aria-label="Navegação inferior"
            className="w-full max-w-md mx-auto grid grid-cols-5 items-stretch h-14"
          >
            
            {/* 1. Início Tab */}
            <button
              type="button"
              id="mobile-nav-dashboard"
              onClick={() => onTabChange('dashboard')}
              className={`relative flex flex-col items-center justify-center pt-1 pb-1 transition-colors cursor-pointer select-none active:scale-95 ${
                activeTab === 'dashboard'
                  ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300'
              }`}
            >
              {/* Top Colored Line for Active State */}
              {activeTab === 'dashboard' && (
                <motion.div 
                  layoutId="activeNavTopLine"
                  className="absolute top-0 inset-x-2 h-[2.5px] bg-emerald-600 dark:bg-emerald-400 rounded-b-full" 
                />
              )}
              <div className="relative">
                <LayoutDashboard size={20} className={activeTab === 'dashboard' ? 'stroke-[2.5]' : 'stroke-[1.6]'} />
              </div>
              <span className={`text-[10px] tracking-tight mt-0.5 leading-none ${activeTab === 'dashboard' ? 'font-bold' : 'font-medium'}`}>
                Início
              </span>
              {activeTab === 'dashboard' && (
                <span className="w-1 h-1 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-0.5" />
              )}
            </button>

            {/* 2. Carteira Tab */}
            <button
              type="button"
              id="mobile-nav-carteira"
              onClick={() => onTabChange('carteira')}
              className={`relative flex flex-col items-center justify-center pt-1 pb-1 transition-colors cursor-pointer select-none active:scale-95 ${
                activeTab === 'carteira'
                  ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300'
              }`}
            >
              {/* Top Colored Line for Active State */}
              {activeTab === 'carteira' && (
                <motion.div 
                  layoutId="activeNavTopLine"
                  className="absolute top-0 inset-x-2 h-[2.5px] bg-emerald-600 dark:bg-emerald-400 rounded-b-full" 
                />
              )}
              <div className="relative">
                <Wallet size={20} className={activeTab === 'carteira' ? 'stroke-[2.5]' : 'stroke-[1.6]'} />
              </div>
              <span className={`text-[10px] tracking-tight mt-0.5 leading-none ${activeTab === 'carteira' ? 'font-bold' : 'font-medium'}`}>
                Carteira
              </span>
              {activeTab === 'carteira' && (
                <span className="w-1 h-1 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-0.5" />
              )}
            </button>

            {/* 3. Botão de Mais (+) para Adicionar Despesa */}
            <button
              type="button"
              id="mobile-nav-add-expense"
              onClick={() => setIsSpeedDialOpen(!isSpeedDialOpen)}
              className="relative flex flex-col items-center justify-center pt-1 pb-1 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors cursor-pointer select-none active:scale-95"
              title="Adicionar Despesa / Ações Rápidas"
              aria-label="Adicionar despesa"
            >
              {isSpeedDialOpen && (
                <motion.div 
                  layoutId="activeNavTopLine"
                  className="absolute top-0 inset-x-2 h-[2.5px] bg-emerald-600 dark:bg-emerald-400 rounded-b-full" 
                />
              )}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                isSpeedDialOpen 
                  ? 'bg-emerald-600 text-white rotate-45 shadow-sm' 
                  : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100'
              }`}>
                <Plus size={18} className="stroke-[2.6]" />
              </div>
              <span className="text-[10px] tracking-tight mt-0.5 leading-none font-medium text-emerald-700 dark:text-emerald-400">
                Novo
              </span>
            </button>

            {/* 4. Cartões Tab */}
            <button
              type="button"
              id="mobile-nav-cartoes"
              onClick={() => onTabChange('cartoes')}
              className={`relative flex flex-col items-center justify-center pt-1 pb-1 transition-colors cursor-pointer select-none active:scale-95 ${
                activeTab === 'cartoes'
                  ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300'
              }`}
            >
              {/* Top Colored Line for Active State */}
              {activeTab === 'cartoes' && (
                <motion.div 
                  layoutId="activeNavTopLine"
                  className="absolute top-0 inset-x-2 h-[2.5px] bg-emerald-600 dark:bg-emerald-400 rounded-b-full" 
                />
              )}
              <div className="relative">
                <CreditCard size={20} className={activeTab === 'cartoes' ? 'stroke-[2.5]' : 'stroke-[1.6]'} />
              </div>
              <span className={`text-[10px] tracking-tight mt-0.5 leading-none ${activeTab === 'cartoes' ? 'font-bold' : 'font-medium'}`}>
                Cartões
              </span>
              {activeTab === 'cartoes' && (
                <span className="w-1 h-1 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-0.5" />
              )}
            </button>

            {/* 5. Mais Tab */}
            <button
              type="button"
              id="mobile-nav-more"
              onClick={() => setIsMoreSheetOpen(true)}
              className={`relative flex flex-col items-center justify-center pt-1 pb-1 transition-colors cursor-pointer select-none active:scale-95 ${
                ['meuuber', 'freelancer', 'assinaturas', 'investimentos', 'pessoas'].includes(activeTab) || isMoreSheetOpen
                  ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300'
              }`}
            >
              {/* Top Colored Line for Active State */}
              {(['meuuber', 'freelancer', 'assinaturas', 'investimentos', 'pessoas'].includes(activeTab) || isMoreSheetOpen) && (
                <motion.div 
                  layoutId="activeNavTopLine"
                  className="absolute top-0 inset-x-2 h-[2.5px] bg-emerald-600 dark:bg-emerald-400 rounded-b-full" 
                />
              )}
              <div className="relative">
                <Grid3x3 size={20} className={['meuuber', 'freelancer', 'assinaturas', 'investimentos', 'pessoas'].includes(activeTab) ? 'stroke-[2.5]' : 'stroke-[1.6]'} />
              </div>
              <span className={`text-[10px] tracking-tight mt-0.5 leading-none ${['meuuber', 'freelancer', 'assinaturas', 'investimentos', 'pessoas'].includes(activeTab) ? 'font-bold' : 'font-medium'}`}>
                Mais
              </span>
              {(['meuuber', 'freelancer', 'assinaturas', 'investimentos', 'pessoas'].includes(activeTab) || isMoreSheetOpen) && (
                <span className="w-1 h-1 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-0.5" />
              )}
            </button>

          </nav>
        </div>
      </div>
    </>
  );
}
