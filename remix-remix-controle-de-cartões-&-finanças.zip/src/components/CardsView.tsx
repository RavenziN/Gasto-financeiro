import React, { useState, useMemo } from 'react';
import { 
  CreditCard as CardIcon, 
  Plus, 
  Calendar, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  Edit3, 
  Trash2, 
  ChevronRight, 
  Check, 
  RotateCcw,
  Sparkles,
  Search,
  Sliders,
  Receipt,
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Tag,
  User,
  ShoppingBag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CardBillPayment, CreditCard, ExpenseItem, Person } from '../types';
import { formatCurrency, formatMonthDisplay } from '../utils/financeCalculations';
import { BankLogo, normalizeBankName } from './BankLogo';
import { PayCardBillModal } from './PayCardBillModal';
import { triggerHaptic } from '../utils/haptics';

interface CardsViewProps {
  cards: CreditCard[];
  people: Person[];
  activeExpenses: { expense: ExpenseItem; currentInstallmentForMonth?: number; totalInstallments?: number }[];
  currentMonth: string;
  paidBills: CardBillPayment[];
  onOpenAddCard: () => void;
  onEditCard: (card: CreditCard) => void;
  onDeleteCard: (cardId: string) => void;
  onOpenAddExpenseForCard: (cardId: string) => void;
  onEditExpense: (expense: ExpenseItem) => void;
  onDeleteExpense: (id: string) => void;
  onPayBill: (
    card: CreditCard,
    amount: number,
    monthYear: string,
    paymentType?: 'full' | 'partial',
    interestAmount?: number,
    rolledOverDebt?: number,
    nextMonth?: string
  ) => void;
  onUnpayBill: (cardId: string, monthYear: string) => void;
}

// Bank Color Presets & Styling
export function getBankCardStyle(bankName?: string, customGradient?: string) {
  const key = normalizeBankName(bankName);
  
  if (customGradient) {
    return {
      gradient: `bg-gradient-to-br ${customGradient}`,
      textColor: 'text-white',
      chipColor: '#FFD700',
      badgeBg: 'bg-white/20',
      brandColor: '#10B981',
    };
  }

  switch (key) {
    case 'nubank':
      return {
        gradient: 'bg-gradient-to-br from-[#820AD1] via-[#6508A5] to-[#400468]',
        textColor: 'text-white',
        chipColor: '#E2B13C',
        badgeBg: 'bg-white/15',
        brandColor: '#820AD1',
      };
    case 'itau':
      return {
        gradient: 'bg-gradient-to-br from-[#EC7000] via-[#C95300] to-[#002D72]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-black/25',
        brandColor: '#EC7000',
      };
    case 'inter':
      return {
        gradient: 'bg-gradient-to-br from-[#FF7A00] via-[#E86000] to-[#B34400]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-black/20',
        brandColor: '#FF7A00',
      };
    case 'c6':
      return {
        gradient: 'bg-gradient-to-br from-[#242428] via-[#18181B] to-[#0B0B0C]',
        textColor: 'text-white',
        chipColor: '#E5E7EB',
        badgeBg: 'bg-white/10',
        brandColor: '#3F3F46',
      };
    case 'bradesco':
      return {
        gradient: 'bg-gradient-to-br from-[#CC092F] via-[#A80625] to-[#680013]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-white/20',
        brandColor: '#CC092F',
      };
    case 'santander':
      return {
        gradient: 'bg-gradient-to-br from-[#EC0000] via-[#C40000] to-[#800000]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-white/20',
        brandColor: '#EC0000',
      };
    case 'bb':
      return {
        gradient: 'bg-gradient-to-br from-[#003882] via-[#002659] to-[#001736]',
        textColor: 'text-white',
        chipColor: '#F8D210',
        badgeBg: 'bg-[#F8D210]/20',
        brandColor: '#003882',
      };
    case 'caixa':
      return {
        gradient: 'bg-gradient-to-br from-[#005CA9] via-[#00447C] to-[#002B4E]',
        textColor: 'text-white',
        chipColor: '#F39200',
        badgeBg: 'bg-white/15',
        brandColor: '#005CA9',
      };
    case 'btg':
      return {
        gradient: 'bg-gradient-to-br from-[#0B1B3D] via-[#061026] to-[#02050E]',
        textColor: 'text-white',
        chipColor: '#D4AF37',
        badgeBg: 'bg-white/10',
        brandColor: '#D4AF37',
      };
    case 'picpay':
      return {
        gradient: 'bg-gradient-to-br from-[#11C76F] via-[#0DA35B] to-[#066135]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-black/20',
        brandColor: '#11C76F',
      };
    case 'xp':
      return {
        gradient: 'bg-gradient-to-br from-[#1A1A1E] via-[#111114] to-[#08080A]',
        textColor: 'text-white',
        chipColor: '#F5C518',
        badgeBg: 'bg-white/10',
        brandColor: '#F5C518',
      };
    case 'neon':
      return {
        gradient: 'bg-gradient-to-br from-[#00E5FF] via-[#00A3FF] to-[#0047FF]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-black/20',
        brandColor: '#00E5FF',
      };
    default:
      return {
        gradient: 'bg-gradient-to-br from-[#3B82F6] via-[#2563EB] to-[#1D4ED8]',
        textColor: 'text-white',
        chipColor: '#FFD700',
        badgeBg: 'bg-white/20',
        brandColor: '#2563EB',
      };
  }
}

export function CardsView({
  cards,
  people,
  activeExpenses,
  currentMonth,
  paidBills,
  onOpenAddCard,
  onEditCard,
  onDeleteCard,
  onOpenAddExpenseForCard,
  onEditExpense,
  onDeleteExpense,
  onPayBill,
  onUnpayBill,
}: CardsViewProps) {
  const [selectedCardId, setSelectedCardId] = useState<string>(cards[0]?.id || '');
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Fallback to first card if selected is not found
  const selectedCard = cards.find((c) => c.id === selectedCardId) || cards[0];
  const activeCardIndex = Math.max(0, cards.findIndex((c) => c.id === selectedCard?.id));

  // Expenses specifically for the selected card
  const cardExpenses = useMemo(() => {
    return activeExpenses
      .filter((e) => e.expense.cardId === selectedCard?.id)
      .filter((e) => {
        if (!searchTerm) return true;
        const term = searchTerm.toLowerCase();
        return (
          e.expense.description.toLowerCase().includes(term) ||
          e.expense.category.toLowerCase().includes(term) ||
          (e.expense.notes && e.expense.notes.toLowerCase().includes(term))
        );
      });
  }, [activeExpenses, selectedCard?.id, searchTerm]);

  // Current month total for the selected card
  const totalCardAmount = useMemo(() => {
    return activeExpenses
      .filter((e) => e.expense.cardId === selectedCard?.id)
      .reduce((acc, curr) => acc + curr.expense.amount, 0);
  }, [activeExpenses, selectedCard?.id]);

  // Check if invoice for current month is paid
  const isBillPaid = paidBills.some((p) => p.cardId === selectedCard?.id && p.monthYear === currentMonth);

  // Available limit calculation
  const cardLimit = selectedCard?.limit || 0;
  const availableLimit = Math.max(0, cardLimit - totalCardAmount);

  // Calculate days until due
  const getDueStatus = (card: CreditCard, isPaid: boolean) => {
    if (isPaid) {
      return { text: 'Fatura Paga ✓', color: 'bg-emerald-500 text-white' };
    }
    const hoje = new Date();
    const diaVencimento = card.dueDay || 15;
    const mesAtual = hoje.getMonth() + 1;
    const anoAtual = hoje.getFullYear();
    
    let vencimento = new Date(anoAtual, mesAtual - 1, diaVencimento);
    if (vencimento < hoje) {
      vencimento = new Date(anoAtual, mesAtual, diaVencimento);
    }
    
    const diff = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));

    if (diff <= 0) return { text: 'Vence Hoje!', color: 'bg-rose-500 text-white animate-pulse' };
    if (diff === 1) return { text: 'Vence Amanhã', color: 'bg-rose-500 text-white animate-pulse' };
    if (diff <= 3) return { text: `Vence em ${diff} dias`, color: 'bg-rose-500 text-white' };
    if (diff <= 7) return { text: `Vence em ${diff} dias`, color: 'bg-amber-500 text-white' };
    return { text: `Vence em ${diff} dias`, color: 'bg-white/20 text-white' };
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-4xl mx-auto">
      
      {/* Header & Add Card Action */}
      <div className="flex items-center justify-between gap-3 px-1">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white">
            Meus Cartões
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Faturas e compras ativas em {formatMonthDisplay(currentMonth)}
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenAddCard}
          className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white px-3.5 py-2 rounded-2xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
        >
          <Plus size={16} className="stroke-[2.5]" />
          <span>Novo Cartão</span>
        </button>
      </div>

      {/* Empty State */}
      {cards.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-dashed border-slate-300 dark:border-slate-800 text-center space-y-3 shadow-xs">
          <div className="w-14 h-14 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
            <CardIcon size={28} />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-white text-sm">Nenhum cartão cadastrado</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Cadastre seus cartões (Nubank, Itaú, Inter, Bradesco, etc.) para acompanhar limites e faturas automaticamente.
          </p>
          <button
            type="button"
            onClick={onOpenAddCard}
            className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer"
          >
            <Plus size={16} />
            <span>Cadastrar Meu Primeiro Cartão</span>
          </button>
        </div>
      ) : (
        <>
          {/* ========================================================================= */}
          {/* PHYSICAL CARD CAROUSEL (Inspirado no layout Fintech) */}
          {/* ========================================================================= */}
          <div className="relative">
            {/* Horizontal Scrollable Carousel Container */}
            <div className="flex gap-4 overflow-x-auto pb-4 pt-1 px-1 snap-x snap-mandatory scrollbar-none">
              {cards.map((card) => {
                const isSelected = card.id === selectedCard?.id;
                const isPaid = paidBills.some((p) => p.cardId === card.id && p.monthYear === currentMonth);
                const exp = activeExpenses.filter((e) => e.expense.cardId === card.id);
                const totalInvoice = exp.reduce((acc, curr) => acc + curr.expense.amount, 0);
                const availLimit = Math.max(0, (card.limit || 0) - totalInvoice);
                const style = getBankCardStyle(card.bank || card.name, card.gradient);
                const dueStatus = getDueStatus(card, isPaid);

                return (
                  <div
                    key={card.id}
                    onClick={() => {
                      setSelectedCardId(card.id);
                      triggerHaptic(8);
                    }}
                    className={`relative shrink-0 snap-center w-[300px] sm:w-[340px] h-[190px] sm:h-[205px] rounded-[26px] p-5 sm:p-6 transition-all duration-300 cursor-pointer select-none overflow-hidden flex flex-col justify-between ${
                      style.gradient
                    } ${
                      isSelected
                        ? 'ring-4 ring-emerald-500/80 shadow-2xl scale-[1.02] z-10'
                        : 'opacity-85 hover:opacity-100 hover:scale-[1.01] shadow-lg'
                    }`}
                  >
                    {/* Background Decorative Ambient Circles */}
                    <div className="absolute -right-8 -top-8 w-36 h-36 rounded-full bg-white/10 blur-xl pointer-events-none" />
                    <div className="absolute -left-8 -bottom-8 w-36 h-36 rounded-full bg-black/20 blur-xl pointer-events-none" />

                    {/* Top Row: Fatura Atual / Saldo + Golden EMV Chip */}
                    <div className="relative z-10 flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-semibold tracking-wider uppercase opacity-85 text-white">
                            Fatura Atual
                          </span>
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${dueStatus.color} shadow-xs`}>
                            {dueStatus.text}
                          </span>
                        </div>
                        <h3 className="text-2xl sm:text-[26px] font-black tracking-tight text-white mt-0.5 tabular-nums">
                          {formatCurrency(totalInvoice)}
                        </h3>
                        {card.limit ? (
                          <span className="text-[10px] opacity-80 text-white font-medium">
                            Disponível: {formatCurrency(availLimit)}
                          </span>
                        ) : null}
                      </div>

                      {/* Golden EMV Smart Chip */}
                      <div className="w-10 h-7 sm:w-11 sm:h-8 rounded-md bg-gradient-to-br from-[#FFE885] via-[#E8BA38] to-[#BA8812] border border-[#FFF3A8]/60 p-1 shadow-sm shrink-0 flex flex-col justify-between">
                        <div className="w-full h-[1px] bg-black/20" />
                        <div className="flex justify-between items-center px-0.5">
                          <div className="w-1.5 h-1.5 rounded-xs border border-black/30" />
                          <div className="w-2 h-[1px] bg-black/20" />
                          <div className="w-1.5 h-1.5 rounded-xs border border-black/30" />
                        </div>
                        <div className="w-full h-[1px] bg-black/20" />
                      </div>
                    </div>

                    {/* Middle Row: Masked Card Number */}
                    <div className="relative z-10 my-auto">
                      <div className="flex items-center justify-between">
                        <span className="text-xs sm:text-sm font-mono tracking-widest font-bold text-white/95 drop-shadow-xs">
                          •••• •••• •••• {card.lastDigits || '0000'}
                        </span>
                        
                        <div className="flex items-center gap-2 text-[9px] text-white/80 font-medium">
                          <span>Corte: {card.closingDay || '08'}</span>
                          <span>•</span>
                          <span>Venc: {card.dueDay || '15'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Row: Card Holder Name + Bank / Mastercard Logo */}
                    <div className="relative z-10 flex items-end justify-between pt-1">
                      <div>
                        <span className="text-[8px] sm:text-[9px] uppercase tracking-wider opacity-75 text-white block">
                          {card.bank ? `Banco ${card.bank}` : 'Cartão de Crédito'}
                        </span>
                        <p className="text-xs sm:text-sm font-bold text-white tracking-wide truncate max-w-[170px]">
                          {card.name}
                        </p>
                      </div>

                      {/* Overlapping Mastercard Circles or Bank Emblem */}
                      <div className="flex items-center gap-1.5">
                        <div className="flex -space-x-2">
                          <div className="w-5 h-5 rounded-full bg-[#EB001B] opacity-90 shadow-xs" />
                          <div className="w-5 h-5 rounded-full bg-[#F79E1B] opacity-90 shadow-xs mix-blend-screen" />
                        </div>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>

            {/* Pagination Dots Below Carousel */}
            {cards.length > 1 && (
              <div className="flex items-center justify-center gap-1.5 mt-2">
                {cards.map((card, idx) => (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => {
                      setSelectedCardId(card.id);
                      triggerHaptic(6);
                    }}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      card.id === selectedCard?.id
                        ? 'w-6 bg-emerald-600 dark:bg-emerald-400'
                        : 'w-1.5 bg-slate-300 dark:bg-white/20 hover:bg-slate-400'
                    }`}
                    title={card.name}
                  />
                ))}
              </div>
            )}
          </div>

          {/* ========================================================================= */}
          {/* QUICK ACTIONS (Ações Rápidas em Grid Limpo) */}
          {/* ========================================================================= */}
          {selectedCard && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider px-1">
                Ações Rápidas
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
                
                {/* 1. Pagar Fatura / Reabrir */}
                {isBillPaid ? (
                  <button
                    type="button"
                    onClick={() => onUnpayBill(selectedCard.id, currentMonth)}
                    className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs hover:shadow-md transition-all flex flex-col items-center justify-center text-center gap-2 cursor-pointer group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <RotateCcw size={18} />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800 dark:text-white block">
                        Reabrir Fatura
                      </span>
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                        Fatura Paga ✓
                      </span>
                    </div>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsPayModalOpen(true)}
                    disabled={totalCardAmount === 0}
                    className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/50 hover:border-emerald-400 dark:hover:border-emerald-600 shadow-xs hover:shadow-md transition-all flex flex-col items-center justify-center text-center gap-2 cursor-pointer group disabled:opacity-50"
                  >
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <CheckCircle2 size={18} className="stroke-[2.5]" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800 dark:text-white block">
                        Pagar Fatura
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">
                        {formatCurrency(totalCardAmount)}
                      </span>
                    </div>
                  </button>
                )}

                {/* 2. Novo Lançamento */}
                <button
                  type="button"
                  onClick={() => onOpenAddExpenseForCard(selectedCard.id)}
                  className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-emerald-400 dark:hover:border-emerald-600 shadow-xs hover:shadow-md transition-all flex flex-col items-center justify-center text-center gap-2 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ShoppingBag size={18} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-white block">
                      Novo Gasto
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Neste cartão
                    </span>
                  </div>
                </button>

                {/* 3. Editar Cartão */}
                <button
                  type="button"
                  onClick={() => onEditCard(selectedCard)}
                  className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs hover:shadow-md transition-all flex flex-col items-center justify-center text-center gap-2 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Edit3 size={18} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-white block">
                      Editar Limite
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Ajustar dados
                    </span>
                  </div>
                </button>

                {/* 4. Excluir Cartão */}
                <button
                  type="button"
                  onClick={() => onDeleteCard(selectedCard.id)}
                  className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-rose-300 dark:hover:border-rose-800 shadow-xs hover:shadow-md transition-all flex flex-col items-center justify-center text-center gap-2 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Trash2 size={18} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 dark:text-white block">
                      Excluir
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Remover cartão
                    </span>
                  </div>
                </button>

              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* DETAILED INVOICE & EXPENSES LIST (Schedule Payments / Compras do Cartão) */}
          {/* ========================================================================= */}
          {selectedCard && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
              
              {/* Header with Search and Summary */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                      Lançamentos da Fatura
                    </h3>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {cardExpenses.length} itens
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Compras vinculadas a {selectedCard.name} em {formatMonthDisplay(currentMonth)}
                  </p>
                </div>

                {/* Search Bar */}
                <div className="relative w-full sm:w-64">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Buscar compra..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-white/[0.04] border border-slate-200 dark:border-white/10 rounded-xl outline-none focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Items List */}
              {cardExpenses.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs space-y-2">
                  <p>Nenhuma compra lançada neste cartão para o mês selecionado.</p>
                  <button
                    type="button"
                    onClick={() => onOpenAddExpenseForCard(selectedCard.id)}
                    className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer"
                  >
                    <Plus size={14} />
                    <span>Adicionar compra agora</span>
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                  {cardExpenses.map((item) => {
                    const exp = item.expense;
                    const person = people.find((p) => p.id === exp.personId);

                    return (
                      <div
                        key={exp.id}
                        className="py-3 flex items-center justify-between gap-3 group hover:bg-slate-50/70 dark:hover:bg-slate-800/40 px-2 rounded-2xl transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-white/[0.06] flex items-center justify-center text-base shrink-0">
                            {exp.category === 'alimentacao' ? '🍔' :
                             exp.category === 'mercado' ? '🛒' :
                             exp.category === 'transporte' ? '🚗' :
                             exp.category === 'eletronicos' ? '📱' :
                             exp.category === 'vestuario' ? '👕' :
                             exp.category === 'saude' ? '💊' :
                             exp.category === 'lazer' ? '✈️' :
                             exp.category === 'servicos' ? '📺' : '🏷️'}
                          </div>

                          <div className="truncate">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                                {exp.description}
                              </span>
                              {item.currentInstallmentForMonth && (
                                <span className="px-1.5 py-0.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold rounded-md shrink-0">
                                  {item.currentInstallmentForMonth}/{item.totalInstallments}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mt-0.5">
                              <span className={`w-1.5 h-1.5 rounded-full ${person?.avatarBg || 'bg-slate-400'}`} />
                              <span>{person?.name || 'Você'}</span>
                              <span>•</span>
                              <span className="capitalize">{exp.category}</span>
                              {exp.date && (
                                <>
                                  <span>•</span>
                                  <span>{exp.date.split('-').reverse().slice(0, 2).join('/')}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Amount & Actions */}
                        <div className="flex items-center gap-3 shrink-0">
                          <div className="text-right">
                            <span className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white tabular-nums">
                              {formatCurrency(exp.amount)}
                            </span>
                            {exp.totalAmount && exp.type === 'parcelada' && (
                              <span className="block text-[9px] text-slate-400">
                                Total: {formatCurrency(exp.totalAmount)}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                            <button
                              type="button"
                              onClick={() => onEditExpense(exp)}
                              className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
                              title="Editar despesa"
                            >
                              <Edit3 size={13} />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteExpense(exp.id)}
                              className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer transition-colors"
                              title="Excluir despesa"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}

            </div>
          )}
        </>
      )}

      {/* Pay Bill Modal with interest simulation */}
      <PayCardBillModal
        isOpen={isPayModalOpen}
        onClose={() => setIsPayModalOpen(false)}
        card={selectedCard}
        currentMonth={currentMonth}
        totalAmount={totalCardAmount}
        onConfirmPayment={(paymentData) => {
          onPayBill(
            paymentData.card,
            paymentData.paidAmount,
            paymentData.monthYear,
            paymentData.paymentType,
            paymentData.interestAmount,
            paymentData.rolledOverDebt,
            paymentData.nextMonth
          );
        }}
      />
    </div>
  );
}
