import React, { useState } from 'react';
import { 
  X, 
  Car, 
  Briefcase, 
  Sparkles, 
  Check, 
  ArrowRight, 
  ArrowLeft, 
  Wallet, 
  Target, 
  Fuel, 
  Bike, 
  Zap, 
  HelpCircle,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ExtraProfileConfig, 
  ExtraWorkType, 
  DriverAppType, 
  WalletAccount,
  FreelanceCategory 
} from '../types';
import { DriverAppLogo } from './DriverAppLogo';
import { APP_CONFIGS } from '../data/initialDriverData';

interface ExtraSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ExtraProfileConfig;
  accounts: WalletAccount[];
  onSaveConfig: (newConfig: ExtraProfileConfig) => void;
}

const AVAILABLE_DRIVER_APPS: DriverAppType[] = [
  'uber',
  '99',
  'indrive',
  'ifood',
  'rappi',
  'lalamove',
  'particular',
  'blablacar',
  'outro'
];

export function ExtraSetupModal({
  isOpen,
  onClose,
  config,
  accounts,
  onSaveConfig
}: ExtraSetupModalProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [workType, setWorkType] = useState<ExtraWorkType>(config.workType || 'motorista_app');
  
  // Driver specific settings
  const [selectedApps, setSelectedApps] = useState<DriverAppType[]>(
    config.selectedApps && config.selectedApps.length > 0 
      ? config.selectedApps 
      : ['uber', '99', 'indrive']
  );
  const [vehicleType, setVehicleType] = useState<'carro_proprio' | 'carro_alugado' | 'moto' | 'bike' | 'outro'>(
    config.vehicleType || 'carro_proprio'
  );
  const [fuelType, setFuelType] = useState<'gasolina' | 'etanol' | 'gnv' | 'diesel' | 'eletrico' | 'outro'>(
    config.fuelType || 'gasolina'
  );
  const [dailyGoal, setDailyGoal] = useState<string>(
    config.dailyGoal ? String(config.dailyGoal) : '250'
  );
  const [monthlyGoal, setMonthlyGoal] = useState<string>(
    config.monthlyGoal ? String(config.monthlyGoal) : '5500'
  );
  const [defaultAccountId, setDefaultAccountId] = useState<string>(
    config.defaultAccountId || (accounts[0]?.id || '')
  );

  if (!isOpen) return null;

  const toggleApp = (app: DriverAppType) => {
    setSelectedApps(prev => {
      if (prev.includes(app)) {
        if (prev.length === 1) return prev; // Keep at least one
        return prev.filter(a => a !== app);
      }
      return [...prev, app];
    });
  };

  const handleFinish = () => {
    const cleanDaily = parseFloat(dailyGoal.replace(',', '.')) || 250;
    const cleanMonthly = parseFloat(monthlyGoal.replace(',', '.')) || 5500;

    const newConfig: ExtraProfileConfig = {
      workType,
      selectedApps: workType === 'motorista_app' ? selectedApps : ['outro'],
      vehicleType,
      fuelType,
      dailyGoal: cleanDaily,
      monthlyGoal: cleanMonthly,
      defaultAccountId,
      setupCompleted: true,
      lastCustomizedAt: new Date().toISOString()
    };

    onSaveConfig(newConfig);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
      />

      {/* Modal Card */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 10 }}
        className="relative w-full max-w-lg bg-white dark:bg-[#1C1C1E] rounded-3xl shadow-2xl border border-slate-200 dark:border-white/10 overflow-hidden flex flex-col max-h-[90vh] z-10"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Sparkles size={20} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base sm:text-lg">
                Configurar Renda Extra
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Passo {step} de 2: {step === 1 ? 'Tipo de atividade' : 'Personalização'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          {step === 1 ? (
            <div className="space-y-4">
              <div className="text-center sm:text-left space-y-1">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  O que você faz como Renda Extra?
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Vamos adaptar todo o visual, cálculos e gráficos especificamente para o seu modelo de trabalho.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3 pt-2">
                {/* Motorista / Entregador */}
                <button
                  type="button"
                  onClick={() => setWorkType('motorista_app')}
                  className={`p-4 rounded-2xl border text-left transition-all flex items-start gap-4 cursor-pointer relative ${
                    workType === 'motorista_app'
                      ? 'border-emerald-500 bg-emerald-500/5 dark:bg-emerald-500/10 shadow-sm'
                      : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20'
                  }`}
                >
                  <div className={`p-3 rounded-xl ${workType === 'motorista_app' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300'}`}>
                    <Car size={24} />
                  </div>
                  <div className="flex-1 min-w-0 pr-6">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        Motorista / Entregador de App
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400">
                        Uber, 99, iFood...
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Controle de ganhos diários separados por plataforma, gastos com gasolina, almoço, lucro líquido real e metas diárias.
                    </p>
                  </div>
                  {workType === 'motorista_app' && (
                    <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                      <Check size={14} className="stroke-[3]" />
                    </div>
                  )}
                </button>

                {/* Freelancer & Projetos */}
                <button
                  type="button"
                  onClick={() => setWorkType('freelancer')}
                  className={`p-4 rounded-2xl border text-left transition-all flex items-start gap-4 cursor-pointer relative ${
                    workType === 'freelancer'
                      ? 'border-emerald-500 bg-emerald-500/5 dark:bg-emerald-500/10 shadow-sm'
                      : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20'
                  }`}
                >
                  <div className={`p-3 rounded-xl ${workType === 'freelancer' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300'}`}>
                    <Briefcase size={24} />
                  </div>
                  <div className="flex-1 min-w-0 pr-6">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        Freelancer & Prestador de Serviços
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400">
                        Design, Dev, Aulas...
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Gestão de projetos por cliente, status de pagamento, custos de ferramentas e software, e margem de faturamento.
                    </p>
                  </div>
                  {workType === 'freelancer' && (
                    <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                      <Check size={14} className="stroke-[3]" />
                    </div>
                  )}
                </button>

                {/* Outro Bico */}
                <button
                  type="button"
                  onClick={() => setWorkType('outro')}
                  className={`p-4 rounded-2xl border text-left transition-all flex items-start gap-4 cursor-pointer relative ${
                    workType === 'outro'
                      ? 'border-emerald-500 bg-emerald-500/5 dark:bg-emerald-500/10 shadow-sm'
                      : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20'
                  }`}
                >
                  <div className={`p-3 rounded-xl ${workType === 'outro' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300'}`}>
                    <Zap size={24} />
                  </div>
                  <div className="flex-1 min-w-0 pr-6">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        Outros Trabalhos & Bicos Extras
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Vendas diretas, comércio, eventos, consultoria geral e comissões extras integradas à carteira.
                    </p>
                  </div>
                  {workType === 'outro' && (
                    <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                      <Check size={14} className="stroke-[3]" />
                    </div>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              {workType === 'motorista_app' ? (
                <>
                  {/* Apps Selection */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                      Quais aplicativos você costuma rodar? (Selecione todos que usa)
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {AVAILABLE_DRIVER_APPS.map(appId => {
                        const isSelected = selectedApps.includes(appId);
                        const appConfig = APP_CONFIGS[appId];
                        return (
                          <button
                            key={appId}
                            type="button"
                            onClick={() => toggleApp(appId)}
                            className={`p-2.5 rounded-2xl border transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center relative ${
                              isSelected
                                ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                                : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20 opacity-60'
                            }`}
                          >
                            <DriverAppLogo app={appId} size="md" />
                            <span className="text-[11px] font-bold text-slate-900 dark:text-white">
                              {appConfig?.shortName || appId}
                            </span>
                            {isSelected && (
                              <div className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                                <Check size={10} className="stroke-[3]" />
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Vehicle & Fuel */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Meio de Transporte
                      </label>
                      <select
                        value={vehicleType}
                        onChange={e => setVehicleType(e.target.value as NonNullable<ExtraProfileConfig['vehicleType']>)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="carro_proprio">🚗 Carro Próprio</option>
                        <option value="carro_alugado">🔑 Carro Alugado</option>
                        <option value="moto">🏍️ Moto</option>
                        <option value="bike">🚲 Bicicleta</option>
                        <option value="outro">📦 Outro</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Combustível / Energia
                      </label>
                      <select
                        value={fuelType}
                        onChange={e => setFuelType(e.target.value as NonNullable<ExtraProfileConfig['fuelType']>)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="gasolina">⛽ Gasolina</option>
                        <option value="etanol">🌱 Etanol</option>
                        <option value="gnv">💨 GNV</option>
                        <option value="diesel">🚚 Diesel</option>
                        <option value="eletrico">⚡ Elétrico</option>
                        <option value="outro">Outro / N/A</option>
                      </select>
                    </div>
                  </div>

                  {/* Daily Goal & Account */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Meta Diária (R$)
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">R$</span>
                        <input
                          type="text"
                          value={dailyGoal}
                          onChange={e => setDailyGoal(e.target.value)}
                          placeholder="250,00"
                          className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Conta para Saldo
                      </label>
                      <select
                        value={defaultAccountId}
                        onChange={e => setDefaultAccountId(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        {accounts.map(acc => (
                          <option key={acc.id} value={acc.id}>
                            {acc.name} ({acc.institution})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* Freelancer settings */}
                  <div className="space-y-4">
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-2">
                      <h5 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Briefcase size={16} className="text-emerald-500" />
                        Perfil Freelancer & Serviços Ativado
                      </h5>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Você terá acesso a lançamentos de projetos, controle de clientes, custos operacionais e margem de lucro líquido.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                          Meta Mensal (R$)
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">R$</span>
                          <input
                            type="text"
                            value={monthlyGoal}
                            onChange={e => setMonthlyGoal(e.target.value)}
                            placeholder="5000,00"
                            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                          Conta para Recebimentos
                        </label>
                        <select
                          value={defaultAccountId}
                          onChange={e => setDefaultAccountId(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        >
                          {accounts.map(acc => (
                            <option key={acc.id} value={acc.id}>
                              {acc.name} ({acc.institution})
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-white/[0.02]">
          {step === 2 ? (
            <button
              type="button"
              onClick={() => setStep(1)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft size={16} />
              Voltar
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white transition-all cursor-pointer"
            >
              Cancelar
            </button>
          )}

          {step === 1 ? (
            <button
              type="button"
              onClick={() => setStep(2)}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-2 cursor-pointer ml-auto"
            >
              Continuar
              <ArrowRight size={16} />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleFinish}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-2 cursor-pointer"
            >
              Salvar e Começar
              <Check size={16} />
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
