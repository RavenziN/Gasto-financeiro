import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  DollarSign, 
  Briefcase, 
  Laptop, 
  TrendingUp, 
  Gift, 
  ShoppingBag, 
  HelpCircle,
  Calendar,
  CheckCircle2,
  Repeat,
  Sparkles,
  Check,
  ArrowRight,
  Delete
} from 'lucide-react';
import { IncomeItem, IncomeCategory } from '../types';
import { formatCurrency, formatMonthDisplay } from '../utils/financeCalculations';
import { triggerHaptic } from '../utils/haptics';

interface AddIncomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (income: Partial<IncomeItem>) => void;
  editingIncome?: IncomeItem | null;
  currentMonth: string;
}

export const INCOME_CATEGORIES: {
  id: IncomeCategory;
  name: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  color: string;
  emoji: string;
}[] = [
  { id: 'salario', name: 'Salário / Fixo', icon: Briefcase, color: 'text-emerald-500', emoji: '💼' },
  { id: 'freelance', name: 'Freelance / Bicos', icon: Laptop, color: 'text-indigo-500', emoji: '💻' },
  { id: 'investimentos', name: 'Rendimentos / Juros', icon: TrendingUp, color: 'text-cyan-500', emoji: '📈' },
  { id: 'beneficios', name: 'Benefícios / VR / VA', icon: Gift, color: 'text-purple-500', emoji: '🎁' },
  { id: 'vendas', name: 'Vendas / Desapegos', icon: ShoppingBag, color: 'text-amber-500', emoji: '🛍️' },
  { id: 'outros', name: 'Outras Entradas', icon: HelpCircle, color: 'text-slate-500', emoji: '📦' },
];

export function AddIncomeModal({
  isOpen,
  onClose,
  onSave,
  editingIncome,
  currentMonth,
}: AddIncomeModalProps) {
  // Step navigation: 1 = Valor & Frequência, 2 = Detalhes & Categoria
  const [step, setStep] = useState<1 | 2>(1);

  // Keypad & Amount in Cents
  const [amountCents, setAmountCents] = useState<number>(0);
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IncomeCategory>('salario');
  const [type, setType] = useState<'fixa' | 'unica'>('fixa');
  const [date, setDate] = useState(`${currentMonth}-05`);
  const [received, setReceived] = useState(true);
  const [notes, setNotes] = useState('');

  const numericAmount = amountCents / 100;

  useEffect(() => {
    if (isOpen) {
      if (editingIncome) {
        setAmountCents(Math.round((editingIncome.amount || 0) * 100));
        setDescription(editingIncome.description || '');
        setCategory(editingIncome.category || 'salario');
        setType(editingIncome.type || 'fixa');
        setDate(editingIncome.date || `${currentMonth}-05`);
        setReceived(editingIncome.received ?? true);
        setNotes(editingIncome.notes || '');
        setStep(1);
      } else {
        setAmountCents(0);
        setDescription('');
        setCategory('salario');
        setType('fixa');
        setDate(`${currentMonth}-05`);
        setReceived(true);
        setNotes('');
        setStep(1);
      }
    }
  }, [editingIncome, isOpen, currentMonth]);

  // Handle Keypad presses for Step 1
  const handleKeypadPress = (key: string) => {
    triggerHaptic(8);
    if (key === 'backspace') {
      setAmountCents((prev) => Math.floor(prev / 10));
    } else if (key === 'clear') {
      setAmountCents(0);
    } else {
      const digit = parseInt(key, 10);
      if (!isNaN(digit)) {
        setAmountCents((prev) => {
          if (prev > 99999999) return prev;
          return prev * 10 + digit;
        });
      }
    }
  };

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
        return;
      }
      if (step === 1) {
        if (e.key >= '0' && e.key <= '9') {
          handleKeypadPress(e.key);
        } else if (e.key === 'Backspace') {
          handleKeypadPress('backspace');
        } else if (e.key === 'Enter') {
          if (numericAmount > 0) {
            triggerHaptic(12);
            setStep(2);
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, step, numericAmount, onClose]);

  if (!isOpen) return null;

  const handleContinueToStep2 = () => {
    if (numericAmount <= 0) {
      triggerHaptic(20);
      return;
    }
    triggerHaptic(10);
    setStep(2);
  };

  // Quick Direct Save (e.g. from step 1 or quick action)
  const handleQuickSaveDirect = () => {
    if (numericAmount <= 0) {
      triggerHaptic(20);
      return;
    }
    triggerHaptic(15);
    const finalDesc = description.trim() || selectedCategoryObj.name || 'Entrada / Renda';
    const monthYear = date.slice(0, 7) || currentMonth;

    onSave({
      id: editingIncome?.id,
      description: finalDesc,
      amount: numericAmount,
      category,
      type,
      monthYear,
      date,
      received,
      receivedDate: received ? (editingIncome?.receivedDate || date) : undefined,
      notes: notes.trim() || undefined,
    });
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (numericAmount <= 0) {
      triggerHaptic(20);
      return;
    }

    triggerHaptic(15);
    const finalDesc = description.trim() || selectedCategoryObj.name || 'Entrada / Renda';
    const monthYear = date.slice(0, 7) || currentMonth;

    onSave({
      id: editingIncome?.id,
      description: finalDesc,
      amount: numericAmount,
      category,
      type,
      monthYear,
      date,
      received,
      receivedDate: received ? (editingIncome?.receivedDate || date) : undefined,
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  const selectedCategoryObj = INCOME_CATEGORIES.find(c => c.id === category) || INCOME_CATEGORIES[0];

  return (
    <div 
      className="fixed inset-0 z-[100] bg-slate-100 dark:bg-zinc-950 overflow-y-auto flex flex-col w-full h-full min-h-screen"
    >
      
      {/* Full-Screen Header with Circular Back Button */}
      <header className="sticky top-0 z-30 bg-white dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800 px-4 sm:px-6 py-3.5 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              if (step === 2) {
                setStep(1);
                triggerHaptic(8);
              } else {
                onClose();
              }
            }}
            className="w-10 h-10 rounded-full bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-xs"
            title={step === 2 ? "Voltar para valor" : "Voltar"}
          >
            <ArrowLeft size={18} className="stroke-[2.5]" />
          </button>

          <div>
            <h1 className="text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight">
              {editingIncome ? 'Editar Renda' : 'Nova Entrada / Renda'}
            </h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {step === 1 ? 'Etapa 1 de 2 • Valor & Frequência' : 'Etapa 2 de 2 • Detalhes & Categoria'}
            </p>
          </div>
        </div>

        {/* Progress Indicator Pill */}
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-zinc-800 px-3 py-1.5 rounded-full">
          <span className={`w-2 h-2 rounded-full transition-all ${step === 1 ? 'bg-indigo-600 dark:bg-indigo-400 w-5' : 'bg-emerald-500'}`} />
          <span className={`w-2 h-2 rounded-full transition-all ${step === 2 ? 'bg-indigo-600 dark:bg-indigo-400 w-5' : 'bg-slate-300 dark:bg-zinc-600'}`} />
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-between">
        
        {/* ========================================================================= */}
        {/* ETAPA 1: VALOR E FREQUÊNCIA (Design Moderno em Tela Cheia)               */}
        {/* ========================================================================= */}
        {step === 1 && (
          <div className="space-y-5">
            
            {/* Income Type Capsule (Inspirado no bloco "Duration" da Imagem) */}
            <div className="bg-white dark:bg-zinc-900 p-4 sm:p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs space-y-3">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Frequência da Entrada
              </span>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => { setType('fixa'); triggerHaptic(8); }}
                  className={`py-3 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer text-center ${
                    type === 'fixa'
                      ? 'border-2 border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200/70'
                  }`}
                >
                  <div className="font-bold">Recorrente Mensal</div>
                  <div className="text-[10px] font-normal opacity-80">Salário / Renda Fixa</div>
                </button>

                <button
                  type="button"
                  onClick={() => { setType('unica'); triggerHaptic(8); }}
                  className={`py-3 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer text-center ${
                    type === 'unica'
                      ? 'border-2 border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200/70'
                  }`}
                >
                  <div className="font-bold">Entrada Pontual</div>
                  <div className="text-[10px] font-normal opacity-80">Freela / Venda / Bônus</div>
                </button>
              </div>
            </div>

            {/* Big Amount Display (Hero Value Center) */}
            <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs text-center space-y-3">
              <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
                Valor da Entrada
              </span>

              <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-emerald-600 dark:text-emerald-400 tabular-nums">
                {formatCurrency(numericAmount)}
              </h1>

              {/* Quick Amount Preset Chips */}
              <div className="flex items-center justify-center flex-wrap gap-1.5 pt-1">
                {[
                  { label: '+R$ 100', add: 10000 },
                  { label: '+R$ 500', add: 50000 },
                  { label: '+R$ 1.000', add: 100000 },
                  { label: '+R$ 2.500', add: 250000 },
                  { label: '+R$ 5.000', add: 500000 },
                ].map((chip) => (
                  <button
                    key={chip.label}
                    type="button"
                    onClick={() => {
                      triggerHaptic(8);
                      setAmountCents(prev => Math.min(prev + chip.add, 99999999));
                    }}
                    className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-zinc-800 hover:bg-emerald-500/15 hover:text-emerald-600 dark:hover:text-emerald-400 text-[11px] font-bold text-slate-600 dark:text-slate-300 transition-colors active:scale-95 cursor-pointer"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clear', '0', 'backspace'].map((key) => {
                if (key === 'backspace') {
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handleKeypadPress('backspace')}
                      className="h-12 sm:h-14 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 active:scale-95 flex items-center justify-center text-slate-700 dark:text-slate-300 font-bold transition-all cursor-pointer shadow-xs"
                      title="Apagar dígito"
                    >
                      <Delete size={22} className="stroke-[2.2]" />
                    </button>
                  );
                }

                if (key === 'clear') {
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handleKeypadPress('clear')}
                      className="h-12 sm:h-14 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 active:scale-95 flex items-center justify-center text-slate-500 dark:text-slate-400 font-bold text-xs transition-all cursor-pointer uppercase tracking-wider shadow-xs"
                      title="Limpar valor"
                    >
                      Limpar
                    </button>
                  );
                }

                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => handleKeypadPress(key)}
                    className="h-12 sm:h-14 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 active:scale-95 flex items-center justify-center text-slate-900 dark:text-white font-black text-xl transition-all cursor-pointer select-none shadow-xs"
                  >
                    {key}
                  </button>
                );
              })}
            </div>

            {/* Actions in Step 1: Quick Confirm or Continue to Details */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                id="btn-add-income-quick-save"
                disabled={numericAmount <= 0}
                onClick={handleQuickSaveDirect}
                className={`py-4 px-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                  numericAmount > 0
                    ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white shadow-emerald-600/30'
                    : 'bg-slate-200 dark:bg-zinc-800 text-slate-400 dark:text-slate-600 cursor-not-allowed shadow-none'
                }`}
              >
                <Check size={18} className="stroke-[2.5]" />
                <span>Confirmar Entrada Direta</span>
              </button>

              <button
                type="button"
                id="btn-add-income-continue"
                disabled={numericAmount <= 0}
                onClick={handleContinueToStep2}
                className={`py-4 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  numericAmount > 0
                    ? 'bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 active:scale-[0.98]'
                    : 'bg-slate-100 dark:bg-zinc-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                }`}
              >
                <span>Mais Detalhes</span>
                <ArrowRight size={18} className="stroke-[2.5]" />
              </button>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* ETAPA 2: DETALHES DA RENDA (Inspirado na 2ª Tela de Referência)          */}
        {/* ========================================================================= */}
        {step === 2 && (
          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* Reckoning / Resumo Financeiro */}
            <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-zinc-800">
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  Resumo da Entrada
                </span>
                <button
                  type="button"
                  onClick={() => { setStep(1); triggerHaptic(8); }}
                  className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                >
                  Alterar Valor
                </button>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Frequência</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {type === 'fixa' ? 'Recorrente Mensal' : 'Entrada Pontual'}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Mês de Referência</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {formatMonthDisplay(date.slice(0, 7) || currentMonth)}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-zinc-800">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Valor Total</span>
                  <span className="text-base font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {formatCurrency(numericAmount)}
                  </span>
                </div>
              </div>
            </div>

            {/* Informações da Renda */}
            <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-slate-200 dark:border-zinc-800 shadow-xs space-y-4">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Detalhes da Entrada
              </span>

              {/* 1. Descrição & Sugestões Rápidas */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Descrição do Ganho (Opcional)
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={`Ex: ${selectedCategoryObj.name}, Freela, Reembolso...`}
                  autoFocus
                  className="w-full px-4 py-3.5 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 outline-none"
                />

                {/* Quick Title Suggestions */}
                <div className="flex items-center flex-wrap gap-1.5 mt-2">
                  {[
                    { label: '💼 Salário', cat: 'salario' as const },
                    { label: '💻 Freela', cat: 'freelance' as const },
                    { label: '💰 Renda Extra', cat: 'freelance' as const },
                    { label: '📈 Rendimentos', cat: 'investimentos' as const },
                    { label: '🎁 Benefício / VR', cat: 'beneficios' as const },
                    { label: '🏷️ Venda', cat: 'vendas' as const },
                    { label: '⚡ Pix Recebido', cat: 'outros' as const },
                  ].map((sug) => (
                    <button
                      key={sug.label}
                      type="button"
                      onClick={() => {
                        triggerHaptic(6);
                        setDescription(sug.label.replace(/^[^\s]+\s/, ''));
                        setCategory(sug.cat);
                      }}
                      className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-zinc-800/80 hover:bg-emerald-500/15 hover:text-emerald-600 dark:hover:text-emerald-400 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
                    >
                      {sug.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Categoria */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Categoria da Renda
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as IncomeCategory)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs font-semibold cursor-pointer outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  {INCOME_CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.emoji} {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. Data Prevista / Recebida */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Calendar size={14} className="text-purple-500" />
                  <span>Data do Recebimento</span>
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* 4. Status de Recebimento */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-zinc-800 rounded-2xl border border-slate-200 dark:border-zinc-700">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 size={18} className={received ? 'text-emerald-500' : 'text-slate-400'} />
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">Já foi recebido?</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">Marque se o dinheiro já está na conta</p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={received}
                    onChange={(e) => setReceived(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* 5. Observações */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Observações (opcional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Desconto de impostos, bônus de performance..."
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-2xl text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-4 px-4 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-700 text-slate-700 dark:text-slate-200 rounded-2xl font-bold text-sm transition-colors cursor-pointer text-center"
              >
                Voltar
              </button>

              <button
                type="submit"
                id="btn-save-income-final"
                className="flex-[2] py-4 px-6 font-black text-white rounded-2xl text-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer bg-emerald-600 hover:bg-emerald-700 active:scale-95 shadow-emerald-600/30"
              >
                <Check size={18} className="stroke-[2.5]" />
                <span>Confirmar e Salvar Entrada</span>
              </button>
            </div>

          </form>
        )}

      </main>
    </div>
  );
}
