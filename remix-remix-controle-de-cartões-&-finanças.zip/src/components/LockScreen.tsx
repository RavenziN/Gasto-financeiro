import React, { useState, useEffect } from 'react';
import { Lock, Fingerprint, Delete } from 'lucide-react';
import { UserProfile } from '../types';

interface LockScreenProps {
  userProfile: UserProfile | null;
  onUnlock: () => void;
}

export const LockScreen: React.FC<LockScreenProps> = ({ userProfile, onUnlock }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [useBio, setUseBio] = useState(userProfile?.useBiometrics || false);

  // Dummy hash function to compare PINs (since we don't have crypto library or we can just use Web Crypto)
  // For this prototype, we'll use a simple comparison. In production, we'd hash and compare.
  const verifyPin = async (inputPin: string) => {
    // Basic hash to check against stored PIN (which would be hashed)
    const encoder = new TextEncoder();
    const data = encoder.encode(inputPin);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    if (hashHex === userProfile?.appLockPin) {
      setError(false);
      onUnlock();
    } else {
      setError(true);
      setPin('');
    }
  };

  const handleKeyPress = (digit: string) => {
    if (pin.length < 6) {
      const newPin = pin + digit;
      setPin(newPin);
      setError(false);
      
      // Se tiver 4 a 6 dígitos e for igual ao hash (vamos testar ao digitar o 4º, 5º ou 6º)
      // Como não sabemos o tamanho original do PIN do usuário, testamos em 4, 5 e 6
      if (newPin.length >= 4) {
        verifyPin(newPin);
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
    setError(false);
  };

  const handleBiometric = async () => {
    // Dummy biometrics for web (WebAuthn is complex, so we'll simulate the UX/intent)
    try {
      if (window.PublicKeyCredential) {
        // Just a UX fallback for now if WebAuthn is unsupported or not enrolled
        alert('Biometria indisponível neste navegador/dispositivo para testes locais.');
      } else {
        alert('Biometria não suportada.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (userProfile?.useBiometrics) {
      handleBiometric();
    }
  }, [userProfile]);

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-900 flex flex-col items-center justify-center p-6">
      <div className="flex flex-col items-center mb-8">
        <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4 text-emerald-500">
          <Lock size={32} />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">App Bloqueado</h1>
        <p className="text-slate-400 text-sm">Digite seu PIN para acessar seus dados</p>
      </div>

      <div className="flex gap-4 mb-8">
        {[...Array(6)].map((_, i) => (
          <div 
            key={i} 
            className={`w-4 h-4 rounded-full border-2 transition-all ${
              i < pin.length 
                ? 'bg-emerald-500 border-emerald-500' 
                : error ? 'border-rose-500' : 'border-slate-600'
            }`} 
          />
        ))}
      </div>
      
      {error && <p className="text-rose-500 text-sm mb-4">PIN incorreto. Tente novamente.</p>}

      <div className="grid grid-cols-3 gap-6 max-w-[280px] w-full">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <button
            key={num}
            onClick={() => handleKeyPress(num.toString())}
            className="w-16 h-16 rounded-full bg-slate-800 text-white text-2xl font-semibold flex items-center justify-center hover:bg-slate-700 active:bg-slate-600 transition-colors mx-auto"
          >
            {num}
          </button>
        ))}
        <button
          onClick={handleBiometric}
          disabled={!useBio}
          className={`w-16 h-16 rounded-full text-white text-2xl font-semibold flex items-center justify-center transition-colors mx-auto ${useBio ? 'bg-slate-800 hover:bg-slate-700' : 'opacity-20'}`}
        >
          <Fingerprint size={28} />
        </button>
        <button
          onClick={() => handleKeyPress('0')}
          className="w-16 h-16 rounded-full bg-slate-800 text-white text-2xl font-semibold flex items-center justify-center hover:bg-slate-700 active:bg-slate-600 transition-colors mx-auto"
        >
          0
        </button>
        <button
          onClick={handleDelete}
          className="w-16 h-16 rounded-full bg-slate-800 text-white text-2xl font-semibold flex items-center justify-center hover:bg-slate-700 active:bg-slate-600 transition-colors mx-auto"
        >
          <Delete size={24} />
        </button>
      </div>
    </div>
  );
};
