import React, { useState, useMemo, useEffect, useRef, Suspense, lazy } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged, User, signOut, updateProfile } from 'firebase/auth';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './lib/firebase';
import { sanitizeForFirestore } from './lib/sanitizeFirestore';
import { AuthView, LocalAuthUser } from './components/AuthView';
import { Header } from './components/Header';
import { GastoLogo } from './components/GastoLogo';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AddExpenseModal } from './components/AddExpenseModal';
import { AddIncomeModal } from './components/AddIncomeModal';
import { AddPersonModal } from './components/AddPersonModal';
import { AddCardModal } from './components/AddCardModal';
import { AddInvestmentFolderModal } from './components/AddInvestmentFolderModal';
import { AddInvestmentBoxModal } from './components/AddInvestmentBoxModal';
import { DepositWithdrawModal } from './components/DepositWithdrawModal';
import { ExportModal } from './components/ExportModal';
import { ConfirmDialogModal } from './components/ConfirmDialogModal';
import { OnboardingTutorialModal } from './components/OnboardingTutorialModal';
import { ProfileModal } from './components/ProfileModal';
import { AddFreelanceEntryModal } from './components/AddFreelanceEntryModal';
import { AddFreelanceExpenseModal } from './components/AddFreelanceExpenseModal';
import { FreelanceGoalsModal } from './components/FreelanceGoalsModal';
import { AddSubscriptionModal } from './components/AddSubscriptionModal';
import { AddWalletAccountModal } from './components/AddWalletAccountModal';
import { AddWalletTransactionModal } from './components/AddWalletTransactionModal';
import { OfflineBanner } from './components/OfflineBanner';
import { LegalTermsModal } from './components/LegalTermsModal';
import { useNetworkStatus } from './hooks/useNetworkStatus';

import { DashboardSkeleton } from './components/DashboardSkeleton';
import { PullToRefresh } from './components/PullToRefresh';
import { LockScreen } from './components/LockScreen';

// Code-split dynamic views for instant initial load
const ChartsDashboard = lazy(() => import('./components/ChartsDashboard').then(m => ({ default: m.ChartsDashboard })));
const PeopleSplitView = lazy(() => import('./components/PeopleSplitView').then(m => ({ default: m.PeopleSplitView })));
const CardsView = lazy(() => import('./components/CardsView').then(m => ({ default: m.CardsView })));
const InvestmentsView = lazy(() => import('./components/InvestmentsView').then(m => ({ default: m.InvestmentsView })));
const SubscriptionsView = lazy(() => import('./components/SubscriptionsView').then(m => ({ default: m.SubscriptionsView })));
const WalletView = lazy(() => import('./components/WalletView').then(m => ({ default: m.WalletView })));
const ExtraView = lazy(() => import('./components/ExtraView').then(m => ({ default: m.ExtraView })));

function ViewLoadingFallback() {
  return (
    <div className="w-full py-24 flex flex-col items-center justify-center gap-3">
      <div className="w-8 h-8 border-3 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin" />
      <p className="text-xs text-slate-400 font-medium">Carregando painel...</p>
    </div>
  );
}

import { 
  ExpenseItem, 
  IncomeItem,
  CreditCard, 
  Person, 
  InvestmentFolder, 
  InvestmentBox,
  CardBillPayment,
  UserProfile,
  MainTabType,
  SubscriptionItem,
  DriverTrip,
  DriverExpense,
  DriverGoals,
  ExtraProfileConfig,
  FreelanceEntry,
  FreelanceExpense,
  FreelanceGoals,
  WalletAccount,
  WalletTransaction
} from './types';
import { 
  INITIAL_EXPENSES, 
  INITIAL_INCOMES,
  INITIAL_CARDS, 
  INITIAL_PEOPLE, 
  INITIAL_FOLDERS, 
  INITIAL_BOXES 
} from './data/initialData';
import {
  INITIAL_SUBSCRIPTIONS,
  ServicePreset
} from './data/subscriptionPresets';
import {
  INITIAL_DRIVER_TRIPS,
  INITIAL_DRIVER_EXPENSES,
  INITIAL_DRIVER_GOALS,
  INITIAL_EXTRA_PROFILE,
  APP_CONFIGS
} from './data/initialDriverData';
import {
  INITIAL_FREELANCE_ENTRIES,
  INITIAL_FREELANCE_EXPENSES,
  INITIAL_FREELANCE_GOALS
} from './data/initialFreelanceData';
import {
  INITIAL_WALLET_ACCOUNTS,
  INITIAL_WALLET_TRANSACTIONS
} from './data/initialWalletData';
import { 
  calculateMonthSummary, 
  getActiveExpensesForMonth,
  addMonths,
  formatCurrency 
} from './utils/financeCalculations';

const STORAGE_KEYS = {
  EXPENSES: 'financas_expenses_v2',
  INCOMES: 'financas_incomes_v2',
  CARDS: 'financas_cards_v2',
  PEOPLE: 'financas_people_v2',
  FOLDERS: 'financas_inv_folders_v2',
  BOXES: 'financas_inv_boxes_v2',
  PAID_BILLS: 'financas_paid_bills_v1',
  DARK_MODE: 'financas_dark_mode_v1',
  PROFILE: 'financas_profile_v1',
  LOCAL_USER: 'financas_local_user_v1',
  DRIVER_TRIPS: 'financas_driver_trips_v1',
  DRIVER_EXPENSES: 'financas_driver_expenses_v1',
  DRIVER_GOALS: 'financas_driver_goals_v1',
  DRIVER_INTRO_SEEN: 'financas_driver_intro_seen_v1',
  EXTRA_PROFILE: 'financas_extra_profile_v1',
  FREELANCE_ENTRIES: 'financas_freelance_entries_v1',
  FREELANCE_EXPENSES: 'financas_freelance_expenses_v1',
  FREELANCE_GOALS: 'financas_freelance_goals_v1',
  SUBSCRIPTIONS: 'financas_subscriptions_v1',
  WALLET_ACCOUNTS: 'financas_wallet_accounts_v1',
  WALLET_TRANSACTIONS: 'financas_wallet_transactions_v1',
};

type AppUser = User | LocalAuthUser;

export default function App() {
  // Auth state
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LOCAL_USER);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return null;
  });
  const [authLoading, setAuthLoading] = useState(true);
  const [dataLoadedFromCloud, setDataLoadedFromCloud] = useState(false);
  const isInitialLoadRef = useRef(true);
  const loadedUidRef = useRef<string | null>(null);

  // Theme State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DARK_MODE);
      if (saved !== null) {
        return saved === 'true';
      }
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch (e) {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DARK_MODE, String(isDarkMode));
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch (e) {
      console.error('Error saving dark mode', e);
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);
        try {
          const userObj: LocalAuthUser = {
            uid: user.uid,
            email: user.email || undefined,
            displayName: user.displayName || undefined,
            photoURL: user.photoURL || undefined,
          };
          localStorage.setItem(STORAGE_KEYS.LOCAL_USER, JSON.stringify(userObj));
        } catch (e) {
          console.error('Error caching auth session to localStorage:', e);
        }
      } else {
        const saved = localStorage.getItem(STORAGE_KEYS.LOCAL_USER);
        if (saved) {
          try {
            setCurrentUser(JSON.parse(saved));
          } catch (e) {
            setCurrentUser(null);
          }
        }
      }
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLocalLogin = (user: LocalAuthUser) => {
    setCurrentUser(user);
    try {
      localStorage.setItem(STORAGE_KEYS.LOCAL_USER, JSON.stringify(user));
    } catch (e) {
      console.error('Error saving local user session:', e);
    }
  };

  // Current active month in view (default August 2026)
  const [currentMonth, setCurrentMonth] = useState<string>('2026-08');
  const [activeTab, setActiveTab] = useState<MainTabType>('dashboard');

  const MASTER_ACCOUNT_EMAIL = 'pedrootavio10k@gmail.com';

  // Persistence State
  const [expenses, setExpenses] = useState<ExpenseItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EXPENSES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading expenses', e);
    }
    return INITIAL_EXPENSES;
  });

  const [incomes, setIncomes] = useState<IncomeItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INCOMES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading incomes', e);
    }
    return INITIAL_INCOMES;
  });

  const [cards, setCards] = useState<CreditCard[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CARDS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.map((c: CreditCard) => {
          if (c.id === 'card-nubank') return { ...c, dueDay: 15, closingDay: 8 };
          if (c.id === 'card-itau') return { ...c, dueDay: 8, closingDay: 1 };
          if (c.id === 'card-mercadopago') return { ...c, dueDay: 17, closingDay: 10 };
          return c;
        });
      }
    } catch (e) {
      console.error('Error loading cards', e);
    }
    return INITIAL_CARDS;
  });

  const [people, setPeople] = useState<Person[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PEOPLE);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading people', e);
    }
    return INITIAL_PEOPLE;
  });

  const [folders, setFolders] = useState<InvestmentFolder[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FOLDERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading investment folders', e);
    }
    return INITIAL_FOLDERS;
  });

  const [boxes, setBoxes] = useState<InvestmentBox[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BOXES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter(b => !b.id.startsWith('box-nu-reserva') && !b.id.startsWith('box-tesouro') && !b.id.startsWith('box-viagem') && !b.id.startsWith('box-passeios') && !b.id.startsWith('box-carro') && !b.id.startsWith('box-notebook') && !b.id.startsWith('box-fiis') && !b.id.startsWith('box-acoes'));
        }
      }
    } catch (e) {
      console.error('Error loading investment boxes', e);
    }
    return INITIAL_BOXES;
  });

  // Paid Credit Card Bills history
  const [paidBills, setPaidBills] = useState<CardBillPayment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PAID_BILLS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading paid bills', e);
    }
    return [];
  });

  // Driver / MeuUber State
  const [driverTrips, setDriverTrips] = useState<DriverTrip[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DRIVER_TRIPS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading driver trips', e);
    }
    return INITIAL_DRIVER_TRIPS;
  });

  const [driverExpenses, setDriverExpenses] = useState<DriverExpense[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DRIVER_EXPENSES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading driver expenses', e);
    }
    return INITIAL_DRIVER_EXPENSES;
  });

  const [driverGoals, setDriverGoals] = useState<DriverGoals>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DRIVER_GOALS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading driver goals', e);
    }
    return INITIAL_DRIVER_GOALS;
  });

  // Extra Profile Config State (Motorista de App / Freelancer / Outro)
  const [extraProfile, setExtraProfile] = useState<ExtraProfileConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EXTRA_PROFILE);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading extra profile', e);
    }
    return INITIAL_EXTRA_PROFILE;
  });

  // Freelancer & Projetos State
  const [freelanceEntries, setFreelanceEntries] = useState<FreelanceEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FREELANCE_ENTRIES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading freelance entries', e);
    }
    return INITIAL_FREELANCE_ENTRIES;
  });

  const [freelanceExpenses, setFreelanceExpenses] = useState<FreelanceExpense[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FREELANCE_EXPENSES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading freelance expenses', e);
    }
    return INITIAL_FREELANCE_EXPENSES;
  });

  const [freelanceGoals, setFreelanceGoals] = useState<FreelanceGoals>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FREELANCE_GOALS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading freelance goals', e);
    }
    return INITIAL_FREELANCE_GOALS;
  });

  const [isAddFreelanceEntryOpen, setIsAddFreelanceEntryOpen] = useState(false);
  const [editingFreelanceEntry, setEditingFreelanceEntry] = useState<FreelanceEntry | null>(null);
  const [isAddFreelanceExpenseOpen, setIsAddFreelanceExpenseOpen] = useState(false);
  const [editingFreelanceExpense, setEditingFreelanceExpense] = useState<FreelanceExpense | null>(null);
  const [isFreelanceGoalsOpen, setIsFreelanceGoalsOpen] = useState(false);

  // Subscriptions State
  const [subscriptions, setSubscriptions] = useState<SubscriptionItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUBSCRIPTIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading subscriptions', e);
    }
    return INITIAL_SUBSCRIPTIONS;
  });

  const [isAddSubscriptionOpen, setIsAddSubscriptionOpen] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<SubscriptionItem | null>(null);

  // Wallet / Bank Accounts & Balances State
  const [walletAccounts, setWalletAccounts] = useState<WalletAccount[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WALLET_ACCOUNTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading wallet accounts', e);
    }
    return INITIAL_WALLET_ACCOUNTS;
  });

  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WALLET_TRANSACTIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading wallet transactions', e);
    }
    return INITIAL_WALLET_TRANSACTIONS;
  });

  const [isAddWalletAccountOpen, setIsAddWalletAccountOpen] = useState(false);
  const [editingWalletAccount, setEditingWalletAccount] = useState<WalletAccount | null>(null);
  const [isAddWalletTransactionOpen, setIsAddWalletTransactionOpen] = useState(false);
  const [walletTransactionMode, setWalletTransactionMode] = useState<'expense' | 'income' | 'transfer' | 'adjust'>('expense');
  const [walletPreselectedAccountId, setWalletPreselectedAccountId] = useState<string | undefined>(undefined);

  // User Profile State
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading user profile', e);
    }
    return {};
  });

  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isLegalTermsOpen, setIsLegalTermsOpen] = useState(false);
  const isOnline = useNetworkStatus();

  // App Lock State
  const [isLocked, setIsLocked] = useState(false);
  const [initialLockChecked, setInitialLockChecked] = useState(false);
  const lastActiveRef = useRef<number>(Date.now());

  useEffect(() => {
    if (dataLoadedFromCloud && userProfile.appLockEnabled && !initialLockChecked) {
      setIsLocked(true);
      setInitialLockChecked(true);
    } else if (dataLoadedFromCloud && !initialLockChecked) {
      setInitialLockChecked(true);
    }
  }, [dataLoadedFromCloud, userProfile.appLockEnabled, initialLockChecked]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        lastActiveRef.current = Date.now();
      } else {
        if (userProfile.appLockEnabled && !isLocked) {
          const timeout = 60 * 1000; // 1 min
          if (Date.now() - lastActiveRef.current > timeout) {
            setIsLocked(true);
          }
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [userProfile.appLockEnabled, isLocked]);

  // Onboarding Tutorial State
  const [isTutorialOpen, setIsTutorialOpen] = useState(false);
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);

  const loadUserData = async (isMounted = true) => {
    if (!currentUser) return;
    const targetUid = currentUser.uid;
    const isMaster = currentUser.email?.toLowerCase() === MASTER_ACCOUNT_EMAIL.toLowerCase();
    const userKeyPrefix = `user_${targetUid}_`;

    try {
      const userDocRef = doc(db, 'users', targetUid);
      const docSnap = await getDoc(userDocRef);

      const authUser = auth.currentUser || ('providerData' in currentUser ? currentUser : null);
      const gName = authUser?.displayName || authUser?.providerData?.[0]?.displayName || currentUser?.displayName;
      const gEmail = authUser?.email || authUser?.providerData?.[0]?.email || currentUser?.email;
      const gPhoto = authUser?.photoURL || authUser?.providerData?.[0]?.photoURL || currentUser?.photoURL;
      const gPhone = authUser?.phoneNumber || authUser?.providerData?.[0]?.phoneNumber || ('phoneNumber' in currentUser ? (currentUser as { phoneNumber?: string }).phoneNumber : undefined);

      const initialProf: UserProfile = {
        name: gName || undefined,
        nickname: gName || undefined,
        email: gEmail || undefined,
        photoURL: gPhoto || undefined,
        photoSource: gPhoto ? 'google' : undefined,
        phone: gPhone || undefined,
      };

      if (docSnap.exists() && isMounted) {
        const data = docSnap.data();
        setExpenses(data.expenses || []);
        setIncomes(data.incomes || []);
        setCards(data.cards || []);
        setPeople(data.people || INITIAL_PEOPLE);
        setFolders(data.folders || INITIAL_FOLDERS);
        const rawBoxes: InvestmentBox[] = data.boxes || [];
        const cleanedBoxes = rawBoxes.filter(b => !b.id.startsWith('box-nu-reserva') && !b.id.startsWith('box-tesouro') && !b.id.startsWith('box-viagem') && !b.id.startsWith('box-passeios') && !b.id.startsWith('box-carro') && !b.id.startsWith('box-notebook') && !b.id.startsWith('box-fiis') && !b.id.startsWith('box-acoes'));
        setBoxes(cleanedBoxes);
        setPaidBills(data.paidBills || []);
        setSubscriptions(data.subscriptions || INITIAL_SUBSCRIPTIONS);
        setDriverTrips(data.driverTrips || INITIAL_DRIVER_TRIPS);
        setDriverExpenses(data.driverExpenses || INITIAL_DRIVER_EXPENSES);
        setDriverGoals(data.driverGoals || INITIAL_DRIVER_GOALS);
        setExtraProfile(data.extraProfile || INITIAL_EXTRA_PROFILE);
        setFreelanceEntries(data.freelanceEntries || INITIAL_FREELANCE_ENTRIES);
        setFreelanceExpenses(data.freelanceExpenses || INITIAL_FREELANCE_EXPENSES);
        setFreelanceGoals(data.freelanceGoals || INITIAL_FREELANCE_GOALS);
        setWalletAccounts(data.walletAccounts || INITIAL_WALLET_ACCOUNTS);
        setWalletTransactions(data.walletTransactions || INITIAL_WALLET_TRANSACTIONS);

        if (data.profile) {
          const isPlaceholderName = data.profile.name === 'Usuário Google';
          const isPlaceholderEmail = data.profile.email === 'usuario.google@gmail.com';

          const resolvedName = (!isPlaceholderName && data.profile.name) ? data.profile.name : (gName || data.profile.name || undefined);
          const resolvedNickname = (!isPlaceholderName && data.profile.nickname) ? data.profile.nickname : (gName || data.profile.nickname || undefined);
          const resolvedEmail = (!isPlaceholderEmail && data.profile.email) ? data.profile.email : (gEmail || data.profile.email || undefined);
          const resolvedPhoto = data.profile.photoURL || gPhoto || undefined;

          const mergedProfile: UserProfile = {
            name: resolvedName,
            nickname: resolvedNickname,
            email: resolvedEmail,
            photoURL: resolvedPhoto,
            photoSource: data.profile.photoSource || (resolvedPhoto ? 'google' : undefined),
            phone: data.profile.phone || gPhone || undefined,
            ...data.profile,
            ...(isPlaceholderName && gName ? { name: gName, nickname: gName } : {}),
            ...(isPlaceholderEmail && gEmail ? { email: gEmail } : {}),
          };
          setUserProfile(mergedProfile);
          localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PROFILE, JSON.stringify(mergedProfile));
        } else {
          setUserProfile(initialProf);
          localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PROFILE, JSON.stringify(initialProf));
        }
      } else if (isMounted) {
        // Brand new account on Firestore
        const defaultSelfName = gName ? `Meu (${gName})` : 'Meu';
        const initialPeople: Person[] = [
          { id: 'person-me', name: defaultSelfName, avatarBg: 'bg-emerald-600', isSelf: true }
        ];
        const initialFolders: InvestmentFolder[] = [
          { id: 'folder-reserva', name: 'Reserva de Emergência', color: '#10B981', icon: 'shield', description: 'Segurança financeira' },
          { id: 'folder-sonhos', name: 'Metas & Sonhos', color: '#3B82F6', icon: 'sparkles', description: 'Conquistas futuras' }
        ];
        const initialExp = isMaster ? INITIAL_EXPENSES : [];
        const initialInc = isMaster ? INITIAL_INCOMES : [];
        const initialCds = isMaster ? INITIAL_CARDS : [];
        const initialBxs = isMaster ? INITIAL_BOXES : [];

        await setDoc(userDocRef, sanitizeForFirestore({
          expenses: initialExp,
          incomes: initialInc,
          cards: initialCds,
          people: isMaster ? INITIAL_PEOPLE : initialPeople,
          folders: initialFolders,
          boxes: initialBxs,
          paidBills: [],
          subscriptions: INITIAL_SUBSCRIPTIONS,
          driverTrips: INITIAL_DRIVER_TRIPS,
          driverExpenses: INITIAL_DRIVER_EXPENSES,
          driverGoals: INITIAL_DRIVER_GOALS,
          extraProfile: INITIAL_EXTRA_PROFILE,
          freelanceEntries: INITIAL_FREELANCE_ENTRIES,
          freelanceExpenses: INITIAL_FREELANCE_EXPENSES,
          freelanceGoals: INITIAL_FREELANCE_GOALS,
          walletAccounts: INITIAL_WALLET_ACCOUNTS,
          walletTransactions: INITIAL_WALLET_TRANSACTIONS,
          profile: initialProf,
          updatedAt: new Date().toISOString(),
        }), { merge: true });

        setExpenses(initialExp);
        setIncomes(initialInc);
        setCards(initialCds);
        setPeople(isMaster ? INITIAL_PEOPLE : initialPeople);
        setFolders(initialFolders);
        setBoxes(initialBxs);
        setPaidBills([]);
        setSubscriptions(INITIAL_SUBSCRIPTIONS);
        setDriverTrips(INITIAL_DRIVER_TRIPS);
        setDriverExpenses(INITIAL_DRIVER_EXPENSES);
        setDriverGoals(INITIAL_DRIVER_GOALS);
        setExtraProfile(INITIAL_EXTRA_PROFILE);
        setFreelanceEntries(INITIAL_FREELANCE_ENTRIES);
        setFreelanceExpenses(INITIAL_FREELANCE_EXPENSES);
        setFreelanceGoals(INITIAL_FREELANCE_GOALS);
        setWalletAccounts(INITIAL_WALLET_ACCOUNTS);
        setWalletTransactions(INITIAL_WALLET_TRANSACTIONS);
        setUserProfile(initialProf);
        localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PROFILE, JSON.stringify(initialProf));

        if (!isMaster) {
          setIsTutorialOpen(true);
        }
      }
    } catch (err) {
      console.warn('Firestore load notice:', err);
    } finally {
      if (isMounted) {
        loadedUidRef.current = targetUid;
        setDataLoadedFromCloud(true);
        isInitialLoadRef.current = false;
      }
    }
  };

  // Load user data from Firestore/Local Storage when logged in
  useEffect(() => {
    if (!currentUser) {
      setDataLoadedFromCloud(false);
      loadedUidRef.current = null;
      return;
    }

    let isMounted = true;
    if (loadedUidRef.current !== currentUser.uid) {
      setDataLoadedFromCloud(false);
    }

    loadUserData(isMounted);

    return () => {
      isMounted = false;
    };
  }, [currentUser]);

  // Sync to Firestore & localStorage when data changes
  useEffect(() => {
    if (!currentUser || !dataLoadedFromCloud || loadedUidRef.current !== currentUser.uid) {
      return;
    }

    const userKeyPrefix = `user_${currentUser.uid}_`;
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.INCOMES, JSON.stringify(incomes));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.BOXES, JSON.stringify(boxes));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.FOLDERS, JSON.stringify(folders));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PAID_BILLS, JSON.stringify(paidBills));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.SUBSCRIPTIONS, JSON.stringify(subscriptions));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.DRIVER_TRIPS, JSON.stringify(driverTrips));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.DRIVER_EXPENSES, JSON.stringify(driverExpenses));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.DRIVER_GOALS, JSON.stringify(driverGoals));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.EXTRA_PROFILE, JSON.stringify(extraProfile));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.FREELANCE_ENTRIES, JSON.stringify(freelanceEntries));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.FREELANCE_EXPENSES, JSON.stringify(freelanceExpenses));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.FREELANCE_GOALS, JSON.stringify(freelanceGoals));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.WALLET_ACCOUNTS, JSON.stringify(walletAccounts));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.WALLET_TRANSACTIONS, JSON.stringify(walletTransactions));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.CARDS, JSON.stringify(cards));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PEOPLE, JSON.stringify(people));
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PROFILE, JSON.stringify(userProfile));

    const timeoutId = setTimeout(async () => {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await setDoc(userDocRef, sanitizeForFirestore({
          expenses,
          incomes,
          cards,
          people,
          folders,
          boxes,
          paidBills,
          subscriptions,
          driverTrips,
          driverExpenses,
          driverGoals,
          extraProfile,
          freelanceEntries,
          freelanceExpenses,
          freelanceGoals,
          walletAccounts,
          walletTransactions,
          profile: userProfile,
          updatedAt: new Date().toISOString(),
        }), { merge: true });
      } catch (e) {
        console.warn('Firestore sync notice:', e);
      }
    }, 600);

    return () => clearTimeout(timeoutId);
  }, [expenses, incomes, cards, people, folders, boxes, paidBills, subscriptions, driverTrips, driverExpenses, driverGoals, extraProfile, freelanceEntries, freelanceExpenses, freelanceGoals, walletAccounts, walletTransactions, userProfile, currentUser, dataLoadedFromCloud]);

  // Modal States
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<ExpenseItem | null>(null);
  const [defaultPersonId, setDefaultPersonId] = useState<string | undefined>(undefined);
  const [defaultCardId, setDefaultCardId] = useState<string | undefined>(undefined);

  const [isAddPersonOpen, setIsAddPersonOpen] = useState(false);
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [isAddCardOpen, setIsAddCardOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<CreditCard | null>(null);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Investment Modals State
  const [isAddFolderOpen, setIsAddFolderOpen] = useState(false);
  const [editingFolder, setEditingFolder] = useState<InvestmentFolder | null>(null);

  const [isAddBoxOpen, setIsAddBoxOpen] = useState(false);
  const [editingBox, setEditingBox] = useState<InvestmentBox | null>(null);
  const [defaultFolderIdForBox, setDefaultFolderIdForBox] = useState<string | undefined>(undefined);

  const [isDepositWithdrawOpen, setIsDepositWithdrawOpen] = useState(false);
  const [selectedBoxForDeposit, setSelectedBoxForDeposit] = useState<InvestmentBox | null>(null);
  const [depositModalType, setDepositModalType] = useState<'deposit' | 'withdraw'>('deposit');

  // Unified Custom Confirm Dialog State
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    confirmText?: string;
    cancelText?: string;
    variant?: 'danger' | 'warning' | 'info';
    icon?: 'trash' | 'warning' | 'reset';
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {},
  });

  // Active month calculations
  const activeExpenses = useMemo(() => {
    return getActiveExpensesForMonth(expenses, currentMonth);
  }, [expenses, currentMonth]);

  const summary = useMemo(() => {
    return calculateMonthSummary(expenses, currentMonth);
  }, [expenses, currentMonth]);

  // Handlers: Expense
  const handleSaveExpense = (expenseData: Partial<ExpenseItem>) => {
    if (expenseData.id) {
      setExpenses(prev => prev.map(exp => exp.id === expenseData.id ? { ...exp, ...expenseData } as ExpenseItem : exp));
    } else {
      const newExp: ExpenseItem = {
        id: `exp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        description: expenseData.description || 'Novo Gasto',
        category: expenseData.category || 'outros',
        amount: expenseData.amount || 0,
        totalAmount: expenseData.totalAmount,
        type: expenseData.type || 'unica',
        cardId: expenseData.cardId || cards[0]?.id || '',
        personId: expenseData.personId || people[0]?.id || '',
        totalInstallments: expenseData.totalInstallments,
        currentInstallment: expenseData.currentInstallment || 1,
        startMonthYear: expenseData.startMonthYear || currentMonth,
        date: expenseData.date || `${currentMonth}-01`,
        notes: expenseData.notes,
        paidByPerson: expenseData.paidByPerson || false,
      };
      setExpenses(prev => [newExp, ...prev]);
    }
  };

  const handleEditExpense = (expense: ExpenseItem) => {
    setEditingExpense(expense);
    setIsAddExpenseOpen(true);
  };

  const handleDeleteExpense = (id: string) => {
    const itemToDelete = expenses.find(e => e.id === id);
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Gasto',
      description: itemToDelete 
        ? `Tem certeza que deseja excluir "${itemToDelete.description}"? Essa ação não pode ser desfeita.`
        : 'Tem certeza que deseja excluir este lançamento?',
      confirmText: 'Excluir Lançamento',
      cancelText: 'Voltar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setExpenses(prev => prev.filter(e => e.id !== id));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleToggleExpensePaid = (id: string) => {
    setExpenses(prev => prev.map(exp => {
      if (exp.id === id) {
        const nextPaid = !exp.paidByPerson;
        return {
          ...exp,
          paidByPerson: nextPaid,
          paidDate: nextPaid ? new Date().toISOString() : undefined,
        };
      }
      return exp;
    }));
  };

  const handleMarkAllPersonExpensesPaid = (personId: string, month: string) => {
    const personObj = people.find(p => p.id === personId);
    setConfirmDialog({
      isOpen: true,
      title: 'Confirmar Pagamento Total',
      description: `Deseja marcar todas as compras pendentes de ${personObj?.name || 'esta pessoa'} em ${month} como quitadas?`,
      confirmText: 'Marcar como Pagas',
      cancelText: 'Cancelar',
      variant: 'info',
      icon: 'warning',
      onConfirm: () => {
        setExpenses(prev => prev.map(exp => {
          if (exp.personId === personId) {
            return {
              ...exp,
              paidByPerson: true,
              paidDate: new Date().toISOString(),
            };
          }
          return exp;
        }));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Handlers: Person
  const handleSavePerson = (personData: Partial<Person>) => {
    if (personData.id) {
      setPeople(prev => prev.map(p => p.id === personData.id ? { ...p, ...personData } as Person : p));
    } else {
      const newPerson: Person = {
        id: `person-${Date.now()}`,
        name: personData.name || 'Nova Pessoa',
        avatarBg: personData.avatarBg || 'bg-slate-500',
        photoURL: personData.photoURL,
        pixKey: personData.pixKey,
        phone: personData.phone,
        email: personData.email,
        cpf: personData.cpf,
        notes: personData.notes,
      };
      setPeople(prev => [...prev, newPerson]);
    }
  };

  const handleDeletePerson = (personId: string) => {
    const personObj = people.find(p => p.id === personId);
    if (personObj?.isSelf) return;
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Pessoa',
      description: `Deseja excluir "${personObj?.name || ''}" da divisão de contas? As compras associadas a ela permanecerão no seu histórico e serão transferidas para o Titular (Você).`,
      confirmText: 'Excluir Pessoa',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        const selfPerson = people.find(p => p.isSelf) || people[0];
        if (selfPerson) {
          setExpenses(prev => prev.map(exp => exp.personId === personId ? { ...exp, personId: selfPerson.id } : exp));
        }
        setPeople(prev => prev.filter(p => p.id !== personId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Handlers: Card
  const handleSaveCard = (cardData: Partial<CreditCard>) => {
    if (cardData.id) {
      setCards(prev => prev.map(c => c.id === cardData.id ? { ...c, ...cardData } as CreditCard : c));
    } else {
      const newCard: CreditCard = {
        id: `card-${Date.now()}`,
        name: cardData.name || 'Novo Cartão',
        bank: cardData.bank || 'Banco',
        lastDigits: cardData.lastDigits,
        color: cardData.color || '#3b82f6',
        gradient: cardData.gradient || 'from-blue-600 to-indigo-900',
        limit: cardData.limit || 1000,
        closingDay: cardData.closingDay || 15,
        dueDay: cardData.dueDay || 22,
      };
      setCards(prev => [...prev, newCard]);
    }
  };

  const handleEditCard = (card: CreditCard) => {
    setEditingCard(card);
    setIsAddCardOpen(true);
  };

  const handleOpenAddCard = () => {
    setEditingCard(null);
    setIsAddCardOpen(true);
  };

  const handleDeleteCard = (cardId: string) => {
    const cardObj = cards.find(c => c.id === cardId);
    const relatedExpensesCount = expenses.filter(e => e.cardId === cardId).length;
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Cartão de Crédito',
      description: `Tem certeza que deseja excluir o cartão "${cardObj?.name || 'este cartão'}"? ${
        relatedExpensesCount > 0 
          ? `As ${relatedExpensesCount} despesas vinculadas a ele serão desvinculadas e mantidas no seu histórico de gastos.` 
          : 'Ele será removido da sua lista de cartões.'
      }`,
      confirmText: 'Excluir Cartão',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setCards(prev => prev.filter(c => c.id !== cardId));
        setExpenses(prev => prev.map(e => e.cardId === cardId ? { ...e, cardId: undefined } : e));
        setPaidBills(prev => prev.filter(p => p.cardId !== cardId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Handlers: Investment Folder
  const handleSaveFolder = (folderData: Partial<InvestmentFolder>) => {
    if (folderData.id) {
      setFolders(prev => prev.map(f => f.id === folderData.id ? { ...f, ...folderData } as InvestmentFolder : f));
    } else {
      const newFolder: InvestmentFolder = {
        id: `folder-${Date.now()}`,
        name: folderData.name || 'Nova Pasta',
        color: folderData.color || '#10b981',
        icon: folderData.icon || 'Folder',
        description: folderData.description,
      };
      setFolders(prev => [...prev, newFolder]);
    }
  };

  const handleDeleteFolder = (folderId: string) => {
    const folderObj = folders.find(f => f.id === folderId);
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Pasta de Caixinhas',
      description: `Deseja excluir a pasta "${folderObj?.name || ''}"? As caixinhas dentro dela serão movidas para a pasta geral.`,
      confirmText: 'Excluir Pasta',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setFolders(prev => prev.filter(f => f.id !== folderId));
        setBoxes(prev => prev.map(b => b.folderId === folderId ? { ...b, folderId: 'default' } : b));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Handlers: Investment Box
  const handleSaveBox = (boxData: Partial<InvestmentBox>) => {
    if (boxData.id) {
      setBoxes(prev => prev.map(b => b.id === boxData.id ? { ...b, ...boxData, updatedAt: new Date().toISOString() } as InvestmentBox : b));
    } else {
      const newBox: InvestmentBox = {
        id: `box-${Date.now()}`,
        folderId: boxData.folderId || 'default',
        title: boxData.title || 'Nova Caixinha',
        currentBalance: boxData.currentBalance || 0,
        targetAmount: boxData.targetAmount,
        monthlyYieldPercent: boxData.monthlyYieldPercent || 1.0,
        yieldDescription: boxData.yieldDescription || '100% CDI',
        institution: boxData.institution || 'Nubank',
        color: boxData.color || '#10b981',
        icon: boxData.icon || 'PiggyBank',
        notes: boxData.notes,
        history: boxData.currentBalance && boxData.currentBalance > 0 ? [{
          id: `tx-${Date.now()}`,
          type: 'deposit',
          amount: boxData.currentBalance,
          date: new Date().toISOString().split('T')[0],
          notes: 'Saldo inicial',
        }] : [],
        updatedAt: new Date().toISOString(),
      };
      setBoxes(prev => [...prev, newBox]);
    }
  };

  const handleDeleteBox = (boxId: string) => {
    const boxObj = boxes.find(b => b.id === boxId);
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Caixinha',
      description: `Tem certeza que deseja excluir "${boxObj?.title || ''}" e todo seu histórico de rendimentos?`,
      confirmText: 'Excluir Caixinha',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setBoxes(prev => prev.filter(b => b.id !== boxId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleDepositWithdraw = (boxId: string, amount: number, mode: 'deposit' | 'withdraw', notes?: string) => {
    setBoxes(prev => prev.map(box => {
      if (box.id === boxId) {
        const newBalance = mode === 'deposit' 
          ? box.currentBalance + amount 
          : Math.max(0, box.currentBalance - amount);

        const newTx = {
          id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          type: mode,
          amount,
          date: new Date().toISOString().split('T')[0],
          notes: notes || (mode === 'deposit' ? 'Aporte manual' : 'Resgate manual'),
        };

        return {
          ...box,
          currentBalance: newBalance,
          history: [newTx, ...(box.history || [])],
          updatedAt: new Date().toISOString(),
        };
      }
      return box;
    }));
  };

  const handleOpenDepositModal = (box: InvestmentBox) => {
    setSelectedBoxForDeposit(box);
    setDepositModalType('deposit');
    setIsDepositWithdrawOpen(true);
  };

  const handleOpenWithdrawModal = (box: InvestmentBox) => {
    setSelectedBoxForDeposit(box);
    setDepositModalType('withdraw');
    setIsDepositWithdrawOpen(true);
  };

  const handleOpenAddBoxForFolder = (folderId?: string) => {
    setEditingBox(null);
    setDefaultFolderIdForBox(folderId);
    setIsAddBoxOpen(true);
  };

  // Card Bill Payment & Invoice Closing Logic
  const handlePayBill = (
    card: CreditCard,
    amount: number,
    monthYear: string,
    paymentType: 'full' | 'partial' = 'full',
    interestAmount = 0,
    rolledOverDebt = 0,
    nextMonth = addMonths(monthYear, 1)
  ) => {
    const isPartial = paymentType === 'partial';
    setConfirmDialog({
      isOpen: true,
      title: isPartial ? 'Confirmar Pagamento Parcial (Rotativo)' : 'Confirmar Pagamento Integral da Fatura',
      description: isPartial
        ? `Pagamento parcial de R$ ${amount.toFixed(2)} registrado para o cartão "${card.name}". O saldo remanescente com juros de R$ ${rolledOverDebt.toFixed(2)} será transferido para a fatura de ${nextMonth}.`
        : `Deseja marcar a fatura do cartão "${card.name}" do mês ${monthYear} no valor de R$ ${amount.toFixed(2)} como PAGA?`,
      confirmText: 'Confirmar Pagamento',
      cancelText: 'Cancelar',
      variant: 'info',
      icon: 'reset',
      onConfirm: () => {
        setPaidBills(prev => {
          const filtered = prev.filter(p => !(p.cardId === card.id && p.monthYear === monthYear));
          return [
            ...filtered,
            {
              id: `bill-pay-${Date.now()}`,
              cardId: card.id,
              monthYear,
              amount,
              paidDate: new Date().toISOString(),
            }
          ];
        });

        // If partial payment with rolled-over debt, add adjustment expense to next month
        if (isPartial && rolledOverDebt > 0) {
          const rolloverExpense: ExpenseItem = {
            id: `rollover-${Date.now()}`,
            description: `🔄 Saldo Rolado & Juros (${card.name})`,
            amount: rolledOverDebt,
            date: `${nextMonth}-10`,
            startMonthYear: nextMonth,
            category: 'outros',
            type: 'unica',
            cardId: card.id,
            personId: people.find(p => p.isSelf)?.id || people[0]?.id || '1',
            notes: `Juros de rotativo simulados (Juros: R$ ${interestAmount.toFixed(2)})`,
          };
          setExpenses(prev => [rolloverExpense, ...prev]);
        }

        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleUnpayBill = (cardId: string, monthYear: string) => {
    setPaidBills(prev => prev.filter(p => !(p.cardId === cardId && p.monthYear === monthYear)));
  };

  const handleAdvanceToNextMonth = () => {
    setCurrentMonth(prev => addMonths(prev, 1));
  };

  // Reset to starter data
  const handleResetData = () => {
    setConfirmDialog({
      isOpen: true,
      title: 'Restaurar Dados Iniciais',
      description: 'Deseja restaurar as faturas, entradas e caixinhas para os dados padrão? Todas as informações personalizadas adicionadas nesta conta serão redefinidas.',
      confirmText: 'Restaurar Dados',
      cancelText: 'Cancelar',
      variant: 'warning',
      icon: 'reset',
      onConfirm: () => {
        setExpenses(INITIAL_EXPENSES);
        setIncomes(INITIAL_INCOMES);
        setCards(INITIAL_CARDS);
        setPeople(INITIAL_PEOPLE);
        setFolders(INITIAL_FOLDERS);
        setBoxes(INITIAL_BOXES);
        setSubscriptions(INITIAL_SUBSCRIPTIONS);
        setDriverTrips(INITIAL_DRIVER_TRIPS);
        setDriverExpenses(INITIAL_DRIVER_EXPENSES);
        setDriverGoals(INITIAL_DRIVER_GOALS);
        setWalletAccounts(INITIAL_WALLET_ACCOUNTS);
        setWalletTransactions(INITIAL_WALLET_TRANSACTIONS);
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Quick Open Modal with defaults
  const handleOpenAddExpenseWithDefaults = (personId?: string, cardId?: string) => {
    setEditingExpense(null);
    setDefaultPersonId(personId);
    setDefaultCardId(cardId);
    setIsAddExpenseOpen(true);
  };

  // Handlers: Income & Cash Flow
  const [isAddIncomeOpen, setIsAddIncomeOpen] = useState(false);
  const [editingIncome, setEditingIncome] = useState<IncomeItem | null>(null);

  const handleSaveIncome = (incomeData: Partial<IncomeItem>) => {
    if (incomeData.id) {
      setIncomes(prev => prev.map(inc => inc.id === incomeData.id ? { ...inc, ...incomeData } as IncomeItem : inc));
    } else {
      const newInc: IncomeItem = {
        id: `inc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        description: incomeData.description || 'Nova Entrada',
        amount: incomeData.amount || 0,
        category: incomeData.category || 'salario',
        type: incomeData.type || 'fixa',
        monthYear: incomeData.monthYear || currentMonth,
        date: incomeData.date || `${currentMonth}-05`,
        received: incomeData.received ?? true,
        receivedDate: incomeData.receivedDate,
        notes: incomeData.notes,
      };
      setIncomes(prev => [newInc, ...prev]);
    }
  };

  const handleEditIncome = (income: IncomeItem) => {
    setEditingIncome(income);
    setIsAddIncomeOpen(true);
  };

  const handleDeleteIncome = (id: string) => {
    const incToDelete = incomes.find(i => i.id === id);
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Entrada',
      description: incToDelete
        ? `Tem certeza que deseja excluir "${incToDelete.description}"? Essa ação não pode ser desfeita.`
        : 'Tem certeza que deseja excluir esta entrada?',
      confirmText: 'Excluir Entrada',
      cancelText: 'Voltar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setIncomes(prev => prev.filter(i => i.id !== id));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleToggleIncomeReceived = (id: string) => {
    setIncomes(prev => prev.map(inc => {
      if (inc.id === id) {
        const nextReceived = !inc.received;
        return {
          ...inc,
          received: nextReceived,
          receivedDate: nextReceived ? new Date().toISOString().split('T')[0] : undefined,
        };
      }
      return inc;
    }));
  };

  // Driver / Renda Extra Handlers (With Real-Time Wallet Balance Sync)
  const handleSaveDriverTrip = (tripData: Omit<DriverTrip, 'id'>, editId?: string) => {
    const net = tripData.netAmount || tripData.grossAmount;
    if (editId) {
      const oldTrip = driverTrips.find(t => t.id === editId);
      if (oldTrip) {
        const oldNet = oldTrip.netAmount || oldTrip.grossAmount;
        // Revert old account balance
        if (oldTrip.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === oldTrip.accountId ? { ...a, currentBalance: a.currentBalance - oldNet } : a));
        }
        // Apply new account balance
        if (tripData.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === tripData.accountId ? { ...a, currentBalance: a.currentBalance + net } : a));
        }

        // Update linked wallet transaction
        if (oldTrip.walletTxId) {
          setWalletTransactions(prev => prev.map(tx => {
            if (tx.id === oldTrip.walletTxId) {
              return {
                ...tx,
                accountId: tripData.accountId || tx.accountId,
                amount: net,
                description: `🚗 Ganho ${tripData.app.toUpperCase()}: ${tripData.notes || 'Corrida/Entrega'}`,
                date: tripData.date,
                time: tripData.time,
                notes: tripData.notes,
              };
            }
            return tx;
          }));
        }
      }

      setDriverTrips(prev => prev.map(t => t.id === editId ? { ...tripData, id: editId, walletTxId: t.walletTxId } : t));
    } else {
      const newTripId = `trip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newTxId = `wtx-dtrip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      // Create linked wallet transaction & update account balance
      if (tripData.accountId) {
        const newWalletTx: WalletTransaction = {
          id: newTxId,
          accountId: tripData.accountId,
          type: 'deposito',
          amount: net,
          description: `🚗 Ganho ${tripData.app.toUpperCase()}: ${tripData.notes || 'Corrida/Entrega'}`,
          category: 'renda_extra',
          date: tripData.date,
          time: tripData.time,
          recipientOrPayer: APP_CONFIGS[tripData.app]?.name || tripData.app,
          notes: tripData.notes,
          createdAt: new Date().toISOString(),
        };

        setWalletTransactions(prev => [newWalletTx, ...prev]);
        setWalletAccounts(prev => prev.map(a => a.id === tripData.accountId ? { ...a, currentBalance: a.currentBalance + net } : a));
      }

      const newTrip: DriverTrip = {
        ...tripData,
        id: newTripId,
        walletTxId: tripData.accountId ? newTxId : undefined,
      };
      setDriverTrips(prev => [newTrip, ...prev]);

      // If synced to incomes, also create an income entry
      if (tripData.syncToIncome) {
        const newInc: IncomeItem = {
          id: `inc-uber-${Date.now()}`,
          description: `Renda Extra: ${tripData.app.toUpperCase()} - ${tripData.origin || 'Ganho App'}`,
          amount: net,
          category: 'freelance',
          type: 'unica',
          monthYear: tripData.date.substring(0, 7),
          date: tripData.date,
          received: true,
          receivedDate: tripData.date,
          notes: `Lançado via Módulo Extra`
        };
        setIncomes(prev => [newInc, ...prev]);
      }
    }
  };

  const handleDeleteDriverTrip = (tripId: string) => {
    const trip = driverTrips.find(t => t.id === tripId);
    if (!trip) return;

    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Ganho de App',
      description: `Deseja excluir o ganho de ${formatCurrency(trip.netAmount || trip.grossAmount)} (${trip.app.toUpperCase()})? O valor será estornado do saldo da sua carteira sincronizada.`,
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        const net = trip.netAmount || trip.grossAmount;
        if (trip.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === trip.accountId ? { ...a, currentBalance: a.currentBalance - net } : a));
        }
        if (trip.walletTxId) {
          setWalletTransactions(prev => prev.filter(tx => tx.id !== trip.walletTxId));
        }

        setDriverTrips(prev => prev.filter(t => t.id !== tripId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleSaveDriverExpense = (expenseData: Omit<DriverExpense, 'id'>, editId?: string) => {
    if (editId) {
      const oldExp = driverExpenses.find(e => e.id === editId);
      if (oldExp) {
        // Revert old account balance
        if (oldExp.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === oldExp.accountId ? { ...a, currentBalance: a.currentBalance + oldExp.amount } : a));
        }
        // Apply new account balance
        if (expenseData.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === expenseData.accountId ? { ...a, currentBalance: a.currentBalance - expenseData.amount } : a));
        }

        // Update linked wallet transaction
        if (oldExp.walletTxId) {
          setWalletTransactions(prev => prev.map(tx => {
            if (tx.id === oldExp.walletTxId) {
              return {
                ...tx,
                accountId: expenseData.accountId || tx.accountId,
                amount: expenseData.amount,
                description: `⛽ Despesa Extra (${expenseData.category}): ${expenseData.description}`,
                date: expenseData.date,
                time: expenseData.time,
                notes: expenseData.notes,
              };
            }
            return tx;
          }));
        }
      }

      setDriverExpenses(prev => prev.map(e => e.id === editId ? { ...expenseData, id: editId, walletTxId: e.walletTxId } : e));
    } else {
      const newExpId = `dexp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newTxId = `wtx-dexp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      if (expenseData.accountId) {
        const newWalletTx: WalletTransaction = {
          id: newTxId,
          accountId: expenseData.accountId,
          type: 'debito',
          amount: expenseData.amount,
          description: `⛽ Despesa Extra (${expenseData.category}): ${expenseData.description}`,
          category: 'transporte',
          date: expenseData.date,
          time: expenseData.time,
          notes: expenseData.notes,
          createdAt: new Date().toISOString(),
        };

        setWalletTransactions(prev => [newWalletTx, ...prev]);
        setWalletAccounts(prev => prev.map(a => a.id === expenseData.accountId ? { ...a, currentBalance: a.currentBalance - expenseData.amount } : a));
      }

      const newExpense: DriverExpense = {
        ...expenseData,
        id: newExpId,
        walletTxId: expenseData.accountId ? newTxId : undefined,
      };
      setDriverExpenses(prev => [newExpense, ...prev]);
    }
  };

  const handleDeleteDriverExpense = (expenseId: string) => {
    const exp = driverExpenses.find(e => e.id === expenseId);
    if (!exp) return;

    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Despesa Operacional',
      description: `Deseja excluir a despesa "${exp.description}" (${formatCurrency(exp.amount)})? O valor será creditado de volta na sua conta sincronizada.`,
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        if (exp.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === exp.accountId ? { ...a, currentBalance: a.currentBalance + exp.amount } : a));
        }
        if (exp.walletTxId) {
          setWalletTransactions(prev => prev.filter(tx => tx.id !== exp.walletTxId));
        }

        setDriverExpenses(prev => prev.filter(e => e.id !== expenseId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleSaveDriverGoals = (newGoals: DriverGoals) => {
    setDriverGoals(newGoals);
  };

  const handleSaveDriverShift = (
    shiftTrips: Omit<DriverTrip, 'id' | 'createdAt'>[],
    shiftExpenses: Omit<DriverExpense, 'id' | 'createdAt'>[]
  ) => {
    const newTrips: DriverTrip[] = [];
    const newExpenses: DriverExpense[] = [];
    const newWalletTxs: WalletTransaction[] = [];
    const accountDeltas: Record<string, number> = {};

    shiftTrips.forEach(t => {
      const tripId = `trip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const txId = `wtx-dtrip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const net = t.netAmount || t.grossAmount;

      if (t.accountId) {
        newWalletTxs.push({
          id: txId,
          accountId: t.accountId,
          type: 'deposito',
          amount: net,
          description: `🚗 Ganho ${t.app.toUpperCase()}: Fechamento do dia`,
          category: 'renda_extra',
          date: t.date,
          time: t.time,
          recipientOrPayer: APP_CONFIGS[t.app]?.name || t.app,
          notes: t.notes,
          createdAt: new Date().toISOString(),
        });
        accountDeltas[t.accountId] = (accountDeltas[t.accountId] || 0) + net;
      }

      newTrips.push({
        ...t,
        id: tripId,
        walletTxId: t.accountId ? txId : undefined,
      });
    });

    shiftExpenses.forEach(e => {
      const expId = `dexp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const txId = `wtx-dexp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      if (e.accountId) {
        newWalletTxs.push({
          id: txId,
          accountId: e.accountId,
          type: 'debito',
          amount: e.amount,
          description: `⛽ Gasto Operacional: ${e.description}`,
          category: 'transporte',
          date: e.date,
          time: e.time,
          notes: e.notes,
          createdAt: new Date().toISOString(),
        });
        accountDeltas[e.accountId] = (accountDeltas[e.accountId] || 0) - e.amount;
      }

      newExpenses.push({
        ...e,
        id: expId,
        walletTxId: e.accountId ? txId : undefined,
      });
    });

    if (newTrips.length > 0) {
      setDriverTrips(prev => [...newTrips, ...prev]);
    }
    if (newExpenses.length > 0) {
      setDriverExpenses(prev => [...newExpenses, ...prev]);
    }
    if (newWalletTxs.length > 0) {
      setWalletTransactions(prev => [...newWalletTxs, ...prev]);
      setWalletAccounts(prev => prev.map(a => {
        const delta = accountDeltas[a.id];
        return delta ? { ...a, currentBalance: a.currentBalance + delta } : a;
      }));
    }
  };

  // Freelancer & Projetos Handlers (With Real-Time Wallet Balance Sync)
  const handleSaveFreelanceEntry = (entryData: Omit<FreelanceEntry, 'id'>, editId?: string) => {
    if (editId) {
      const oldEntry = freelanceEntries.find(e => e.id === editId);
      if (oldEntry) {
        // Revert old account balance
        if (oldEntry.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === oldEntry.accountId ? { ...a, currentBalance: a.currentBalance - oldEntry.amount } : a));
        }
        // Apply new account balance
        if (entryData.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === entryData.accountId ? { ...a, currentBalance: a.currentBalance + entryData.amount } : a));
        }

        // Update linked wallet transaction
        if (oldEntry.walletTxId) {
          setWalletTransactions(prev => prev.map(tx => {
            if (tx.id === oldEntry.walletTxId) {
              return {
                ...tx,
                accountId: entryData.accountId || tx.accountId,
                amount: entryData.amount,
                description: `💰 Freela: ${entryData.title}${entryData.clientName ? ` (${entryData.clientName})` : ''}`,
                date: entryData.date,
                time: entryData.time,
                recipientOrPayer: entryData.clientName || 'Cliente Freela',
                notes: entryData.notes,
              };
            }
            return tx;
          }));
        }
      }

      setFreelanceEntries(prev => prev.map(e => e.id === editId ? { ...entryData, id: editId, walletTxId: e.walletTxId } : e));
    } else {
      const newEntryId = `fe-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newTxId = `wtx-fe-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      // Create linked wallet transaction & update account balance
      if (entryData.accountId) {
        const newWalletTx: WalletTransaction = {
          id: newTxId,
          accountId: entryData.accountId,
          type: 'deposito',
          amount: entryData.amount,
          description: `💰 Freela: ${entryData.title}${entryData.clientName ? ` (${entryData.clientName})` : ''}`,
          category: 'renda_extra',
          date: entryData.date,
          time: entryData.time,
          recipientOrPayer: entryData.clientName || 'Cliente Freela',
          notes: entryData.notes,
          createdAt: new Date().toISOString(),
        };

        setWalletTransactions(prev => [newWalletTx, ...prev]);
        setWalletAccounts(prev => prev.map(a => a.id === entryData.accountId ? { ...a, currentBalance: a.currentBalance + entryData.amount } : a));
      }

      const newEntry: FreelanceEntry = {
        ...entryData,
        id: newEntryId,
        walletTxId: entryData.accountId ? newTxId : undefined,
      };

      setFreelanceEntries(prev => [newEntry, ...prev]);

      // If sync to general incomes is requested
      if (entryData.syncToIncome) {
        const newInc: IncomeItem = {
          id: `inc-freela-${Date.now()}`,
          description: `Freela: ${entryData.title}${entryData.clientName ? ` (${entryData.clientName})` : ''}`,
          amount: entryData.amount,
          category: 'freelance',
          type: 'unica',
          monthYear: entryData.date.substring(0, 7),
          date: entryData.date,
          received: entryData.status === 'recebido',
          receivedDate: entryData.status === 'recebido' ? entryData.date : undefined,
          notes: `Lançado via Módulo Freelancer (${entryData.category})`
        };
        setIncomes(prev => [newInc, ...prev]);
      }
    }
  };

  const handleDeleteFreelanceEntry = (entryId: string) => {
    const entry = freelanceEntries.find(e => e.id === entryId);
    if (!entry) return;

    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Entrada Freelance',
      description: `Deseja excluir a entrada "${entry.title}" (${formatCurrency(entry.amount)})? O valor será estornado do saldo da sua carteira sincronizada.`,
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        // Revert wallet balance & remove wallet tx
        if (entry.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === entry.accountId ? { ...a, currentBalance: a.currentBalance - entry.amount } : a));
        }
        if (entry.walletTxId) {
          setWalletTransactions(prev => prev.filter(tx => tx.id !== entry.walletTxId));
        }

        setFreelanceEntries(prev => prev.filter(e => e.id !== entryId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleSaveFreelanceExpense = (expenseData: Omit<FreelanceExpense, 'id'>, editId?: string) => {
    if (editId) {
      const oldExp = freelanceExpenses.find(e => e.id === editId);
      if (oldExp) {
        // Revert old account balance
        if (oldExp.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === oldExp.accountId ? { ...a, currentBalance: a.currentBalance + oldExp.amount } : a));
        }
        // Apply new account balance
        if (expenseData.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === expenseData.accountId ? { ...a, currentBalance: a.currentBalance - expenseData.amount } : a));
        }

        // Update linked wallet transaction
        if (oldExp.walletTxId) {
          setWalletTransactions(prev => prev.map(tx => {
            if (tx.id === oldExp.walletTxId) {
              return {
                ...tx,
                accountId: expenseData.accountId || tx.accountId,
                amount: expenseData.amount,
                description: `💼 Despesa Freela: ${expenseData.description}`,
                date: expenseData.date,
                time: expenseData.time,
                notes: expenseData.notes,
              };
            }
            return tx;
          }));
        }
      }

      setFreelanceExpenses(prev => prev.map(e => e.id === editId ? { ...expenseData, id: editId, walletTxId: e.walletTxId } : e));
    } else {
      const newExpId = `fexp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newTxId = `wtx-fexp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      // Deduct from wallet account & record transaction
      if (expenseData.accountId) {
        const newWalletTx: WalletTransaction = {
          id: newTxId,
          accountId: expenseData.accountId,
          type: 'debito',
          amount: expenseData.amount,
          description: `💼 Despesa Freela: ${expenseData.description}`,
          category: 'servicos',
          date: expenseData.date,
          time: expenseData.time,
          notes: expenseData.notes,
          createdAt: new Date().toISOString(),
        };

        setWalletTransactions(prev => [newWalletTx, ...prev]);
        setWalletAccounts(prev => prev.map(a => a.id === expenseData.accountId ? { ...a, currentBalance: a.currentBalance - expenseData.amount } : a));
      }

      const newExpense: FreelanceExpense = {
        ...expenseData,
        id: newExpId,
        walletTxId: expenseData.accountId ? newTxId : undefined,
      };

      setFreelanceExpenses(prev => [newExpense, ...prev]);
    }
  };

  const handleDeleteFreelanceExpense = (expenseId: string) => {
    const exp = freelanceExpenses.find(e => e.id === expenseId);
    if (!exp) return;

    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Despesa Freelance',
      description: `Deseja excluir a despesa "${exp.description}" (${formatCurrency(exp.amount)})? O valor será creditado de volta na sua conta sincronizada.`,
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        // Revert wallet balance & remove wallet tx
        if (exp.accountId) {
          setWalletAccounts(prev => prev.map(a => a.id === exp.accountId ? { ...a, currentBalance: a.currentBalance + exp.amount } : a));
        }
        if (exp.walletTxId) {
          setWalletTransactions(prev => prev.filter(tx => tx.id !== exp.walletTxId));
        }

        setFreelanceExpenses(prev => prev.filter(e => e.id !== expenseId));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleSaveFreelanceGoals = (newGoals: FreelanceGoals) => {
    setFreelanceGoals(newGoals);
  };

  // Subscription Handlers
  const handleSaveSubscription = (subData: Partial<SubscriptionItem>) => {
    if (subData.id) {
      setSubscriptions(prev => prev.map(s => s.id === subData.id ? { ...s, ...subData } as SubscriptionItem : s));
    } else {
      const newSub: SubscriptionItem = {
        id: `sub-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: subData.name || 'Nova Assinatura',
        serviceKey: subData.serviceKey || subData.name?.toLowerCase() || 'custom',
        amount: subData.amount || 0,
        category: subData.category || 'streaming',
        billingCycle: subData.billingCycle || 'mensal',
        billingDay: subData.billingDay || 10,
        cardId: subData.cardId,
        personId: subData.personId,
        active: subData.active ?? true,
        autoRenew: subData.autoRenew ?? true,
        color: subData.color,
        notes: subData.notes,
      };
      setSubscriptions(prev => [newSub, ...prev]);
    }
  };

  const handleDeleteSubscription = (id: string) => {
    const subToDelete = subscriptions.find(s => s.id === id);
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Assinatura',
      description: subToDelete 
        ? `Deseja remover a assinatura "${subToDelete.name}" (${formatCurrency(subToDelete.amount)}/${subToDelete.billingCycle}) do seu monitoramento?`
        : 'Deseja remover esta assinatura?',
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setSubscriptions(prev => prev.filter(s => s.id !== id));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleToggleSubscriptionActive = (id: string) => {
    setSubscriptions(prev => prev.map(s => s.id === id ? { ...s, active: !s.active } : s));
  };

  const handleQuickAddPreset = (preset: ServicePreset) => {
    const defaultCard = cards[0]?.id;
    const defaultPerson = people.find(p => p.isSelf)?.id || people[0]?.id;
    const newSub: SubscriptionItem = {
      id: `sub-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: preset.name,
      serviceKey: preset.serviceKey,
      amount: preset.defaultAmount,
      category: preset.category,
      billingCycle: 'mensal',
      billingDay: preset.suggestedBillingDay || 10,
      cardId: defaultCard,
      personId: defaultPerson,
      active: true,
      autoRenew: true,
      color: preset.color,
      notes: preset.description,
    };
    setSubscriptions(prev => [newSub, ...prev]);
  };

  const handleEditSubscription = (sub: SubscriptionItem) => {
    setEditingSubscription(sub);
    setIsAddSubscriptionOpen(true);
  };

  // Wallet Handlers
  const handleSaveWalletAccount = (accData: Partial<WalletAccount>) => {
    if (accData.id) {
      setWalletAccounts(prev => prev.map(a => a.id === accData.id ? { ...a, ...accData } as WalletAccount : a));
    } else {
      const newAcc: WalletAccount = {
        id: `acc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: accData.name || 'Nova Conta',
        institution: accData.institution || 'Nubank',
        accountType: accData.accountType || 'corrente',
        initialBalance: accData.initialBalance || 0,
        currentBalance: accData.initialBalance || 0,
        color: accData.color || '#8A05BE',
        pixKey: accData.pixKey,
        isDefault: accData.isDefault || false,
        includeInTotal: accData.includeInTotal ?? true,
        createdAt: new Date().toISOString(),
      };
      if (newAcc.isDefault) {
        setWalletAccounts(prev => [...prev.map(a => ({ ...a, isDefault: false })), newAcc]);
      } else {
        setWalletAccounts(prev => [...prev, newAcc]);
      }
    }
  };

  const handleDeleteWalletAccount = (id: string) => {
    const acc = walletAccounts.find(a => a.id === id);
    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Conta Bancária',
      description: acc 
        ? `Tem certeza que deseja excluir a conta "${acc.name}"? As movimentações associadas a ela permanecerão no extrato histórico.`
        : 'Tem certeza que deseja excluir esta conta?',
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        setWalletAccounts(prev => prev.filter(a => a.id !== id));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleAddWalletTransaction = (
    txData: Omit<WalletTransaction, 'id' | 'createdAt'>,
    transferData?: { toAccountId: string }
  ) => {
    let resolvedAccountId = txData.accountId;
    const isExit = ['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(txData.type);

    // If there are no accounts yet, auto-create a default "Carteira Principal"
    if (walletAccounts.length === 0) {
      const defaultAcc: WalletAccount = {
        id: `acc-default-${Date.now()}`,
        name: 'Carteira Principal',
        institution: 'Outro',
        accountType: 'corrente',
        initialBalance: isExit ? -txData.amount : txData.amount,
        currentBalance: isExit ? -txData.amount : txData.amount,
        color: 'emerald',
        includeInTotal: true,
        createdAt: new Date().toISOString(),
      };
      resolvedAccountId = defaultAcc.id;
      setWalletAccounts([defaultAcc]);
    } else if (!resolvedAccountId && walletAccounts.length > 0) {
      resolvedAccountId = walletAccounts.find(a => a.isDefault)?.id || walletAccounts[0].id;
    }

    const newTxId = `wtx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newTx: WalletTransaction = {
      ...txData,
      accountId: resolvedAccountId,
      id: newTxId,
      createdAt: new Date().toISOString(),
    };

    // If it's a transfer between own accounts
    if (txData.type === 'transferencia_saida' && transferData?.toAccountId && resolvedAccountId) {
      const incomingTx: WalletTransaction = {
        id: `wtx-${Date.now() + 1}-${Math.random().toString(36).substring(2, 6)}`,
        accountId: transferData.toAccountId,
        type: 'transferencia_entrada',
        amount: txData.amount,
        description: `Transferência recebida de ${walletAccounts.find(a => a.id === resolvedAccountId)?.name || 'conta'}`,
        category: 'transferencia',
        date: txData.date,
        time: txData.time,
        recipientOrPayer: walletAccounts.find(a => a.id === resolvedAccountId)?.name,
        fromAccountId: resolvedAccountId,
        createdAt: new Date().toISOString(),
      };

      setWalletTransactions(prev => [newTx, incomingTx, ...prev]);

      // Deduct from source and credit to destination
      setWalletAccounts(prev => prev.map(acc => {
        if (acc.id === resolvedAccountId) {
          return { ...acc, currentBalance: acc.currentBalance - txData.amount };
        }
        if (acc.id === transferData.toAccountId) {
          return { ...acc, currentBalance: acc.currentBalance + txData.amount };
        }
        return acc;
      }));
      return;
    }

    // Standard transaction (expense or income)
    setWalletTransactions(prev => [newTx, ...prev]);

    // Update account balance if account is linked
    if (resolvedAccountId && walletAccounts.length > 0) {
      setWalletAccounts(prev => prev.map(acc => {
        if (acc.id === resolvedAccountId) {
          const newBal = isExit 
            ? acc.currentBalance - txData.amount
            : acc.currentBalance + txData.amount;
          return { ...acc, currentBalance: newBal };
        }
        return acc;
      }));
    }
  };

  const handleAdjustWalletBalance = (accountId: string, newBalance: number, notes?: string) => {
    const acc = walletAccounts.find(a => a.id === accountId);
    if (!acc) return;
    const diff = newBalance - acc.currentBalance;

    const newTx: WalletTransaction = {
      id: `wtx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      accountId,
      type: 'ajuste',
      amount: Math.abs(diff),
      description: diff >= 0 ? `Ajuste positivo de saldo (+${formatCurrency(diff)})` : `Ajuste negativo de saldo (-${formatCurrency(Math.abs(diff))})`,
      category: 'ajuste',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      notes: notes || undefined,
      createdAt: new Date().toISOString(),
    };

    setWalletTransactions(prev => [newTx, ...prev]);
    setWalletAccounts(prev => prev.map(a => a.id === accountId ? { ...a, currentBalance: newBalance } : a));
  };

  const handleDeleteWalletTransaction = (id: string) => {
    const tx = walletTransactions.find(t => t.id === id);
    if (!tx) return;

    setConfirmDialog({
      isOpen: true,
      title: 'Excluir Movimentação',
      description: `Deseja excluir a movimentação "${tx.description}" (${formatCurrency(tx.amount)})? O saldo da conta será recalculado automaticamente.`,
      confirmText: 'Excluir',
      cancelText: 'Cancelar',
      variant: 'danger',
      icon: 'trash',
      onConfirm: () => {
        // Revert balance
        const isExit = ['pix_out', 'debito', 'dinheiro_gasto', 'transferencia_saida'].includes(tx.type);
        const isEntry = ['pix_in', 'deposito', 'transferencia_entrada'].includes(tx.type);

        if (isExit) {
          setWalletAccounts(prev => prev.map(a => a.id === tx.accountId ? { ...a, currentBalance: a.currentBalance + tx.amount } : a));
        } else if (isEntry) {
          setWalletAccounts(prev => prev.map(a => a.id === tx.accountId ? { ...a, currentBalance: a.currentBalance - tx.amount } : a));
        }

        setWalletTransactions(prev => prev.filter(t => t.id !== id));
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleTabChange = (tab: MainTabType) => {
    setActiveTab(tab);
  };

  const handleSaveProfile = async (updatedProfile: UserProfile, syncWithPersonMe: boolean) => {
    setUserProfile(updatedProfile);
    const userKeyPrefix = currentUser ? `user_${currentUser.uid}_` : '';
    localStorage.setItem(userKeyPrefix + STORAGE_KEYS.PROFILE, JSON.stringify(updatedProfile));
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(updatedProfile));

    if (currentUser) {
      const isFirebaseAuth = Boolean(auth.currentUser && auth.currentUser.uid === currentUser.uid);
      if (isFirebaseAuth && 'providerId' in currentUser) {
        try {
          await updateProfile(currentUser as User, {
            displayName: updatedProfile.nickname,
            photoURL: updatedProfile.photoURL || null,
          });
        } catch (e) {
          console.warn('Could not update Firebase Auth profile:', e);
        }
      }

      if (isFirebaseAuth) {
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          await setDoc(userDocRef, sanitizeForFirestore({
            profile: updatedProfile,
            updatedAt: new Date().toISOString(),
          }), { merge: true });
        } catch (e) {
          console.warn('Firestore profile save notice:', e);
        }
      }
    }

    if (syncWithPersonMe) {
      setPeople(prev => prev.map(p => {
        if (p.isSelf || p.id === 'person-me') {
          const preferredName = updatedProfile.nickname || updatedProfile.name || 'Meu';
          return {
            ...p,
            name: preferredName.startsWith('Meu') ? preferredName : `Meu (${preferredName})`,
            phone: updatedProfile.phone || p.phone,
            pixKey: updatedProfile.pixKey || p.pixKey,
            photoURL: updatedProfile.photoURL || p.photoURL,
            email: updatedProfile.email || p.email,
            cpf: updatedProfile.cpf || p.cpf,
          };
        }
        return p;
      }));
    }
  };

  const handleWipeData = async () => {
    if (!currentUser) return;
    try {
      const isFirebaseAuth = Boolean(auth.currentUser && auth.currentUser.uid === currentUser.uid);
      if (isFirebaseAuth) {
        const path = `users/${currentUser.uid}`;
        try {
          const userDocRef = doc(db, 'users', currentUser.uid);
          await setDoc(userDocRef, sanitizeForFirestore({
            expenses: INITIAL_EXPENSES,
            incomes: INITIAL_INCOMES,
            cards: INITIAL_CARDS,
            people: INITIAL_PEOPLE,
            folders: INITIAL_FOLDERS,
            boxes: INITIAL_BOXES,
            paidBills: [],
            subscriptions: INITIAL_SUBSCRIPTIONS,
            driverTrips: INITIAL_DRIVER_TRIPS,
            driverExpenses: INITIAL_DRIVER_EXPENSES,
            driverGoals: INITIAL_DRIVER_GOALS,
            extraProfile: INITIAL_EXTRA_PROFILE,
            freelanceEntries: INITIAL_FREELANCE_ENTRIES,
            freelanceExpenses: INITIAL_FREELANCE_EXPENSES,
            freelanceGoals: INITIAL_FREELANCE_GOALS,
            walletAccounts: INITIAL_WALLET_ACCOUNTS,
            walletTransactions: INITIAL_WALLET_TRANSACTIONS,
            profile: {
              name: currentUser.displayName || undefined,
              nickname: currentUser.displayName || undefined,
              email: currentUser.email || undefined,
              photoURL: currentUser.photoURL || undefined,
              photoSource: currentUser.photoURL ? 'google' : undefined,
              phone: 'phoneNumber' in currentUser ? (currentUser as { phoneNumber?: string }).phoneNumber : undefined,
            }
          }));
        } catch (err: unknown) {
          const firestoreErr = err as { code?: string; message?: string };
          if (firestoreErr?.code === 'permission-denied' || firestoreErr?.message?.includes('permissions')) {
            handleFirestoreError(err, OperationType.WRITE, path);
          } else {
            throw err;
          }
        }
      }

      // Clear local storage
      const userKeyPrefix = `user_${currentUser.uid}_`;
      (Object.keys(STORAGE_KEYS) as Array<keyof typeof STORAGE_KEYS>).forEach(key => {
        const k = STORAGE_KEYS[key];
        localStorage.removeItem(userKeyPrefix + k);
        localStorage.removeItem(k);
      });

      // Reset local react state
      setExpenses(INITIAL_EXPENSES);
      setIncomes(INITIAL_INCOMES);
      setCards(INITIAL_CARDS);
      setPeople(INITIAL_PEOPLE);
      setFolders(INITIAL_FOLDERS);
      setBoxes(INITIAL_BOXES);
      setPaidBills([]);
      setSubscriptions(INITIAL_SUBSCRIPTIONS);
      setDriverTrips(INITIAL_DRIVER_TRIPS);
      setDriverExpenses(INITIAL_DRIVER_EXPENSES);
      setDriverGoals(INITIAL_DRIVER_GOALS);
      setExtraProfile(INITIAL_EXTRA_PROFILE);
      setFreelanceEntries(INITIAL_FREELANCE_ENTRIES);
      setFreelanceExpenses(INITIAL_FREELANCE_EXPENSES);
      setFreelanceGoals(INITIAL_FREELANCE_GOALS);
      setWalletAccounts(INITIAL_WALLET_ACCOUNTS);
      setWalletTransactions(INITIAL_WALLET_TRANSACTIONS);

      window.location.reload();
    } catch (e) {
      console.error('Error wiping data:', e);
      alert('Não foi possível apagar os dados. Verifique a conexão.');
    }
  };

  const handleSignOut = async () => {
    setDataLoadedFromCloud(false);
    loadedUidRef.current = null;
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Error signing out:', e);
    }
    try {
      localStorage.removeItem(STORAGE_KEYS.LOCAL_USER);
    } catch (e) {
      console.error('Error clearing local user session:', e);
    }

    setExpenses([]);
    setIncomes([]);
    setCards([]);
    setPeople(INITIAL_PEOPLE);
    setFolders(INITIAL_FOLDERS);
    setBoxes([]);
    setPaidBills([]);
    setSubscriptions(INITIAL_SUBSCRIPTIONS);
    setDriverTrips(INITIAL_DRIVER_TRIPS);
    setDriverExpenses(INITIAL_DRIVER_EXPENSES);
    setDriverGoals(INITIAL_DRIVER_GOALS);
    setExtraProfile(INITIAL_EXTRA_PROFILE);
    setFreelanceEntries(INITIAL_FREELANCE_ENTRIES);
    setFreelanceExpenses(INITIAL_FREELANCE_EXPENSES);
    setFreelanceGoals(INITIAL_FREELANCE_GOALS);
    setWalletAccounts(INITIAL_WALLET_ACCOUNTS);
    setWalletTransactions(INITIAL_WALLET_TRANSACTIONS);
    setUserProfile({});
    setCurrentUser(null);
  };

  // Show loading spinner while checking auth status
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-3 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin" />
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Carregando Finanças...</p>
        </div>
      </div>
    );
  }

  // Show Login/Signup Screen if not authenticated
  if (!currentUser) {
    return <AuthView onLocalLogin={handleLocalLogin} />;
  }

  return (
    <div className={`min-h-screen w-full max-w-full overflow-x-hidden ${isDarkMode ? 'dark bg-[#000000] text-slate-100' : 'bg-[#F2F2F7] text-slate-900'} font-sans antialiased selection:bg-emerald-500 selection:text-white transition-colors duration-200`}>
      {isLocked && <LockScreen userProfile={userProfile} onUnlock={() => setIsLocked(false)} />}
      <OfflineBanner isOnline={isOnline} />
      {/* Sticky Header with month navigation, auth info & tab switching */}
      <Header
        currentMonth={currentMonth}
        onMonthChange={setCurrentMonth}
        summary={summary}
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onOpenAddExpense={() => handleOpenAddExpenseWithDefaults()}
        onOpenExport={() => setIsExportOpen(true)}
        onResetData={handleResetData}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
        userEmail={currentUser.isAnonymous ? 'Visitante' : currentUser.email}
        profile={userProfile}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onSignOut={handleSignOut}
        onOpenTutorial={() => setIsTutorialOpen(true)}
        isBalanceVisible={isBalanceVisible}
        onToggleBalance={() => setIsBalanceVisible(!isBalanceVisible)}
      />

      {/* Main Content Area (extra bottom padding on mobile for MobileBottomNav) */}
      <main className="w-full max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 py-4 sm:py-6 pb-24 md:pb-10">
        <PullToRefresh onRefresh={() => loadUserData(true)}>
          {!dataLoadedFromCloud ? (
            <DashboardSkeleton />
          ) : (
            <Suspense fallback={<ViewLoadingFallback />}>
            {activeTab === 'dashboard' && (
            <ChartsDashboard
              currentMonth={currentMonth}
              summary={summary}
              expenses={expenses}
              cards={cards}
              people={people}
              paidBills={paidBills}
              onNavigateToTab={handleTabChange}
              onSelectMonth={setCurrentMonth}
              isDarkMode={isDarkMode}
              onOpenTutorial={() => setIsTutorialOpen(true)}
              onOpenAddExpense={() => handleOpenAddExpenseWithDefaults()}
              onOpenAddIncome={() => {
                setEditingIncome(null);
                setIsAddIncomeOpen(true);
              }}
              onPayBill={handlePayBill}
              onNextMonth={handleAdvanceToNextMonth}
              isBalanceVisible={isBalanceVisible}
              walletAccounts={walletAccounts}
              walletTransactions={walletTransactions}
              investmentBoxes={boxes}
              subscriptions={subscriptions}
              driverTrips={driverTrips}
              driverExpenses={driverExpenses}
              driverGoals={driverGoals}
              extraProfile={extraProfile}
              freelanceEntries={freelanceEntries}
              freelanceExpenses={freelanceExpenses}
              freelanceGoals={freelanceGoals}
              userProfile={userProfile}
              onOpenProfile={() => setIsProfileModalOpen(true)}
              onOpenAddWalletTransaction={(mode, accountId) => {
                setWalletTransactionMode(mode || 'expense');
                setWalletPreselectedAccountId(accountId);
                setIsAddWalletTransactionOpen(true);
              }}
            />
          )}

          {activeTab === 'assinaturas' && (
            <SubscriptionsView
              subscriptions={subscriptions}
              cards={cards}
              people={people}
              onOpenAddSubscription={() => {
                setEditingSubscription(null);
                setIsAddSubscriptionOpen(true);
              }}
              onEditSubscription={handleEditSubscription}
              onDeleteSubscription={handleDeleteSubscription}
              onToggleSubscriptionActive={handleToggleSubscriptionActive}
              onQuickAddPreset={handleQuickAddPreset}
            />
          )}

          {(activeTab === 'extra' || activeTab === 'freelancer' || activeTab === 'meuuber') && (
            <ExtraView
              config={extraProfile}
              onSaveConfig={(newConfig) => setExtraProfile(newConfig)}
              driverTrips={driverTrips}
              driverExpenses={driverExpenses}
              driverGoals={driverGoals}
              onAddDriverTrip={handleSaveDriverTrip}
              onDeleteDriverTrip={handleDeleteDriverTrip}
              onAddDriverExpense={handleSaveDriverExpense}
              onDeleteDriverExpense={handleDeleteDriverExpense}
              onSaveDriverGoals={handleSaveDriverGoals}
              onSaveDriverShift={handleSaveDriverShift}
              freelanceEntries={freelanceEntries}
              freelanceExpenses={freelanceExpenses}
              freelanceGoals={freelanceGoals}
              onOpenAddFreelanceEntry={() => {
                setEditingFreelanceEntry(null);
                setIsAddFreelanceEntryOpen(true);
              }}
              onOpenEditFreelanceEntry={(entry) => {
                setEditingFreelanceEntry(entry);
                setIsAddFreelanceEntryOpen(true);
              }}
              onDeleteFreelanceEntry={handleDeleteFreelanceEntry}
              onOpenAddFreelanceExpense={() => {
                setEditingFreelanceExpense(null);
                setIsAddFreelanceExpenseOpen(true);
              }}
              onOpenEditFreelanceExpense={(expense) => {
                setEditingFreelanceExpense(expense);
                setIsAddFreelanceExpenseOpen(true);
              }}
              onDeleteFreelanceExpense={handleDeleteFreelanceExpense}
              onOpenFreelanceGoals={() => setIsFreelanceGoalsOpen(true)}
              accounts={walletAccounts}
              currentMonth={currentMonth}
              onNavigateToWallet={() => handleTabChange('carteira')}
            />
          )}

          {activeTab === 'cartoes' && (
            <CardsView
              cards={cards}
              people={people}
              activeExpenses={activeExpenses}
              currentMonth={currentMonth}
              paidBills={paidBills}
              onOpenAddCard={handleOpenAddCard}
              onEditCard={handleEditCard}
              onDeleteCard={handleDeleteCard}
              onOpenAddExpenseForCard={(cardId) => handleOpenAddExpenseWithDefaults(undefined, cardId)}
              onEditExpense={handleEditExpense}
              onDeleteExpense={handleDeleteExpense}
              onPayBill={handlePayBill}
              onUnpayBill={handleUnpayBill}
            />
          )}

          {activeTab === 'pessoas' && (
            <PeopleSplitView
              people={people}
              cards={cards}
              activeExpenses={activeExpenses}
              currentMonth={currentMonth}
              userProfile={userProfile}
              onToggleExpensePaid={handleToggleExpensePaid}
              onMarkAllPersonExpensesPaid={handleMarkAllPersonExpensesPaid}
              onOpenAddPerson={() => {
                setEditingPerson(null);
                setIsAddPersonOpen(true);
              }}
              onEditPerson={(person) => {
                setEditingPerson(person);
                setIsAddPersonOpen(true);
              }}
              onDeletePerson={handleDeletePerson}
              onOpenAddExpenseForPerson={(personId) => handleOpenAddExpenseWithDefaults(personId, undefined)}
              onEditExpense={handleEditExpense}
              onDeleteExpense={handleDeleteExpense}
            />
          )}

          {activeTab === 'investimentos' && (
            <InvestmentsView
              folders={folders}
              boxes={boxes}
              onOpenAddFolder={() => {
                setEditingFolder(null);
                setIsAddFolderOpen(true);
              }}
              onEditFolder={(folder) => {
                setEditingFolder(folder);
                setIsAddFolderOpen(true);
              }}
              onDeleteFolder={handleDeleteFolder}
              onOpenAddBox={handleOpenAddBoxForFolder}
              onEditBox={(box) => {
                setEditingBox(box);
                setIsAddBoxOpen(true);
              }}
              onDeleteBox={handleDeleteBox}
              onOpenDeposit={handleOpenDepositModal}
              onOpenWithdraw={handleOpenWithdrawModal}
            />
          )}

          {activeTab === 'carteira' && (
            <WalletView
              accounts={walletAccounts}
              transactions={walletTransactions}
              currentMonth={currentMonth}
              onMonthChange={setCurrentMonth}
              onOpenAddAccount={() => {
                setEditingWalletAccount(null);
                setIsAddWalletAccountOpen(true);
              }}
              onOpenEditAccount={(account) => {
                setEditingWalletAccount(account);
                setIsAddWalletAccountOpen(true);
              }}
              onOpenAddTransaction={(initialMode, accountId) => {
                setWalletTransactionMode(initialMode || 'expense');
                setWalletPreselectedAccountId(accountId);
                setIsAddWalletTransactionOpen(true);
              }}
              onDeleteTransaction={handleDeleteWalletTransaction}
              creditCards={cards}
              monthSummary={summary}
            />
          )}
        </Suspense>
        )}
        </PullToRefresh>

        {/* Strategic Brand Footer */}
        <footer className="hidden sm:flex mt-8 pt-6 pb-6 border-t border-slate-200/80 dark:border-slate-800/80 flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs">
              <GastoLogo size={24} />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1 font-bold text-slate-800 dark:text-slate-200">
                <span>Gastô</span>
                <span className="text-emerald-600 dark:text-emerald-400">?</span>
                <span className="text-[10px] font-medium text-slate-400 dark:text-slate-500 ml-1.5">v2.0</span>
              </div>
              <span className="text-[10px] text-slate-400 dark:text-slate-500">
                Controle financeiro inteligente de cartões & divisão de gastos
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400 dark:text-slate-500">
            <span>Privacidade & Dados Criptografados</span>
            <span>•</span>
            <button 
              type="button" 
              onClick={() => setIsTutorialOpen(true)}
              className="hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors font-medium"
            >
              Guia & Tutorial
            </button>
          </div>
        </footer>
      </main>

      {/* Mobile Bottom Navigation Bar (Visible on mobile screens, hidden in MeuUber view to show dedicated driver FAB) */}
      {activeTab !== 'meuuber' && (
        <MobileBottomNav
          activeTab={activeTab}
          onTabChange={handleTabChange}
          onOpenAddExpense={() => handleOpenAddExpenseWithDefaults()}
        />
      )}

      {/* Modals */}
      <AddExpenseModal
        isOpen={isAddExpenseOpen}
        onClose={() => {
          setIsAddExpenseOpen(false);
          setEditingExpense(null);
        }}
        onSave={handleSaveExpense}
        editingExpense={editingExpense}
        cards={cards}
        people={people}
        currentMonth={currentMonth}
        defaultPersonId={defaultPersonId}
        defaultCardId={defaultCardId}
      />

      <AddSubscriptionModal
        isOpen={isAddSubscriptionOpen}
        onClose={() => {
          setIsAddSubscriptionOpen(false);
          setEditingSubscription(null);
        }}
        onSave={handleSaveSubscription}
        editingSubscription={editingSubscription}
        cards={cards}
        people={people}
      />

      <AddIncomeModal
        isOpen={isAddIncomeOpen}
        onClose={() => {
          setIsAddIncomeOpen(false);
          setEditingIncome(null);
        }}
        onSave={handleSaveIncome}
        editingIncome={editingIncome}
        currentMonth={currentMonth}
      />

      <AddPersonModal
        isOpen={isAddPersonOpen}
        onClose={() => {
          setIsAddPersonOpen(false);
          setEditingPerson(null);
        }}
        onSave={handleSavePerson}
        editingPerson={editingPerson}
      />

      <AddCardModal
        isOpen={isAddCardOpen}
        onClose={() => {
          setIsAddCardOpen(false);
          setEditingCard(null);
        }}
        onSave={handleSaveCard}
        editingCard={editingCard}
        onDelete={handleDeleteCard}
      />

      <AddInvestmentFolderModal
        isOpen={isAddFolderOpen}
        onClose={() => {
          setIsAddFolderOpen(false);
          setEditingFolder(null);
        }}
        onSaveFolder={handleSaveFolder}
        folderToEdit={editingFolder}
      />

      <AddInvestmentBoxModal
        isOpen={isAddBoxOpen}
        onClose={() => {
          setIsAddBoxOpen(false);
          setEditingBox(null);
          setDefaultFolderIdForBox(undefined);
        }}
        onSaveBox={handleSaveBox}
        folders={folders}
        boxToEdit={editingBox}
        defaultFolderId={defaultFolderIdForBox}
      />

      <DepositWithdrawModal
        isOpen={isDepositWithdrawOpen}
        onClose={() => {
          setIsDepositWithdrawOpen(false);
          setSelectedBoxForDeposit(null);
        }}
        box={selectedBoxForDeposit}
        mode={depositModalType}
        onConfirm={handleDepositWithdraw}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        expenses={expenses}
        activeExpenses={activeExpenses}
        cards={cards}
        people={people}
        currentMonth={currentMonth}
        summary={summary}
        walletAccounts={walletAccounts}
        walletTransactions={walletTransactions}
        boxes={boxes}
        folders={folders}
        driverTrips={driverTrips}
        driverExpenses={driverExpenses}
        freelanceEntries={freelanceEntries}
        freelanceExpenses={freelanceExpenses}
        subscriptions={subscriptions}
      />

      <LegalTermsModal
        isOpen={isLegalTermsOpen}
        onClose={() => setIsLegalTermsOpen(false)}
      />

      <ConfirmDialogModal
        isOpen={confirmDialog.isOpen}
        onClose={() => setConfirmDialog(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title}
        description={confirmDialog.description}
        confirmText={confirmDialog.confirmText}
        cancelText={confirmDialog.cancelText}
        variant={confirmDialog.variant}
        icon={confirmDialog.icon}
      />

      {/* Interactive Onboarding Tutorial Modal */}
      <OnboardingTutorialModal
        isOpen={isTutorialOpen}
        onClose={() => setIsTutorialOpen(false)}
        onOpenAddCard={() => {
          setIsTutorialOpen(false);
          setIsAddCardOpen(true);
        }}
        onOpenAddPerson={() => {
          setIsTutorialOpen(false);
          setIsAddPersonOpen(true);
        }}
        onOpenAddExpense={() => {
          setIsTutorialOpen(false);
          handleOpenAddExpenseWithDefaults();
        }}
      />

      {/* User Profile Settings Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        userEmail={currentUser.isAnonymous ? 'Visitante' : currentUser.email}
        currentUser={currentUser}
        profile={userProfile}
        people={people}
        onSaveProfile={handleSaveProfile}
        onSignOut={handleSignOut}
        onOpenLegalTerms={() => setIsLegalTermsOpen(true)}
      />

      {/* Wallet Modals */}
      <AddWalletAccountModal
        isOpen={isAddWalletAccountOpen}
        onClose={() => {
          setIsAddWalletAccountOpen(false);
          setEditingWalletAccount(null);
        }}
        onSave={handleSaveWalletAccount}
        onDelete={handleDeleteWalletAccount}
        editingAccount={editingWalletAccount}
      />

      <AddWalletTransactionModal
        isOpen={isAddWalletTransactionOpen}
        onClose={() => {
          setIsAddWalletTransactionOpen(false);
          setWalletPreselectedAccountId(undefined);
        }}
        accounts={walletAccounts}
        onAddTransaction={handleAddWalletTransaction}
        onAdjustBalance={handleAdjustWalletBalance}
        preselectedAccountId={walletPreselectedAccountId}
        initialMode={walletTransactionMode}
      />

      {/* Freelance Modals */}
      <AddFreelanceEntryModal
        isOpen={isAddFreelanceEntryOpen}
        onClose={() => {
          setIsAddFreelanceEntryOpen(false);
          setEditingFreelanceEntry(null);
        }}
        onSave={handleSaveFreelanceEntry}
        editingEntry={editingFreelanceEntry}
        currentMonth={currentMonth}
        accounts={walletAccounts}
      />

      <AddFreelanceExpenseModal
        isOpen={isAddFreelanceExpenseOpen}
        onClose={() => {
          setIsAddFreelanceExpenseOpen(false);
          setEditingFreelanceExpense(null);
        }}
        onSave={handleSaveFreelanceExpense}
        editingExpense={editingFreelanceExpense}
        currentMonth={currentMonth}
        accounts={walletAccounts}
      />

      <FreelanceGoalsModal
        isOpen={isFreelanceGoalsOpen}
        onClose={() => setIsFreelanceGoalsOpen(false)}
        goals={freelanceGoals}
        onSave={handleSaveFreelanceGoals}
      />

      {/* Onboarding Tutorial Modal */}
      <OnboardingTutorialModal
        isOpen={isTutorialOpen}
        onClose={() => setIsTutorialOpen(false)}
        onOpenAddCard={() => setIsAddCardOpen(true)}
        onOpenAddPerson={() => setIsAddPersonOpen(true)}
        onOpenAddExpense={() => setIsAddExpenseOpen(true)}
        onOpenAddWalletAccount={() => setIsAddWalletAccountOpen(true)}
      />
    </div>
  );
}
